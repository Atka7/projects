package tryhss.soundboardfinally.hsssoundboardmaybe;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.MobileAds;
import com.google.android.material.snackbar.Snackbar;

import tryhss.soundboardfinally.hsssoundboardmaybe.Socials.Atka_Socials;
import tryhss.soundboardfinally.hsssoundboardmaybe.Streamerek.AdamKiss;
import tryhss.soundboardfinally.hsssoundboardmaybe.Streamerek.AvidisOdd;
import tryhss.soundboardfinally.hsssoundboardmaybe.Streamerek.Blyyyplays;
import tryhss.soundboardfinally.hsssoundboardmaybe.Streamerek.Dre3dd;
import tryhss.soundboardfinally.hsssoundboardmaybe.Streamerek.Eazykee;
import tryhss.soundboardfinally.hsssoundboardmaybe.Streamerek.Gerimester3;
import tryhss.soundboardfinally.hsssoundboardmaybe.Streamerek.Karthas;
import tryhss.soundboardfinally.hsssoundboardmaybe.Streamerek.KonTroll;
import tryhss.soundboardfinally.hsssoundboardmaybe.Streamerek.Kriszhadvice;
import tryhss.soundboardfinally.hsssoundboardmaybe.Streamerek.Mirageeputo;
import tryhss.soundboardfinally.hsssoundboardmaybe.Streamerek.Nerdhub;
import tryhss.soundboardfinally.hsssoundboardmaybe.Streamerek.Paplovag;
import tryhss.soundboardfinally.hsssoundboardmaybe.Streamerek.Paresz;
import tryhss.soundboardfinally.hsssoundboardmaybe.Streamerek.Paulusz;
import tryhss.soundboardfinally.hsssoundboardmaybe.Streamerek.Pierce;
import tryhss.soundboardfinally.hsssoundboardmaybe.Streamerek.Pindurok;
import tryhss.soundboardfinally.hsssoundboardmaybe.Streamerek.Ruben;
import tryhss.soundboardfinally.hsssoundboardmaybe.Streamerek.Suri;
import tryhss.soundboardfinally.hsssoundboardmaybe.Streamerek.TheVR;
import tryhss.soundboardfinally.hsssoundboardmaybe.Streamerek.TsBlackii;
import tryhss.soundboardfinally.hsssoundboardmaybe.Streamerek.ZalanRithnovszky;
import tryhss.soundboardfinally.hsssoundboardmaybe.Streamerek.Zsozeatya;


public class Emberek extends AppCompatActivity {

    private View mLayout;

    private InterstitialAd Iad;

    ListView listView;

    public static final String MyPREFERENCE ="nightModePrefs";
    public static final String KEY_ISNIGHTMODE ="isNightMode";
    SharedPreferences sharedPreferences;
    private Switch aSwitch;

    String[] nameList = {"Ruben", "AdamKissAK", "Nerdhub", "Karthas", "TheVr", "Zsozeatya", "Dre3dd", "Pierce", "KonTroll", "Paplovag", "Suri", "KriszhAdvice", "Pindurok", "AvidisOdd", "ZalanRithnovszky", "Gerimester3",
            "bLYYY", "eazykee", "Paresz", "Paulusz", "Mirageeputo", "TsBlackii"};
    String[] soundList = {"47 Hang", "53 Hang", "47 Hang", "47 Hang", "60 Hang", "68 Hang", "23 Hang", "32 Hang", "30 Hang", "12 Hang", "19 Hang", "17 Hang", "12 Hang", "23 Hang", "21 Hang", "17 Hang", "25 Hang", "30 Hang",
            "24 Hang", "21 Hang", "16 Hang", "16 Hang"};
    int[] kepek = {R.drawable.ruben, R.drawable.adamkissak, R.drawable.nerdhub, R.drawable.karthas, R.drawable.thevr, R.drawable.zsoze, R.drawable.azmo, R.drawable.pierce, R.drawable.kontroll,
            R.drawable.paplovag, R.drawable.suri, R.drawable.kriszhadvice, R.drawable.pindurok, R.drawable.avidisodd, R.drawable.zalanrithnovszky, R.drawable.gerimester3, R.drawable.blyyyplays, R.drawable.eazykee,
            R.drawable.paresz, R.drawable.paulusz, R.drawable.mirageeputo, R.drawable.blackii};

    androidx.appcompat.widget.Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_emberek);


        toolbar = findViewById(R.id.toolbar_streamerek);
        setSupportActionBar(toolbar);
        toolbar.inflateMenu(R.menu.menu_streamerek);

        mLayout = findViewById(R.id.activity_streamerek);

        //-----------------AD-----------------------------

        MobileAds.initialize(this, "ca-app-pub-8890972768819102~6800754409");

        AdView ad = findViewById(R.id.ad_view_streamerek);

        AdRequest adRequest = new AdRequest.Builder().build();
        ad.loadAd(adRequest);

        AdView ad2 = findViewById(R.id.ad_view_streamerek_2);

        AdRequest adRequest2 = new AdRequest.Builder().build();
        ad2.loadAd(adRequest2);

        Iad = new InterstitialAd(this);
        Iad.setAdUnitId("ca-app-pub-8890972768819102/7395392958");
        AdRequest adRequest3 = new AdRequest.Builder().build();
        Iad.loadAd(adRequest3);

         //----------------------------------------------

        listView = findViewById(R.id.ListView);

        final MyAdapter adapter = new MyAdapter(this, nameList, soundList, kepek);
        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                if (i == 0) {
                    Intent intent = new Intent(Emberek.this, Ruben.class);
                    startActivity(intent);
                }
                if (i == 1) {
                    Intent intent = new Intent(Emberek.this, AdamKiss.class);
                    startActivity(intent);
                }
                if (i == 2) {
                    Intent intent = new Intent(Emberek.this, Nerdhub.class);
                    startActivity(intent);
                }
                if (i == 3) {
                    Intent intent = new Intent(Emberek.this, Karthas.class);
                    startActivity(intent);
                }
                if (i == 4) {
                    Intent intent = new Intent(Emberek.this, TheVR.class);
                    startActivity(intent);
                }
                if (i == 5) {
                    Intent intent = new Intent(Emberek.this, Zsozeatya.class);
                    startActivity(intent);
                }
                if (i == 6) {
                    Intent intent = new Intent(Emberek.this, Dre3dd.class);
                    startActivity(intent);
                }
                if (i == 7) {
                    Intent intent = new Intent(Emberek.this, Pierce.class);
                    startActivity(intent);
                }
                if (i == 8) {
                    Intent intent = new Intent(Emberek.this, KonTroll.class);
                    startActivity(intent);
                }
                if (i == 9) {
                    Intent intent = new Intent(Emberek.this, Paplovag.class);
                    startActivity(intent);
                }
                if (i == 10) {
                    Intent intent = new Intent(Emberek.this, Suri.class);
                    startActivity(intent);
                }
                if (i == 11) {
                    Intent intent = new Intent(Emberek.this, Kriszhadvice.class);
                    startActivity(intent);
                }
                if (i == 12) {
                    Intent intent = new Intent(Emberek.this, Pindurok.class);
                    startActivity(intent);
                }
                if (i == 13) {
                    Intent intent = new Intent(Emberek.this, AvidisOdd.class);
                    startActivity(intent);
                }
                if (i == 14) {
                    Intent intent = new Intent(Emberek.this, ZalanRithnovszky.class);
                    startActivity(intent);
                }
                if (i == 15) {
                    Intent intent = new Intent(Emberek.this, Gerimester3.class);
                    startActivity(intent);
                }
                if (i == 16) {
                    Intent intent = new Intent(Emberek.this, Blyyyplays.class);
                    startActivity(intent);
                }
                if (i == 17) {
                    Intent intent = new Intent(Emberek.this, Eazykee.class);
                    startActivity(intent);
                }
                if (i == 18) {
                    Intent intent = new Intent(Emberek.this, Paresz.class);
                    startActivity(intent);
                }
                if (i == 19) {
                    Intent intent = new Intent(Emberek.this, Paulusz.class);
                    startActivity(intent);
                }
                if (i == 20) {
                    Intent intent = new Intent(Emberek.this, Mirageeputo.class);
                    startActivity(intent);
                }
                if (i == 21) {
                    Intent intent = new Intent(Emberek.this, TsBlackii.class);
                    startActivity(intent);
                }

            }
        });

        requestPermissions();

    }

    private void saveNightModeState(boolean nightMode) {
        SharedPreferences.Editor editor = sharedPreferences.edit();

        editor.putBoolean(KEY_ISNIGHTMODE, nightMode);

        editor.apply();
    }

    public void chechNightModeActivated() {
        if (sharedPreferences.getBoolean(KEY_ISNIGHTMODE, false)){
            aSwitch.setChecked(true);
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
        } else {
            aSwitch.setChecked(false);
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
        }
    }

    class MyAdapter extends ArrayAdapter<String> {

        Context context;
        String[] rnameList;
        String[] rsoundList;
        int[] rkepek;

        MyAdapter(Context context, String[] name, String[] sound, int[] kep) {
            super(context, R.layout.row, R.id.ListView_Text1, name);
            this.context = context;
            this.rnameList = name;
            this.rsoundList = sound;
            this.rkepek = kep;
        }

        @NonNull
        @Override
        public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
            LayoutInflater layoutInflater = (LayoutInflater) getApplicationContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            @SuppressLint("ViewHolder") View row = layoutInflater.inflate(R.layout.row, parent, false);
            ImageView kepek = row.findViewById(R.id.ListView_Image);
            TextView name = row.findViewById(R.id.ListView_Text1);
            TextView sound = row.findViewById(R.id.ListView_Text2);

            kepek.setImageResource(rkepek[position]);
            name.setText(rnameList[position]);
            sound.setText(rsoundList[position]);

            return row;
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_streamerek, menu);


        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() == R.id.atka_social) {
            Intent intent = new Intent(Emberek.this, Atka_Socials.class);
            startActivity(intent);
            return false;
        } else if (menuItem.getItemId() == R.id.about) {
            Intent intent = new Intent(Emberek.this, About.class);
            startActivity(intent);
            return false;
        } else if (menuItem.getItemId() == R.id.card) {
            Intent intent = new Intent(Emberek.this, Card.class);
            startActivity(intent);
            return false;
        } else if (menuItem.getItemId() == R.id.rate) {
            clicked_btnrate("https://play.google.com/store/apps/details?id=tryhss.soundboardfinally.hsssoundboardmaybe");
            return false;
        } else if (menuItem.getItemId() == R.id.discord) {
            clicked_btndc("https://discord.gg/W2MA6WN");
            return false;
        } else if (menuItem.getItemId() == R.id.support) {

            if (Iad.isLoaded())
                Iad.show();
            else
                Toast.makeText(this, "A reklám még nem töltött be.", Toast.LENGTH_SHORT).show();

            return false;
        }
        return super.onOptionsItemSelected(menuItem);
    }

    public void clicked_btnrate(String url) {
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(url));
        startActivity(intent);
    }

    public void clicked_btndc(String url) {
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(url));
        startActivity(intent);
    }

    private void requestPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 0);
            }

            if (!Settings.System.canWrite(this)) {
                Snackbar.make(mLayout, "Az alkalmazásnak hozzá kell férnie a beállításaihoz.", Snackbar.LENGTH_INDEFINITE).setAction("Rendben",
                        new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {

                                Context context = v.getContext();
                                Intent intent = new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS);
                                intent.setData(Uri.parse("package:" + context.getPackageName()));
                                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                startActivity(intent);
                            }
                        }).show();
            }
        }
    }

}





