package tryhss.soundboardfinally.hsssoundboardmaybe.Streamerek;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import tryhss.soundboardfinally.hsssoundboardmaybe.JavaClassok.SoundObject7;
import tryhss.soundboardfinally.hsssoundboardmaybe.JavaClassok.SoundboardRecyclerAdapter7;
import tryhss.soundboardfinally.hsssoundboardmaybe.R;
import tryhss.soundboardfinally.hsssoundboardmaybe.Socials.Dre3dd_Socials;

public class Dre3dd extends AppCompatActivity {

    ArrayList<SoundObject7> soundList7 = new ArrayList<>();

    RecyclerView SoundView7;
    SoundboardRecyclerAdapter7 SoundAdapter7 = new SoundboardRecyclerAdapter7(soundList7);
    RecyclerView.LayoutManager SoundLayoutManager7;

    androidx.appcompat.widget.Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dre3dd);

        //-----------------AD-----------------------------

        MobileAds.initialize(this,"ca-app-pub-8890972768819102~6800754409");

        AdView ad = findViewById(R.id.ad_view_azmo);
        AdView ad2 = findViewById(R.id.ad_view_azmo_2);

        AdRequest adRequest = new AdRequest.Builder().build();
        ad.loadAd(adRequest);

        AdRequest adRequest2 = new AdRequest.Builder().build();
        ad2.loadAd(adRequest2);

        //------------------------------------------------------------

        toolbar = findViewById(R.id.toolbar_azmo);
        setSupportActionBar(toolbar);
        toolbar.inflateMenu(R.menu.menu_azmo);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        List<String> nameList7 = Arrays.asList(getResources().getStringArray(R.array.soundNames7));

        SoundObject7[] soundItems7 = {new SoundObject7(nameList7.get(0), R.raw.azmo2), new SoundObject7(nameList7.get(1), R.raw.azmo3), new SoundObject7(nameList7.get(2), R.raw.azmo4), new SoundObject7(nameList7.get(3), R.raw.azmo5), new SoundObject7(nameList7.get(4), R.raw.azmo6), new SoundObject7(nameList7.get(5), R.raw.azmo7), new SoundObject7(nameList7.get(6), R.raw.azmo8), new SoundObject7(nameList7.get(7), R.raw.azmo9), new SoundObject7(nameList7.get(8), R.raw.azmo10), new SoundObject7(nameList7.get(9), R.raw.azmo11), new SoundObject7(nameList7.get(10), R.raw.azmo12), new SoundObject7(nameList7.get(11), R.raw.azmo13), new SoundObject7(nameList7.get(12), R.raw.azmo14), new SoundObject7(nameList7.get(13), R.raw.azmo15), new SoundObject7(nameList7.get(14), R.raw.azmo16), new SoundObject7(nameList7.get(15), R.raw.azmo17), new SoundObject7(nameList7.get(16), R.raw.azmo18), new SoundObject7(nameList7.get(17), R.raw.azmo19), new SoundObject7(nameList7.get(18), R.raw.azmo20), new SoundObject7(nameList7.get(19), R.raw.azmo21), new SoundObject7(nameList7.get(20), R.raw.azmo22), new SoundObject7(nameList7.get(21), R.raw.azmo23), new SoundObject7(nameList7.get(22), R.raw.azmo24) };

        soundList7.addAll(Arrays.asList(soundItems7));

        SoundView7 = findViewById(R.id.soundboardRecyclerView7);

        SoundLayoutManager7 = new GridLayoutManager(this, 3);

        SoundView7.setLayoutManager(SoundLayoutManager7);

        SoundView7.setAdapter(SoundAdapter7);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_azmo, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem menuItem)
    {
        if(menuItem.getItemId() == R.id.azmo_social){
            Intent intent = new Intent(Dre3dd.this, Dre3dd_Socials.class);
            startActivity(intent);
            return false;
        }
        //implement logic here to get selected item
        return super.onOptionsItemSelected(menuItem);
    }
}



