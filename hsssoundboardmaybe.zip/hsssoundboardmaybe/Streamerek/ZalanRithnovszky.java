package tryhss.soundboardfinally.hsssoundboardmaybe.Streamerek;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import tryhss.soundboardfinally.hsssoundboardmaybe.JavaClassok.EventHandlerClass15;
import tryhss.soundboardfinally.hsssoundboardmaybe.JavaClassok.SoundObject15;
import tryhss.soundboardfinally.hsssoundboardmaybe.JavaClassok.SoundboardRecyclerAdapter15;
import tryhss.soundboardfinally.hsssoundboardmaybe.R;
import tryhss.soundboardfinally.hsssoundboardmaybe.Socials.ZalanRithnovszkySocials;

public class ZalanRithnovszky extends AppCompatActivity {

    ArrayList<SoundObject15> soundList15 = new ArrayList<>();

    RecyclerView SoundView15;
    SoundboardRecyclerAdapter15 SoundAdapter15 = new SoundboardRecyclerAdapter15(soundList15);
    RecyclerView.LayoutManager SoundLayoutManager15;

    androidx.appcompat.widget.Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_zalan_rithnovszky);

        //-----------------AD-----------------------------

        MobileAds.initialize(this,"ca-app-pub-8890972768819102~6800754409");

        AdView ad = findViewById(R.id.ad_view_zalanrithnovszky);
        AdView ad2 = findViewById(R.id.ad_view_zalanrithnovszky_2);

        AdRequest adRequest = new AdRequest.Builder().build();
        ad.loadAd(adRequest);
        AdRequest adRequest2 = new AdRequest.Builder().build();
        ad2.loadAd(adRequest2);

        //------------------------------------------------------------

        toolbar = findViewById(R.id.toolbar_zalanrithnovszky);
        setSupportActionBar(toolbar);
        toolbar.inflateMenu(R.menu.menu_zalanrithnovszky);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        List<String> nameList15 = Arrays.asList(getResources().getStringArray(R.array.soundNames15));

        SoundObject15[] soundItems15 = {new SoundObject15(nameList15.get(0), R.raw.zalan1), new SoundObject15(nameList15.get(1), R.raw.zalan2), new SoundObject15(nameList15.get(2), R.raw.zalan3), new SoundObject15(nameList15.get(3), R.raw.zalan4), new SoundObject15(nameList15.get(4), R.raw.zalan5), new SoundObject15(nameList15.get(5), R.raw.zalan6), new SoundObject15(nameList15.get(6), R.raw.zalan7), new SoundObject15(nameList15.get(7), R.raw.zalan8), new SoundObject15(nameList15.get(8), R.raw.zalan9), new SoundObject15(nameList15.get(9), R.raw.zalan10), new SoundObject15(nameList15.get(10), R.raw.zalan11), new SoundObject15(nameList15.get(11), R.raw.zalan12), new SoundObject15(nameList15.get(12), R.raw.zalan13), new SoundObject15(nameList15.get(13), R.raw.zalan14), new SoundObject15(nameList15.get(14), R.raw.zalan15), new SoundObject15(nameList15.get(15), R.raw.zalan16), new SoundObject15(nameList15.get(16), R.raw.zalan17), new SoundObject15(nameList15.get(17), R.raw.zalan18), new SoundObject15(nameList15.get(18), R.raw.zalan19), new SoundObject15(nameList15.get(19), R.raw.zalan20), new SoundObject15(nameList15.get(20), R.raw.zalan21) };
        soundList15.addAll(Arrays.asList(soundItems15));

        SoundView15 = findViewById(R.id.soundboardRecyclerView15);

        SoundLayoutManager15 = new GridLayoutManager(this, 3);

        SoundView15.setLayoutManager(SoundLayoutManager15);

        SoundView15.setAdapter(SoundAdapter15);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        EventHandlerClass15.releaseMediaPlayer15();
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_zalanrithnovszky, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem menuItem)
    {
        if(menuItem.getItemId() == R.id.zalanrithnovszky_social){
            Intent intent = new Intent(ZalanRithnovszky.this, ZalanRithnovszkySocials.class);
            startActivity(intent);
            return false;
        }
        //implement logic here to get selected item
        return super.onOptionsItemSelected(menuItem);
    }
}


