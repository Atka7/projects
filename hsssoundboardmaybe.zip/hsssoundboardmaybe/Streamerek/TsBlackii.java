package tryhss.soundboardfinally.hsssoundboardmaybe.Streamerek;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import tryhss.soundboardfinally.hsssoundboardmaybe.JavaClassok.EventHandlerClass23;
import tryhss.soundboardfinally.hsssoundboardmaybe.JavaClassok.SoundObject23;
import tryhss.soundboardfinally.hsssoundboardmaybe.JavaClassok.SoundboardRecyclerAdapter23;
import tryhss.soundboardfinally.hsssoundboardmaybe.R;
import tryhss.soundboardfinally.hsssoundboardmaybe.Socials.TsBlackiiSocials;

public class TsBlackii extends AppCompatActivity {

    ArrayList<SoundObject23> soundList23 = new ArrayList<>();

    RecyclerView SoundView23;
    SoundboardRecyclerAdapter23 SoundAdapter23 = new SoundboardRecyclerAdapter23(soundList23);
    RecyclerView.LayoutManager SoundLayoutManager23;

    androidx.appcompat.widget.Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tsblackii);

        //-----------------AD-----------------------------

        MobileAds.initialize(this,"ca-app-pub-8890972768819102~6800754409");

        AdView ad = findViewById(R.id.ad_view_tsblackii);
        AdView ad2 = findViewById(R.id.ad_view_tsblackii_2);

        AdRequest adRequest = new AdRequest.Builder().build();
        ad.loadAd(adRequest);
        AdRequest adRequest2 = new AdRequest.Builder().build();
        ad2.loadAd(adRequest2);

        //------------------------------------------------------------

        toolbar = findViewById(R.id.toolbar_tsblackii);
        setSupportActionBar(toolbar);
        toolbar.inflateMenu(R.menu.menu_tsblackii);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        List<String> nameList23 = Arrays.asList(getResources().getStringArray(R.array.soundNames23));

        SoundObject23[] soundItems23 = {new SoundObject23(nameList23.get(0), R.raw.tsblackii1), new SoundObject23(nameList23.get(1), R.raw.tsblackii2), new SoundObject23(nameList23.get(2), R.raw.tsblackii3), new SoundObject23(nameList23.get(3), R.raw.tsblackii4), new SoundObject23(nameList23.get(4), R.raw.tsblackii5), new SoundObject23(nameList23.get(5), R.raw.tsblackii6), new SoundObject23(nameList23.get(6), R.raw.tsblackii7), new SoundObject23(nameList23.get(7), R.raw.tsblackii8), new SoundObject23(nameList23.get(8), R.raw.tsblackii9), new SoundObject23(nameList23.get(9), R.raw.tsblackii10), new SoundObject23(nameList23.get(10), R.raw.tsblackii11), new SoundObject23(nameList23.get(11), R.raw.tsblackii12), new SoundObject23(nameList23.get(12), R.raw.tsblackii13), new SoundObject23(nameList23.get(13), R.raw.tsblackii14), new SoundObject23(nameList23.get(14), R.raw.tsblackii15), new SoundObject23(nameList23.get(15), R.raw.tsblackii16) };
        soundList23.addAll(Arrays.asList(soundItems23));

        SoundView23 = findViewById(R.id.soundboardRecyclerView23);

        SoundLayoutManager23 = new GridLayoutManager(this, 3);

        SoundView23.setLayoutManager(SoundLayoutManager23);

        SoundView23.setAdapter(SoundAdapter23);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        EventHandlerClass23.releaseMediaPlayer23();
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_tsblackii, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem menuItem)
    {
        if(menuItem.getItemId() == R.id.tsblackii_social){
            Intent intent = new Intent(TsBlackii.this, TsBlackiiSocials.class);
            startActivity(intent);
            return false;
        }
        //implement logic here to get selected item
        return super.onOptionsItemSelected(menuItem);
    }
}


