package tryhss.soundboardfinally.hsssoundboardmaybe.Streamerek;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import tryhss.soundboardfinally.hsssoundboardmaybe.JavaClassok.SoundObject13;
import tryhss.soundboardfinally.hsssoundboardmaybe.JavaClassok.SoundboardRecyclerAdapter13;
import tryhss.soundboardfinally.hsssoundboardmaybe.R;
import tryhss.soundboardfinally.hsssoundboardmaybe.Socials.KriszhAdvice_Socials;

public class Kriszhadvice extends AppCompatActivity {

    ArrayList<SoundObject13> soundList13 = new ArrayList<>();

    RecyclerView SoundView13;
    SoundboardRecyclerAdapter13 SoundAdapter13 = new SoundboardRecyclerAdapter13(soundList13);
    RecyclerView.LayoutManager SoundLayoutManager13;

    androidx.appcompat.widget.Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kriszhadvice);

        //-----------------AD-----------------------------

        MobileAds.initialize(this,"ca-app-pub-8890972768819102~6800754409");

        AdView ad = findViewById(R.id.ad_view_kriszhadvice);
        AdView ad2 = findViewById(R.id.ad_view_kriszhadvice_2);

        AdRequest adRequest = new AdRequest.Builder().build();
        ad.loadAd(adRequest);

        AdRequest adRequest2 = new AdRequest.Builder().build();
        ad2.loadAd(adRequest2);

        //------------------------------------------------------------

        toolbar = findViewById(R.id.toolbar_kriszhadvice);
        setSupportActionBar(toolbar);
        toolbar.inflateMenu(R.menu.menu_kriszhadvice);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        List<String> nameList13 = Arrays.asList(getResources().getStringArray(R.array.soundNames13));

        SoundObject13[] soundItems13 = {new SoundObject13(nameList13.get(0), R.raw.kriszh1), new SoundObject13(nameList13.get(1), R.raw.kriszh2), new SoundObject13(nameList13.get(2), R.raw.kriszh3), new SoundObject13(nameList13.get(3), R.raw.kriszh4), new SoundObject13(nameList13.get(4), R.raw.kriszh5), new SoundObject13(nameList13.get(5), R.raw.kriszh6), new SoundObject13(nameList13.get(6), R.raw.kriszh7), new SoundObject13(nameList13.get(7), R.raw.kriszh8), new SoundObject13(nameList13.get(8), R.raw.kriszh9), new SoundObject13(nameList13.get(9), R.raw.kriszh10), new SoundObject13(nameList13.get(10), R.raw.kriszh11), new SoundObject13(nameList13.get(11), R.raw.kriszh12), new SoundObject13(nameList13.get(12), R.raw.kriszh13), new SoundObject13(nameList13.get(13), R.raw.kriszh14), new SoundObject13(nameList13.get(14), R.raw.kriszh15), new SoundObject13(nameList13.get(15), R.raw.kriszh16), new SoundObject13(nameList13.get(16), R.raw.kriszh17)  };

        soundList13.addAll(Arrays.asList(soundItems13));

        SoundView13 = findViewById(R.id.soundboardRecyclerView13);

        SoundLayoutManager13 = new GridLayoutManager(this, 3);

        SoundView13.setLayoutManager(SoundLayoutManager13);

        SoundView13.setAdapter(SoundAdapter13);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_kriszhadvice, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem menuItem)
    {
        if(menuItem.getItemId() == R.id.kriszhadvice_social){
            Intent intent = new Intent(Kriszhadvice.this, KriszhAdvice_Socials.class);
            startActivity(intent);
            return false;
        }
        //implement logic here to get selected item
        return super.onOptionsItemSelected(menuItem);
    }
}



