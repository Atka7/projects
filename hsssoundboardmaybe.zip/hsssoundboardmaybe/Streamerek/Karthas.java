package tryhss.soundboardfinally.hsssoundboardmaybe.Streamerek;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import tryhss.soundboardfinally.hsssoundboardmaybe.JavaClassok.EventHandlerClass4;
import tryhss.soundboardfinally.hsssoundboardmaybe.JavaClassok.SoundObject4;
import tryhss.soundboardfinally.hsssoundboardmaybe.JavaClassok.SoundboardRecyclerAdapter4;
import tryhss.soundboardfinally.hsssoundboardmaybe.R;
import tryhss.soundboardfinally.hsssoundboardmaybe.Socials.Karthas_Socials;

public class Karthas extends AppCompatActivity {

    ArrayList<SoundObject4> soundList4 = new ArrayList<>();

    RecyclerView SoundView4;
    SoundboardRecyclerAdapter4 SoundAdapter4 = new SoundboardRecyclerAdapter4(soundList4);
    RecyclerView.LayoutManager SoundLayoutManager4;

    androidx.appcompat.widget.Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_karthas);

        toolbar = findViewById(R.id.toolbar_karthas);
        setSupportActionBar(toolbar);
        toolbar.inflateMenu(R.menu.menu_karthas);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        //-----------------AD-----------------------------

        MobileAds.initialize(this,"ca-app-pub-8890972768819102~6800754409");

        AdView ad = findViewById(R.id.ad_view_karthas);
        AdView ad2 = findViewById(R.id.ad_view_karthas_2);

        AdRequest adRequest = new AdRequest.Builder().build();
        ad.loadAd(adRequest);

        AdRequest adRequest2 = new AdRequest.Builder().build();
        ad2.loadAd(adRequest2);

        //------------------------------------------------------------


        List<String> nameList4 = Arrays.asList(getResources().getStringArray(R.array.soundNames4));

        SoundObject4[] soundItems4 = {new SoundObject4(nameList4.get(0), R.raw.karthas2), new SoundObject4(nameList4.get(1), R.raw.karthas3), new SoundObject4(nameList4.get(2), R.raw.karthas4), new SoundObject4(nameList4.get(3), R.raw.karthas5), new SoundObject4(nameList4.get(4), R.raw.karthas6), new SoundObject4(nameList4.get(5), R.raw.karthas7), new SoundObject4(nameList4.get(6), R.raw.karthas8), new SoundObject4(nameList4.get(7), R.raw.karthas9), new SoundObject4(nameList4.get(8), R.raw.karthas10), new SoundObject4(nameList4.get(9), R.raw.karthas11), new SoundObject4(nameList4.get(10), R.raw.karthas12), new SoundObject4(nameList4.get(11), R.raw.karthas13), new SoundObject4(nameList4.get(12), R.raw.karthas14), new SoundObject4(nameList4.get(13), R.raw.karthas15), new SoundObject4(nameList4.get(14), R.raw.karthas16), new SoundObject4(nameList4.get(15), R.raw.karthas17), new SoundObject4(nameList4.get(16), R.raw.karthas18), new SoundObject4(nameList4.get(17), R.raw.karthas19), new SoundObject4(nameList4.get(18), R.raw.karthas20), new SoundObject4(nameList4.get(19), R.raw.karthas21), new SoundObject4(nameList4.get(20), R.raw.karthas22), new SoundObject4(nameList4.get(21), R.raw.karthas23), new SoundObject4(nameList4.get(22), R.raw.karthas24), new SoundObject4(nameList4.get(23), R.raw.karthas25), new SoundObject4(nameList4.get(24), R.raw.karthas26), new SoundObject4(nameList4.get(25), R.raw.karthas27), new SoundObject4(nameList4.get(26), R.raw.karthas28), new SoundObject4(nameList4.get(27), R.raw.karthas29), new SoundObject4(nameList4.get(28), R.raw.karthas30), new SoundObject4(nameList4.get(29), R.raw.karthas31), new SoundObject4(nameList4.get(30), R.raw.karthas32), new SoundObject4(nameList4.get(31), R.raw.karthas33), new SoundObject4(nameList4.get(32), R.raw.karthas34), new SoundObject4(nameList4.get(33), R.raw.karthas35), new SoundObject4(nameList4.get(34), R.raw.karthas36), new SoundObject4(nameList4.get(35), R.raw.karthas37), new SoundObject4(nameList4.get(36), R.raw.karthas38), new SoundObject4(nameList4.get(37), R.raw.karthas39), new SoundObject4(nameList4.get(38), R.raw.karthas40), new SoundObject4(nameList4.get(39), R.raw.karthas41), new SoundObject4(nameList4.get(40), R.raw.karthas42), new SoundObject4(nameList4.get(41), R.raw.karthas43), new SoundObject4(nameList4.get(42), R.raw.karthas44), new SoundObject4(nameList4.get(43), R.raw.karthas45), new SoundObject4(nameList4.get(44), R.raw.karthas46), new SoundObject4(nameList4.get(45), R.raw.karthas47), new SoundObject4(nameList4.get(46), R.raw.karthas48)  };

        soundList4.addAll(Arrays.asList(soundItems4));

        SoundView4 = findViewById(R.id.soundboardRecyclerView4);

        SoundLayoutManager4 = new GridLayoutManager(this, 3);

        SoundView4.setLayoutManager(SoundLayoutManager4);

        SoundView4.setAdapter(SoundAdapter4);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        EventHandlerClass4.releaseMediaPlayer4();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_karthas, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem menuItem)
    {
        if(menuItem.getItemId() == R.id.karthas_social){
            Intent intent = new Intent(Karthas.this, Karthas_Socials.class);
            startActivity(intent);
            return false;
        }
        //implement logic here to get selected item
        return super.onOptionsItemSelected(menuItem);
    }
}



