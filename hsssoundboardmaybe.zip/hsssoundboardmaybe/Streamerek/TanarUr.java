package tryhss.soundboardfinally.hsssoundboardmaybe.Streamerek;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import tryhss.soundboardfinally.hsssoundboardmaybe.JavaClassok.EventHandlerClass21;
import tryhss.soundboardfinally.hsssoundboardmaybe.JavaClassok.SoundObject21;
import tryhss.soundboardfinally.hsssoundboardmaybe.JavaClassok.SoundboardRecyclerAdapter21;
import tryhss.soundboardfinally.hsssoundboardmaybe.R;
import tryhss.soundboardfinally.hsssoundboardmaybe.Socials.TanarUrSocials;

public class TanarUr extends AppCompatActivity {

    ArrayList<SoundObject21> soundList21 = new ArrayList<>();

    RecyclerView SoundView21;
    SoundboardRecyclerAdapter21 SoundAdapter21 = new SoundboardRecyclerAdapter21(soundList21);
    RecyclerView.LayoutManager SoundLayoutManager21;

    androidx.appcompat.widget.Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tanarur);

        //-----------------AD-----------------------------

        MobileAds.initialize(this,"ca-app-pub-8890972768819102~6800754409");

        AdView ad = findViewById(R.id.ad_view_tanarur);
        AdView ad2 = findViewById(R.id.ad_view_tanarur_2);

        AdRequest adRequest = new AdRequest.Builder().build();
        ad.loadAd(adRequest);
        AdRequest adRequest2 = new AdRequest.Builder().build();
        ad2.loadAd(adRequest2);

        //------------------------------------------------------------

        toolbar = findViewById(R.id.toolbar_tanarur);
        setSupportActionBar(toolbar);
        toolbar.inflateMenu(R.menu.menu_tanarur);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        List<String> nameList21 = Arrays.asList(getResources().getStringArray(R.array.soundNames21));

        SoundObject21[] soundItems21 = {new SoundObject21(nameList21.get(0), R.raw.tanarur1), new SoundObject21(nameList21.get(1), R.raw.tanarur2), new SoundObject21(nameList21.get(2), R.raw.tanarur3), new SoundObject21(nameList21.get(3), R.raw.tanarur4), new SoundObject21(nameList21.get(4), R.raw.tanarur5), new SoundObject21(nameList21.get(5), R.raw.tanarur6), new SoundObject21(nameList21.get(6), R.raw.tanarur7), new SoundObject21(nameList21.get(7), R.raw.tanarur8), new SoundObject21(nameList21.get(8), R.raw.tanarur9), new SoundObject21(nameList21.get(9), R.raw.tanarur10), new SoundObject21(nameList21.get(10), R.raw.tanarur11), new SoundObject21(nameList21.get(11), R.raw.tanarur12), new SoundObject21(nameList21.get(12), R.raw.tanarur13), new SoundObject21(nameList21.get(13), R.raw.tanarur14), new SoundObject21(nameList21.get(14), R.raw.tanarur15), new SoundObject21(nameList21.get(15), R.raw.tanarur16), new SoundObject21(nameList21.get(16), R.raw.tanarur17), new SoundObject21(nameList21.get(17), R.raw.tanarur18), new SoundObject21(nameList21.get(18), R.raw.tanarur19), new SoundObject21(nameList21.get(19), R.raw.tanarur20), new SoundObject21(nameList21.get(20), R.raw.tanarur21), new SoundObject21(nameList21.get(21), R.raw.tanarur22), new SoundObject21(nameList21.get(22), R.raw.tanarur23) };
        soundList21.addAll(Arrays.asList(soundItems21));

        SoundView21 = findViewById(R.id.soundboardRecyclerView21);

        SoundLayoutManager21 = new GridLayoutManager(this, 3);

        SoundView21.setLayoutManager(SoundLayoutManager21);

        SoundView21.setAdapter(SoundAdapter21);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        EventHandlerClass21.releaseMediaPlayer21();
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_tanarur, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem menuItem)
    {
        if(menuItem.getItemId() == R.id.tanarur_social){
            Intent intent = new Intent(TanarUr.this, TanarUrSocials.class);
            startActivity(intent);
            return false;
        }
        //implement logic here to get selected item
        return super.onOptionsItemSelected(menuItem);
    }
}


