package tryhss.soundboardfinally.hsssoundboardmaybe.Streamerek;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import tryhss.soundboardfinally.hsssoundboardmaybe.JavaClassok.SoundObject10;
import tryhss.soundboardfinally.hsssoundboardmaybe.JavaClassok.SoundboardRecyclerAdapter10;
import tryhss.soundboardfinally.hsssoundboardmaybe.R;
import tryhss.soundboardfinally.hsssoundboardmaybe.Socials.Paplovag_Socials;

public class Paplovag extends AppCompatActivity {

    ArrayList<SoundObject10> soundList10 = new ArrayList<>();

    RecyclerView SoundView10;
    SoundboardRecyclerAdapter10 SoundAdapter10 = new SoundboardRecyclerAdapter10(soundList10);
    RecyclerView.LayoutManager SoundLayoutManager10;

    androidx.appcompat.widget.Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_paplovag);

        //-----------------AD-----------------------------

        MobileAds.initialize(this,"ca-app-pub-8890972768819102~6800754409");

        AdView ad = findViewById(R.id.ad_view_paplovag);
        AdView ad2 = findViewById(R.id.ad_view_paplovag_2);

        AdRequest adRequest = new AdRequest.Builder().build();
        ad.loadAd(adRequest);

        AdRequest adRequest2 = new AdRequest.Builder().build();
        ad2.loadAd(adRequest2);

        //------------------------------------------------------------

        toolbar = findViewById(R.id.toolbar_paplovag);
        setSupportActionBar(toolbar);
        toolbar.inflateMenu(R.menu.menu_paplovag);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        List<String> nameList10 = Arrays.asList(getResources().getStringArray(R.array.soundNames10));

        SoundObject10[] soundItems10 = {new SoundObject10(nameList10.get(0), R.raw.paplovag2), new SoundObject10(nameList10.get(1), R.raw.paplovag3), new SoundObject10(nameList10.get(2), R.raw.paplovag4), new SoundObject10(nameList10.get(3), R.raw.paplovag5), new SoundObject10(nameList10.get(4), R.raw.paplovag6), new SoundObject10(nameList10.get(5), R.raw.paplovag7), new SoundObject10(nameList10.get(6), R.raw.paplovag8), new SoundObject10(nameList10.get(7), R.raw.paplovag9), new SoundObject10(nameList10.get(8), R.raw.paplovag10), new SoundObject10(nameList10.get(9), R.raw.paplovag11), new SoundObject10(nameList10.get(10), R.raw.paplovag12), new SoundObject10(nameList10.get(11), R.raw.paplovag13) };

        soundList10.addAll(Arrays.asList(soundItems10));

        SoundView10 = findViewById(R.id.soundboardRecyclerView10);

        SoundLayoutManager10 = new GridLayoutManager(this, 3);

        SoundView10.setLayoutManager(SoundLayoutManager10);

        SoundView10.setAdapter(SoundAdapter10);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_paplovag, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem menuItem)
    {
        if(menuItem.getItemId() == R.id.paplovag_social){
            Intent intent = new Intent(Paplovag.this, Paplovag_Socials.class);
            startActivity(intent);
            return false;
        }
        //implement logic here to get selected item
        return super.onOptionsItemSelected(menuItem);
    }
}




