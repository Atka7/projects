package tryhss.soundboardfinally.hsssoundboardmaybe.Streamerek;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import tryhss.soundboardfinally.hsssoundboardmaybe.JavaClassok.EventHandlerClass18;
import tryhss.soundboardfinally.hsssoundboardmaybe.JavaClassok.SoundObject18;
import tryhss.soundboardfinally.hsssoundboardmaybe.JavaClassok.SoundboardRecyclerAdapter18;
import tryhss.soundboardfinally.hsssoundboardmaybe.R;
import tryhss.soundboardfinally.hsssoundboardmaybe.Socials.EazykeeSocials;


public class Eazykee extends AppCompatActivity {

    ArrayList<SoundObject18> soundList18 = new ArrayList<>();

    RecyclerView SoundView18;
    SoundboardRecyclerAdapter18 SoundAdapter18 = new SoundboardRecyclerAdapter18(soundList18);
    RecyclerView.LayoutManager SoundLayoutManager18;

    androidx.appcompat.widget.Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_eazykee);

        //-----------------AD-----------------------------

        MobileAds.initialize(this,"ca-app-pub-8890972768819102~6800754409");

        AdView ad = findViewById(R.id.ad_view_eazykee);
        AdView ad2 = findViewById(R.id.ad_view_eazykee_2);

        AdRequest adRequest = new AdRequest.Builder().build();
        ad.loadAd(adRequest);
        AdRequest adRequest2 = new AdRequest.Builder().build();
        ad2.loadAd(adRequest2);

        //------------------------------------------------------------

        toolbar = findViewById(R.id.toolbar_eazykee);
        setSupportActionBar(toolbar);
        toolbar.inflateMenu(R.menu.menu_eazykee);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        List<String> nameList18 = Arrays.asList(getResources().getStringArray(R.array.soundNames18));

        SoundObject18[] soundItems18 = {new SoundObject18(nameList18.get(0), R.raw.eazykee1), new SoundObject18(nameList18.get(1), R.raw.eazykee2), new SoundObject18(nameList18.get(2), R.raw.eazykee3), new SoundObject18(nameList18.get(3), R.raw.eazykee4), new SoundObject18(nameList18.get(4), R.raw.eazykee5), new SoundObject18(nameList18.get(5), R.raw.eazykee6), new SoundObject18(nameList18.get(6), R.raw.eazykee7), new SoundObject18(nameList18.get(7), R.raw.eazykee8), new SoundObject18(nameList18.get(8), R.raw.eazykee9), new SoundObject18(nameList18.get(9), R.raw.eazykee10), new SoundObject18(nameList18.get(10), R.raw.eazykee11), new SoundObject18(nameList18.get(11), R.raw.eazykee12), new SoundObject18(nameList18.get(12), R.raw.eazykee13), new SoundObject18(nameList18.get(13), R.raw.eazykee14), new SoundObject18(nameList18.get(14), R.raw.eazykee15), new SoundObject18(nameList18.get(15), R.raw.eazykee16), new SoundObject18(nameList18.get(16), R.raw.eazykee17), new SoundObject18(nameList18.get(17), R.raw.eazykee18), new SoundObject18(nameList18.get(18), R.raw.eazykee19), new SoundObject18(nameList18.get(19), R.raw.eazykee20), new SoundObject18(nameList18.get(20), R.raw.eazykee21), new SoundObject18(nameList18.get(21), R.raw.eazykee22), new SoundObject18(nameList18.get(22), R.raw.eazykee23), new SoundObject18(nameList18.get(23), R.raw.eazykee24), new SoundObject18(nameList18.get(24), R.raw.eazykee25), new SoundObject18(nameList18.get(25), R.raw.eazykee26), new SoundObject18(nameList18.get(26), R.raw.eazykee27), new SoundObject18(nameList18.get(27), R.raw.eazykee28), new SoundObject18(nameList18.get(28), R.raw.eazykee29), new SoundObject18(nameList18.get(29), R.raw.eazykee30) };
        soundList18.addAll(Arrays.asList(soundItems18));

        SoundView18 = findViewById(R.id.soundboardRecyclerView18);

        SoundLayoutManager18 = new GridLayoutManager(this, 3);

        SoundView18.setLayoutManager(SoundLayoutManager18);

        SoundView18.setAdapter(SoundAdapter18);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        EventHandlerClass18.releaseMediaPlayer18();
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_eazykee, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem menuItem)
    {
        if(menuItem.getItemId() == R.id.eazykee_social){
            Intent intent = new Intent(Eazykee.this, EazykeeSocials.class);
            startActivity(intent);
            return false;
        }
        //implement logic here to get selected item
        return super.onOptionsItemSelected(menuItem);
    }
}


