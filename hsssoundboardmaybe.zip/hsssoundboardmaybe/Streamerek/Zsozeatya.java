package tryhss.soundboardfinally.hsssoundboardmaybe.Streamerek;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import tryhss.soundboardfinally.hsssoundboardmaybe.JavaClassok.EventHandlerClass6;
import tryhss.soundboardfinally.hsssoundboardmaybe.JavaClassok.SoundObject6;
import tryhss.soundboardfinally.hsssoundboardmaybe.JavaClassok.SoundboardRecyclerAdapter6;
import tryhss.soundboardfinally.hsssoundboardmaybe.R;
import tryhss.soundboardfinally.hsssoundboardmaybe.Socials.Zsozeatya_Socials;

public class Zsozeatya extends AppCompatActivity {

    ArrayList<SoundObject6> soundList6 = new ArrayList<>();

    RecyclerView SoundView6;
    SoundboardRecyclerAdapter6 SoundAdapter6 = new SoundboardRecyclerAdapter6(soundList6);
    RecyclerView.LayoutManager SoundLayoutManager6;

    androidx.appcompat.widget.Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_zsozeatya);

        //-----------------AD-----------------------------

        MobileAds.initialize(this,"ca-app-pub-8890972768819102~6800754409");

        AdView ad = findViewById(R.id.ad_view_zsoze);
        AdView ad2 = findViewById(R.id.ad_view_zsoze_2);

        AdRequest adRequest = new AdRequest.Builder().build();
        ad.loadAd(adRequest);

        AdRequest adRequest2 = new AdRequest.Builder().build();
        ad2.loadAd(adRequest2);

        //------------------------------------------------------------

        toolbar = findViewById(R.id.toolbar_zsoze);
        setSupportActionBar(toolbar);
        toolbar.inflateMenu(R.menu.menu_zsoze);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        List<String> nameList6 = Arrays.asList(getResources().getStringArray(R.array.soundNames6));

        SoundObject6[] soundItems6 = {new SoundObject6(nameList6.get(0), R.raw.zsoze2), new SoundObject6(nameList6.get(1), R.raw.zsoze3), new SoundObject6(nameList6.get(2), R.raw.zsoze4), new SoundObject6(nameList6.get(3), R.raw.zsoze5), new SoundObject6(nameList6.get(4), R.raw.zsoze6), new SoundObject6(nameList6.get(5), R.raw.zsoze7), new SoundObject6(nameList6.get(6), R.raw.zsoze8), new SoundObject6(nameList6.get(7), R.raw.zsoze9), new SoundObject6(nameList6.get(8), R.raw.zsoze10), new SoundObject6(nameList6.get(9), R.raw.zsoze11), new SoundObject6(nameList6.get(10), R.raw.zsoze12), new SoundObject6(nameList6.get(11), R.raw.zsoze13), new SoundObject6(nameList6.get(12), R.raw.zsoze14), new SoundObject6(nameList6.get(13), R.raw.zsoze15), new SoundObject6(nameList6.get(14), R.raw.zsoze16), new SoundObject6(nameList6.get(15), R.raw.zsoze17), new SoundObject6(nameList6.get(16), R.raw.zsoze18), new SoundObject6(nameList6.get(17), R.raw.zsoze19), new SoundObject6(nameList6.get(18), R.raw.zsoze20), new SoundObject6(nameList6.get(19), R.raw.zsoze21), new SoundObject6(nameList6.get(20), R.raw.zsoze22), new SoundObject6(nameList6.get(21), R.raw.zsoze23), new SoundObject6(nameList6.get(22), R.raw.zsoze24), new SoundObject6(nameList6.get(23), R.raw.zsoze25), new SoundObject6(nameList6.get(24), R.raw.zsoze26), new SoundObject6(nameList6.get(25), R.raw.zsoze27), new SoundObject6(nameList6.get(26), R.raw.zsoze28), new SoundObject6(nameList6.get(27), R.raw.zsoze29), new SoundObject6(nameList6.get(28), R.raw.zsoze30), new SoundObject6(nameList6.get(29), R.raw.zsoze31), new SoundObject6(nameList6.get(30), R.raw.zsoze32), new SoundObject6(nameList6.get(31), R.raw.zsoze33), new SoundObject6(nameList6.get(32), R.raw.zsoze34), new SoundObject6(nameList6.get(33), R.raw.zsoze35), new SoundObject6(nameList6.get(34), R.raw.zsoze36), new SoundObject6(nameList6.get(35), R.raw.zsoze37), new SoundObject6(nameList6.get(36), R.raw.zsoze38), new SoundObject6(nameList6.get(37), R.raw.zsoze39), new SoundObject6(nameList6.get(38), R.raw.zsoze40), new SoundObject6(nameList6.get(39), R.raw.zsoze41), new SoundObject6(nameList6.get(40), R.raw.zsoze42), new SoundObject6(nameList6.get(41), R.raw.zsoze43), new SoundObject6(nameList6.get(42), R.raw.zsoze44), new SoundObject6(nameList6.get(43), R.raw.zsoze45), new SoundObject6(nameList6.get(44), R.raw.zsoze46), new SoundObject6(nameList6.get(45), R.raw.zsoze47), new SoundObject6(nameList6.get(46), R.raw.zsoze48), new SoundObject6(nameList6.get(47), R.raw.zsoze49), new SoundObject6(nameList6.get(48), R.raw.zsoze50) , new SoundObject6(nameList6.get(49), R.raw.zsoze51), new SoundObject6(nameList6.get(50), R.raw.zsoze52), new SoundObject6(nameList6.get(51), R.raw.zsoze53), new SoundObject6(nameList6.get(52), R.raw.zsoze54), new SoundObject6(nameList6.get(53), R.raw.zsoze55), new SoundObject6(nameList6.get(54), R.raw.zsoze56), new SoundObject6(nameList6.get(55), R.raw.zsoze57), new SoundObject6(nameList6.get(56), R.raw.zsoze58), new SoundObject6(nameList6.get(57), R.raw.zsoze59), new SoundObject6(nameList6.get(58), R.raw.zsoze60), new SoundObject6(nameList6.get(59), R.raw.zsoze61), new SoundObject6(nameList6.get(60), R.raw.zsoze62), new SoundObject6(nameList6.get(61), R.raw.zsoze63), new SoundObject6(nameList6.get(62), R.raw.zsoze64), new SoundObject6(nameList6.get(63), R.raw.zsoze65), new SoundObject6(nameList6.get(64), R.raw.zsoze66), new SoundObject6(nameList6.get(65), R.raw.zsoze67), new SoundObject6(nameList6.get(66), R.raw.zsoze68), new SoundObject6(nameList6.get(67), R.raw.zsoze69) };

        soundList6.addAll(Arrays.asList(soundItems6));

        SoundView6 = findViewById(R.id.soundboardRecyclerView6);

        SoundLayoutManager6 = new GridLayoutManager(this, 4);

        SoundView6.setLayoutManager(SoundLayoutManager6);

        SoundView6.setAdapter(SoundAdapter6);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        EventHandlerClass6.releaseMediaPlayer6();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_zsoze, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem menuItem)
    {
        if(menuItem.getItemId() == R.id.zsoze_social){
            Intent intent = new Intent(Zsozeatya.this, Zsozeatya_Socials.class);
            startActivity(intent);
            return false;
        }
        //implement logic here to get selected item
        return super.onOptionsItemSelected(menuItem);
    }
}






