package tryhss.soundboardfinally.hsssoundboardmaybe.Streamerek;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import tryhss.soundboardfinally.hsssoundboardmaybe.JavaClassok.SoundObject14;
import tryhss.soundboardfinally.hsssoundboardmaybe.JavaClassok.SoundboardRecyclerAdapter14;
import tryhss.soundboardfinally.hsssoundboardmaybe.R;
import tryhss.soundboardfinally.hsssoundboardmaybe.Socials.Pindurok_Socials;

public class Pindurok extends AppCompatActivity {

    ArrayList<SoundObject14> soundList14 = new ArrayList<>();

    RecyclerView SoundView14;
    SoundboardRecyclerAdapter14 SoundAdapter14 = new SoundboardRecyclerAdapter14(soundList14);
    RecyclerView.LayoutManager SoundLayoutManager14;

    androidx.appcompat.widget.Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pindurok);

        //-----------------AD-----------------------------

        MobileAds.initialize(this,"ca-app-pub-8890972768819102~6800754409");

        AdView ad = findViewById(R.id.ad_view_pindurok);
        AdView ad2 = findViewById(R.id.ad_view_pindurok_2);

        AdRequest adRequest = new AdRequest.Builder().build();
        ad.loadAd(adRequest);

        AdRequest adRequest2 = new AdRequest.Builder().build();
        ad2.loadAd(adRequest2);

        //------------------------------------------------------------

        toolbar = findViewById(R.id.toolbar_pindurok);
        setSupportActionBar(toolbar);
        toolbar.inflateMenu(R.menu.menu_pindurok);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        List<String> nameList14 = Arrays.asList(getResources().getStringArray(R.array.soundNames14));

        SoundObject14[] soundItems14 = {new SoundObject14(nameList14.get(0), R.raw.pindurok2), new SoundObject14(nameList14.get(1), R.raw.pindurok3), new SoundObject14(nameList14.get(2), R.raw.pindurok4), new SoundObject14(nameList14.get(3), R.raw.pindurok5), new SoundObject14(nameList14.get(4), R.raw.pindurok6), new SoundObject14(nameList14.get(5), R.raw.pindurok7), new SoundObject14(nameList14.get(6), R.raw.pindurok8), new SoundObject14(nameList14.get(7), R.raw.pindurok9), new SoundObject14(nameList14.get(8), R.raw.pindurok10), new SoundObject14(nameList14.get(9), R.raw.pindurok11), new SoundObject14(nameList14.get(10), R.raw.pindurok12), new SoundObject14(nameList14.get(11), R.raw.pindurok13)  };

        soundList14.addAll(Arrays.asList(soundItems14));

        SoundView14 = findViewById(R.id.soundboardRecyclerView14);

        SoundLayoutManager14 = new GridLayoutManager(this, 3);

        SoundView14.setLayoutManager(SoundLayoutManager14);

        SoundView14.setAdapter(SoundAdapter14);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_pindurok, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem menuItem)
    {
        if(menuItem.getItemId() == R.id.pindurok_social){
            Intent intent = new Intent(Pindurok.this, Pindurok_Socials.class);
            startActivity(intent);
            return false;
        }
        //implement logic here to get selected item
        return super.onOptionsItemSelected(menuItem);
    }
}




