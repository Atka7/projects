package tryhss.soundboardfinally.hsssoundboardmaybe.Streamerek;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import tryhss.soundboardfinally.hsssoundboardmaybe.JavaClassok.EventHandlerClass16;
import tryhss.soundboardfinally.hsssoundboardmaybe.JavaClassok.SoundObject16;
import tryhss.soundboardfinally.hsssoundboardmaybe.JavaClassok.SoundboardRecyclerAdapter16;
import tryhss.soundboardfinally.hsssoundboardmaybe.R;
import tryhss.soundboardfinally.hsssoundboardmaybe.Socials.Gerimester3Socials;

public class Gerimester3 extends AppCompatActivity {

    ArrayList<SoundObject16> soundList16 = new ArrayList<>();

    RecyclerView SoundView16;
    SoundboardRecyclerAdapter16 SoundAdapter16 = new SoundboardRecyclerAdapter16(soundList16);
    RecyclerView.LayoutManager SoundLayoutManager16;

    androidx.appcompat.widget.Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gerimester3);

        //-----------------AD-----------------------------

        MobileAds.initialize(this,"ca-app-pub-8890972768819102~6800754409");

        AdView ad = findViewById(R.id.ad_view_gerimester);
        AdView ad2 = findViewById(R.id.ad_view_gerimester_2);

        AdRequest adRequest = new AdRequest.Builder().build();
        ad.loadAd(adRequest);
        AdRequest adRequest2 = new AdRequest.Builder().build();
        ad2.loadAd(adRequest2);

        //------------------------------------------------------------

        toolbar = findViewById(R.id.toolbar_gerimester);
        setSupportActionBar(toolbar);
        toolbar.inflateMenu(R.menu.menu_gerimester);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        List<String> nameList16 = Arrays.asList(getResources().getStringArray(R.array.soundNames16));

        SoundObject16[] soundItems16 = {new SoundObject16(nameList16.get(0), R.raw.gerimester1), new SoundObject16(nameList16.get(1), R.raw.gerimester2), new SoundObject16(nameList16.get(2), R.raw.gerimester3), new SoundObject16(nameList16.get(3), R.raw.gerimester4), new SoundObject16(nameList16.get(4), R.raw.gerimester5), new SoundObject16(nameList16.get(5), R.raw.gerimester6), new SoundObject16(nameList16.get(6), R.raw.gerimester7), new SoundObject16(nameList16.get(7), R.raw.gerimester8), new SoundObject16(nameList16.get(8), R.raw.gerimester8), new SoundObject16(nameList16.get(9), R.raw.gerimester10), new SoundObject16(nameList16.get(10), R.raw.gerimester11), new SoundObject16(nameList16.get(11), R.raw.gerimester12), new SoundObject16(nameList16.get(12), R.raw.gerimester13), new SoundObject16(nameList16.get(13), R.raw.gerimester14), new SoundObject16(nameList16.get(14), R.raw.gerimester15), new SoundObject16(nameList16.get(15), R.raw.gerimester16), new SoundObject16(nameList16.get(16), R.raw.gerimester17) };
        soundList16.addAll(Arrays.asList(soundItems16));

        SoundView16 = findViewById(R.id.soundboardRecyclerView16);

        SoundLayoutManager16 = new GridLayoutManager(this, 3);

        SoundView16.setLayoutManager(SoundLayoutManager16);

        SoundView16.setAdapter(SoundAdapter16);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        EventHandlerClass16.releaseMediaPlayer16();
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_gerimester, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem menuItem)
    {
        if(menuItem.getItemId() == R.id.gerimester_social){
            Intent intent = new Intent(Gerimester3.this, Gerimester3Socials.class);
            startActivity(intent);
            return false;
        }
        //implement logic here to get selected item
        return super.onOptionsItemSelected(menuItem);
    }
}


