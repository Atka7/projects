package tryhss.soundboardfinally.hsssoundboardmaybe.Streamerek;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;

import tryhss.soundboardfinally.hsssoundboardmaybe.JavaClassok.EventHandlerClass1;
import tryhss.soundboardfinally.hsssoundboardmaybe.JavaClassok.SoundObject1;
import tryhss.soundboardfinally.hsssoundboardmaybe.JavaClassok.SoundboardRecyclerAdapter1;
import tryhss.soundboardfinally.hsssoundboardmaybe.R;
import tryhss.soundboardfinally.hsssoundboardmaybe.Socials.Ruben_Socials;

public class Ruben extends AppCompatActivity {

    ArrayList<SoundObject1> soundList = new ArrayList<>();

    RecyclerView SoundView;
    SoundboardRecyclerAdapter1 SoundAdapter = new SoundboardRecyclerAdapter1(soundList);
    RecyclerView.LayoutManager SoundLayoutManager;

    androidx.appcompat.widget.Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ruben);

        //-----------------AD-----------------------------

        MobileAds.initialize(this,"ca-app-pub-8890972768819102~6800754409");

        AdView ad = findViewById(R.id.ad_view_ruben);
        AdView ad2 = findViewById(R.id.ad_view_ruben_2);

        AdRequest adRequest = new AdRequest.Builder().build();
        ad.loadAd(adRequest);

        AdRequest adRequest2 = new AdRequest.Builder().build();
        ad2.loadAd(adRequest2);

        //------------------------------------------------------------

        toolbar = findViewById(R.id.toolbar_ruben);
        setSupportActionBar(toolbar);
        toolbar.inflateMenu(R.menu.menu_ruben);
        Objects.requireNonNull(getSupportActionBar()).setDisplayHomeAsUpEnabled(true);

        List<String> nameList1 = Arrays.asList(getResources().getStringArray(R.array.soundNames1));

        SoundObject1[] soundItems = {new SoundObject1(nameList1.get(0), R.raw.ruben2), new SoundObject1(nameList1.get(1), R.raw.ruben3), new SoundObject1(nameList1.get(2), R.raw.ruben4), new SoundObject1(nameList1.get(3), R.raw.ruben5), new SoundObject1(nameList1.get(4), R.raw.ruben6), new SoundObject1(nameList1.get(5), R.raw.ruben7), new SoundObject1(nameList1.get(6), R.raw.ruben8), new SoundObject1(nameList1.get(7), R.raw.ruben9), new SoundObject1(nameList1.get(8), R.raw.ruben10), new SoundObject1(nameList1.get(9), R.raw.ruben11), new SoundObject1(nameList1.get(10), R.raw.ruben12), new SoundObject1(nameList1.get(11), R.raw.ruben13), new SoundObject1(nameList1.get(12), R.raw.ruben14), new SoundObject1(nameList1.get(13), R.raw.ruben15), new SoundObject1(nameList1.get(14), R.raw.ruben16), new SoundObject1(nameList1.get(15), R.raw.ruben17), new SoundObject1(nameList1.get(16), R.raw.ruben18), new SoundObject1(nameList1.get(17), R.raw.ruben19), new SoundObject1(nameList1.get(18), R.raw.ruben20), new SoundObject1(nameList1.get(19), R.raw.ruben21), new SoundObject1(nameList1.get(20), R.raw.ruben22), new SoundObject1(nameList1.get(21), R.raw.ruben23), new SoundObject1(nameList1.get(22), R.raw.ruben24), new SoundObject1(nameList1.get(23), R.raw.ruben25), new SoundObject1(nameList1.get(24), R.raw.ruben26), new SoundObject1(nameList1.get(25), R.raw.ruben27), new SoundObject1(nameList1.get(26), R.raw.ruben28), new SoundObject1(nameList1.get(27), R.raw.ruben29), new SoundObject1(nameList1.get(28), R.raw.ruben30), new SoundObject1(nameList1.get(29), R.raw.ruben311), new SoundObject1(nameList1.get(30), R.raw.ruben32), new SoundObject1(nameList1.get(31), R.raw.ruben33), new SoundObject1(nameList1.get(32), R.raw.ruben34), new SoundObject1(nameList1.get(33), R.raw.ruben35), new SoundObject1(nameList1.get(34), R.raw.ruben36), new SoundObject1(nameList1.get(35), R.raw.ruben37), new SoundObject1(nameList1.get(36), R.raw.ruben38), new SoundObject1(nameList1.get(37), R.raw.ruben39), new SoundObject1(nameList1.get(38), R.raw.ruben40), new SoundObject1(nameList1.get(39), R.raw.ruben41), new SoundObject1(nameList1.get(40), R.raw.ruben42), new SoundObject1(nameList1.get(41), R.raw.ruben43), new SoundObject1(nameList1.get(42), R.raw.ruben44), new SoundObject1(nameList1.get(43), R.raw.ruben45), new SoundObject1(nameList1.get(44), R.raw.ruben46), new SoundObject1(nameList1.get(45), R.raw.ruben47), new SoundObject1(nameList1.get(46), R.raw.ruben48) };

        soundList.addAll(Arrays.asList(soundItems));

        SoundView = findViewById(R.id.soundboardRecyclerView);

        SoundLayoutManager = new GridLayoutManager(this, 3);

        SoundView.setLayoutManager(SoundLayoutManager);

        SoundView.setAdapter(SoundAdapter);

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        EventHandlerClass1.releaseMediaPlayer1();

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_ruben, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem menuItem)
    {
        if(menuItem.getItemId() == R.id.ruben_social){
            Intent intent = new Intent(Ruben.this, Ruben_Socials.class);
            startActivity(intent);
            return false;

        }

        //implement logic here to get selected item
        return super.onOptionsItemSelected(menuItem);
    }

}







