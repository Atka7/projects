package tryhss.soundboardfinally.hsssoundboardmaybe.Streamerek;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import tryhss.soundboardfinally.hsssoundboardmaybe.JavaClassok.EventHandlerClass19;
import tryhss.soundboardfinally.hsssoundboardmaybe.JavaClassok.SoundObject19;
import tryhss.soundboardfinally.hsssoundboardmaybe.JavaClassok.SoundboardRecyclerAdapter19;
import tryhss.soundboardfinally.hsssoundboardmaybe.R;
import tryhss.soundboardfinally.hsssoundboardmaybe.Socials.PareszSocials;

public class Paresz extends AppCompatActivity {

    ArrayList<SoundObject19> soundList19 = new ArrayList<>();

    RecyclerView SoundView19;
    SoundboardRecyclerAdapter19 SoundAdapter19 = new SoundboardRecyclerAdapter19(soundList19);
    RecyclerView.LayoutManager SoundLayoutManager19;

    androidx.appcompat.widget.Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_paresz);

        //-----------------AD-----------------------------

        MobileAds.initialize(this,"ca-app-pub-8890972768819102~6800754409");

        AdView ad = findViewById(R.id.ad_view_paresz);
        AdView ad2 = findViewById(R.id.ad_view_paresz_2);

        AdRequest adRequest = new AdRequest.Builder().build();
        ad.loadAd(adRequest);
        AdRequest adRequest2 = new AdRequest.Builder().build();
        ad2.loadAd(adRequest2);

        //------------------------------------------------------------

        toolbar = findViewById(R.id.toolbar_paresz);
        setSupportActionBar(toolbar);
        toolbar.inflateMenu(R.menu.menu_paresz);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        List<String> nameList19 = Arrays.asList(getResources().getStringArray(R.array.soundNames19));

        SoundObject19[] soundItems19 = {new SoundObject19(nameList19.get(0), R.raw.paresz1), new SoundObject19(nameList19.get(1), R.raw.paresz2), new SoundObject19(nameList19.get(2), R.raw.paresz3), new SoundObject19(nameList19.get(3), R.raw.paresz4), new SoundObject19(nameList19.get(4), R.raw.paresz5), new SoundObject19(nameList19.get(5), R.raw.paresz6), new SoundObject19(nameList19.get(6), R.raw.paresz7), new SoundObject19(nameList19.get(7), R.raw.paresz8), new SoundObject19(nameList19.get(8), R.raw.paresz9), new SoundObject19(nameList19.get(9), R.raw.paresz10), new SoundObject19(nameList19.get(10), R.raw.paresz11), new SoundObject19(nameList19.get(11), R.raw.paresz12), new SoundObject19(nameList19.get(12), R.raw.paresz13), new SoundObject19(nameList19.get(13), R.raw.paresz14), new SoundObject19(nameList19.get(14), R.raw.paresz15), new SoundObject19(nameList19.get(15), R.raw.paresz16), new SoundObject19(nameList19.get(16), R.raw.paresz17), new SoundObject19(nameList19.get(17), R.raw.paresz18), new SoundObject19(nameList19.get(18), R.raw.paresz19), new SoundObject19(nameList19.get(19), R.raw.paresz20), new SoundObject19(nameList19.get(20), R.raw.paresz21), new SoundObject19(nameList19.get(21), R.raw.paresz22), new SoundObject19(nameList19.get(22), R.raw.paresz23), new SoundObject19(nameList19.get(23), R.raw.paresz24) };
        soundList19.addAll(Arrays.asList(soundItems19));

        SoundView19 = findViewById(R.id.soundboardRecyclerView19);

        SoundLayoutManager19 = new GridLayoutManager(this, 3);

        SoundView19.setLayoutManager(SoundLayoutManager19);

        SoundView19.setAdapter(SoundAdapter19);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        EventHandlerClass19.releaseMediaPlayer19();
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_paresz, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem menuItem)
    {
        if(menuItem.getItemId() == R.id.paresz_social){
            Intent intent = new Intent(Paresz.this, PareszSocials.class);
            startActivity(intent);
            return false;
        }
        //implement logic here to get selected item
        return super.onOptionsItemSelected(menuItem);
    }
}


