package tryhss.soundboardfinally.hsssoundboardmaybe.Streamerek;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import tryhss.soundboardfinally.hsssoundboardmaybe.JavaClassok.SoundObject9;
import tryhss.soundboardfinally.hsssoundboardmaybe.JavaClassok.SoundboardRecyclerAdapter9;
import tryhss.soundboardfinally.hsssoundboardmaybe.R;
import tryhss.soundboardfinally.hsssoundboardmaybe.Socials.KonTroll_Socials;

public class KonTroll extends AppCompatActivity {

    ArrayList<SoundObject9> soundList9 = new ArrayList<>();

    RecyclerView SoundView9;
    SoundboardRecyclerAdapter9 SoundAdapter9 = new SoundboardRecyclerAdapter9(soundList9);
    RecyclerView.LayoutManager SoundLayoutManager9;

    androidx.appcompat.widget.Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kon_troll);

        //-----------------AD-----------------------------

        MobileAds.initialize(this,"ca-app-pub-8890972768819102~6800754409");

        AdView ad = findViewById(R.id.ad_view_kontroll);
        AdView ad2 = findViewById(R.id.ad_view_kontroll_2);

        AdRequest adRequest = new AdRequest.Builder().build();
        ad.loadAd(adRequest);

        AdRequest adRequest2 = new AdRequest.Builder().build();
        ad2.loadAd(adRequest2);

        //------------------------------------------------------------

        toolbar = findViewById(R.id.toolbar_kontroll);
        setSupportActionBar(toolbar);
        toolbar.inflateMenu(R.menu.menu_kontroll);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        List<String> nameList9 = Arrays.asList(getResources().getStringArray(R.array.soundNames9));

        SoundObject9[] soundItems9 = {new SoundObject9(nameList9.get(0), R.raw.kon1), new SoundObject9(nameList9.get(1), R.raw.kon2), new SoundObject9(nameList9.get(2), R.raw.kon3), new SoundObject9(nameList9.get(3), R.raw.kon4), new SoundObject9(nameList9.get(4), R.raw.kon5), new SoundObject9(nameList9.get(5), R.raw.kon6), new SoundObject9(nameList9.get(6), R.raw.kon7), new SoundObject9(nameList9.get(7), R.raw.kon8), new SoundObject9(nameList9.get(8), R.raw.kon9), new SoundObject9(nameList9.get(9), R.raw.kon10), new SoundObject9(nameList9.get(10), R.raw.kon11), new SoundObject9(nameList9.get(11), R.raw.kon12), new SoundObject9(nameList9.get(12), R.raw.kon13), new SoundObject9(nameList9.get(13), R.raw.kon14), new SoundObject9(nameList9.get(14), R.raw.kon15), new SoundObject9(nameList9.get(15), R.raw.kon16), new SoundObject9(nameList9.get(16), R.raw.kon17), new SoundObject9(nameList9.get(17), R.raw.kon18), new SoundObject9(nameList9.get(18), R.raw.kon19), new SoundObject9(nameList9.get(19), R.raw.kon20), new SoundObject9(nameList9.get(20), R.raw.kon21), new SoundObject9(nameList9.get(21), R.raw.kon22), new SoundObject9(nameList9.get(22), R.raw.kon23), new SoundObject9(nameList9.get(23), R.raw.kon24), new SoundObject9(nameList9.get(24), R.raw.kon25), new SoundObject9(nameList9.get(25), R.raw.kon26), new SoundObject9(nameList9.get(26), R.raw.kon27), new SoundObject9(nameList9.get(27), R.raw.kon28), new SoundObject9(nameList9.get(28), R.raw.kon29), new SoundObject9(nameList9.get(29), R.raw.kon30)  };

        soundList9.addAll(Arrays.asList(soundItems9));

        SoundView9 = findViewById(R.id.soundboardRecyclerView9);

        SoundLayoutManager9 = new GridLayoutManager(this, 3);

        SoundView9.setLayoutManager(SoundLayoutManager9);

        SoundView9.setAdapter(SoundAdapter9);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_kontroll, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem menuItem)
    {
        if(menuItem.getItemId() == R.id.kontroll_social){
            Intent intent = new Intent(KonTroll.this, KonTroll_Socials.class);
            startActivity(intent);
            return false;
        }
        //implement logic here to get selected item
        return super.onOptionsItemSelected(menuItem);
    }
}



