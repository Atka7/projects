package tryhss.soundboardfinally.hsssoundboardmaybe.Streamerek;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import tryhss.soundboardfinally.hsssoundboardmaybe.JavaClassok.EventHandlerClass17;
import tryhss.soundboardfinally.hsssoundboardmaybe.JavaClassok.SoundObject17;
import tryhss.soundboardfinally.hsssoundboardmaybe.JavaClassok.SoundboardRecyclerAdapter17;
import tryhss.soundboardfinally.hsssoundboardmaybe.R;
import tryhss.soundboardfinally.hsssoundboardmaybe.Socials.BlyyyplaysSocials;

public class Blyyyplays extends AppCompatActivity {

    ArrayList<SoundObject17> soundList17 = new ArrayList<>();

    RecyclerView SoundView17;
    SoundboardRecyclerAdapter17 SoundAdapter17 = new SoundboardRecyclerAdapter17(soundList17);
    RecyclerView.LayoutManager SoundLayoutManager17;

    androidx.appcompat.widget.Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_blyyyplays);

        //-----------------AD-----------------------------

        MobileAds.initialize(this,"ca-app-pub-8890972768819102~6800754409");

        AdView ad = findViewById(R.id.ad_view_blyyyplays);
        AdView ad2 = findViewById(R.id.ad_view_blyyyplays_2);

        AdRequest adRequest = new AdRequest.Builder().build();
        ad.loadAd(adRequest);
        AdRequest adRequest2 = new AdRequest.Builder().build();
        ad2.loadAd(adRequest2);

        //------------------------------------------------------------

        toolbar = findViewById(R.id.toolbar_blyyyplays);
        setSupportActionBar(toolbar);
        toolbar.inflateMenu(R.menu.menu_blyyyplays);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        List<String> nameList17 = Arrays.asList(getResources().getStringArray(R.array.soundNames17));

        SoundObject17[] soundItems17 = {new SoundObject17(nameList17.get(0), R.raw.bly2), new SoundObject17(nameList17.get(1), R.raw.bly3), new SoundObject17(nameList17.get(2), R.raw.bly4), new SoundObject17(nameList17.get(3), R.raw.bly5), new SoundObject17(nameList17.get(4), R.raw.bly6), new SoundObject17(nameList17.get(5), R.raw.bly7), new SoundObject17(nameList17.get(6), R.raw.bly8), new SoundObject17(nameList17.get(7), R.raw.bly9), new SoundObject17(nameList17.get(8), R.raw.bly10), new SoundObject17(nameList17.get(9), R.raw.bly11), new SoundObject17(nameList17.get(10), R.raw.bly12), new SoundObject17(nameList17.get(11), R.raw.bly13), new SoundObject17(nameList17.get(12), R.raw.bly14), new SoundObject17(nameList17.get(13), R.raw.bly15), new SoundObject17(nameList17.get(14), R.raw.bly16), new SoundObject17(nameList17.get(15), R.raw.bly17), new SoundObject17(nameList17.get(16), R.raw.bly18), new SoundObject17(nameList17.get(17), R.raw.bly19), new SoundObject17(nameList17.get(18), R.raw.bly20), new SoundObject17(nameList17.get(19), R.raw.bly21), new SoundObject17(nameList17.get(20), R.raw.bly22), new SoundObject17(nameList17.get(21), R.raw.bly23), new SoundObject17(nameList17.get(22), R.raw.bly24), new SoundObject17(nameList17.get(23), R.raw.bly25), new SoundObject17(nameList17.get(24), R.raw.bly26) };
        soundList17.addAll(Arrays.asList(soundItems17));

        SoundView17 = findViewById(R.id.soundboardRecyclerView17);

        SoundLayoutManager17 = new GridLayoutManager(this, 3);

        SoundView17.setLayoutManager(SoundLayoutManager17);

        SoundView17.setAdapter(SoundAdapter17);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        EventHandlerClass17.releaseMediaPlayer17();
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_blyyyplays, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem menuItem)
    {
        if(menuItem.getItemId() == R.id.blyyyplays_social){
            Intent intent = new Intent(Blyyyplays.this, BlyyyplaysSocials.class);
            startActivity(intent);
            return false;
        }
        //implement logic here to get selected item
        return super.onOptionsItemSelected(menuItem);
    }
}


