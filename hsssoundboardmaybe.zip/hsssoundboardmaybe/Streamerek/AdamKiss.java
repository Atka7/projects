package tryhss.soundboardfinally.hsssoundboardmaybe.Streamerek;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import tryhss.soundboardfinally.hsssoundboardmaybe.JavaClassok.EventHandlerClass2;
import tryhss.soundboardfinally.hsssoundboardmaybe.JavaClassok.SoundObject2;
import tryhss.soundboardfinally.hsssoundboardmaybe.JavaClassok.SoundboardRecyclerAdapter2;
import tryhss.soundboardfinally.hsssoundboardmaybe.R;
import tryhss.soundboardfinally.hsssoundboardmaybe.Socials.AdamKissAK_Socials;

public class AdamKiss extends AppCompatActivity {

    ArrayList<SoundObject2> soundList2 = new ArrayList<>();

    RecyclerView SoundView2;
    SoundboardRecyclerAdapter2 SoundAdapter2 = new SoundboardRecyclerAdapter2(soundList2);
    RecyclerView.LayoutManager SoundLayoutManager2;

    androidx.appcompat.widget.Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_adamkissak);

        //-----------------AD-----------------------------

        MobileAds.initialize(this, "ca-app-pub-8890972768819102~6800754409");

        AdView ad = findViewById(R.id.ad_view_adamkiss);
        AdView ad2 = findViewById(R.id.ad_view_adamkiss_2);

        AdRequest adRequest = new AdRequest.Builder().build();
        ad.loadAd(adRequest);
        AdRequest adRequest2 = new AdRequest.Builder().build();
        ad2.loadAd(adRequest2);

        //------------------------------------------------------------

        toolbar = findViewById(R.id.toolbar_adamkiss);
        setSupportActionBar(toolbar);
        toolbar.inflateMenu(R.menu.menu_adamkiss);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        List<String> nameList2 = Arrays.asList(getResources().getStringArray(R.array.soundNames2));

        SoundObject2[] soundItems2 = {new SoundObject2(nameList2.get(0), R.raw.ak2), new SoundObject2(nameList2.get(1), R.raw.ak3), new SoundObject2(nameList2.get(2), R.raw.ak4), new SoundObject2(nameList2.get(3), R.raw.ak5), new SoundObject2(nameList2.get(4), R.raw.ak6), new SoundObject2(nameList2.get(5), R.raw.ak7), new SoundObject2(nameList2.get(6), R.raw.ak8), new SoundObject2(nameList2.get(7), R.raw.ak9), new SoundObject2(nameList2.get(8), R.raw.ak10), new SoundObject2(nameList2.get(9), R.raw.ak11), new SoundObject2(nameList2.get(10), R.raw.ak12), new SoundObject2(nameList2.get(11), R.raw.ak13), new SoundObject2(nameList2.get(12), R.raw.ak14), new SoundObject2(nameList2.get(13), R.raw.ak15), new SoundObject2(nameList2.get(14), R.raw.ak16), new SoundObject2(nameList2.get(15), R.raw.ak17), new SoundObject2(nameList2.get(16), R.raw.ak18), new SoundObject2(nameList2.get(17), R.raw.ak19), new SoundObject2(nameList2.get(18), R.raw.ak20), new SoundObject2(nameList2.get(19), R.raw.ak21), new SoundObject2(nameList2.get(20), R.raw.ak22), new SoundObject2(nameList2.get(21), R.raw.ak23), new SoundObject2(nameList2.get(22), R.raw.ak24), new SoundObject2(nameList2.get(23), R.raw.ak25), new SoundObject2(nameList2.get(24), R.raw.ak26), new SoundObject2(nameList2.get(25), R.raw.ak27), new SoundObject2(nameList2.get(26), R.raw.ak28), new SoundObject2(nameList2.get(27), R.raw.ak29), new SoundObject2(nameList2.get(28), R.raw.ak30), new SoundObject2(nameList2.get(29), R.raw.akmegfog), new SoundObject2(nameList2.get(30), R.raw.ak32), new SoundObject2(nameList2.get(31), R.raw.ak33), new SoundObject2(nameList2.get(32), R.raw.ak34), new SoundObject2(nameList2.get(33), R.raw.ak35), new SoundObject2(nameList2.get(34), R.raw.ak36), new SoundObject2(nameList2.get(35), R.raw.ak37), new SoundObject2(nameList2.get(36), R.raw.ak38), new SoundObject2(nameList2.get(37), R.raw.ak39), new SoundObject2(nameList2.get(38), R.raw.ak40), new SoundObject2(nameList2.get(39), R.raw.ak41), new SoundObject2(nameList2.get(40), R.raw.ak42), new SoundObject2(nameList2.get(41), R.raw.ak43), new SoundObject2(nameList2.get(42), R.raw.ak44), new SoundObject2(nameList2.get(43), R.raw.ak45), new SoundObject2(nameList2.get(44), R.raw.ak46), new SoundObject2(nameList2.get(45), R.raw.ak47), new SoundObject2(nameList2.get(46), R.raw.ak48), new SoundObject2(nameList2.get(47), R.raw.ak49), new SoundObject2(nameList2.get(48), R.raw.ak50), new SoundObject2(nameList2.get(49), R.raw.ak51), new SoundObject2(nameList2.get(50), R.raw.ak52), new SoundObject2(nameList2.get(51), R.raw.ak53), new SoundObject2(nameList2.get(52), R.raw.ak54)};

        soundList2.addAll(Arrays.asList(soundItems2));

        SoundView2 = findViewById(R.id.soundboardRecyclerView2);

        SoundLayoutManager2 = new GridLayoutManager(this, 3);

        SoundView2.setLayoutManager(SoundLayoutManager2);

        SoundView2.setAdapter(SoundAdapter2);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        EventHandlerClass2.releaseMediaPlayer2();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_adamkiss, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() == R.id.ak_social) {
            Intent intent = new Intent(AdamKiss.this, AdamKissAK_Socials.class);
            startActivity(intent);
            return false;
        }
        //implement logic here to get selected item
        return super.onOptionsItemSelected(menuItem);
    }
}


