package tryhss.soundboardfinally.hsssoundboardmaybe.Streamerek;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import tryhss.soundboardfinally.hsssoundboardmaybe.JavaClassok.SoundObject12;
import tryhss.soundboardfinally.hsssoundboardmaybe.JavaClassok.SoundboardRecyclerAdapter12;
import tryhss.soundboardfinally.hsssoundboardmaybe.R;
import tryhss.soundboardfinally.hsssoundboardmaybe.Socials.Suri_Socials;

public class Suri extends AppCompatActivity {

    ArrayList<SoundObject12> soundList12 = new ArrayList<>();

    RecyclerView SoundView12;
    SoundboardRecyclerAdapter12 SoundAdapter12 = new SoundboardRecyclerAdapter12(soundList12);
    RecyclerView.LayoutManager SoundLayoutManager12;

    androidx.appcompat.widget.Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_suri);

        //-----------------AD-----------------------------

        MobileAds.initialize(this,"ca-app-pub-8890972768819102~6800754409");

        AdView ad = findViewById(R.id.ad_view_suri);
        AdView ad2 = findViewById(R.id.ad_view_suri_2);

        AdRequest adRequest = new AdRequest.Builder().build();
        ad.loadAd(adRequest);

        AdRequest adRequest2 = new AdRequest.Builder().build();
        ad2.loadAd(adRequest2);

        //------------------------------------------------------------

        toolbar = findViewById(R.id.toolbar_suri);
        setSupportActionBar(toolbar);
        toolbar.inflateMenu(R.menu.menu_suri);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        List<String> nameList12 = Arrays.asList(getResources().getStringArray(R.array.soundNames12));

        SoundObject12[] soundItems12 = {new SoundObject12(nameList12.get(0), R.raw.suri2), new SoundObject12(nameList12.get(1), R.raw.suri3), new SoundObject12(nameList12.get(2), R.raw.suri4), new SoundObject12(nameList12.get(3), R.raw.suri5), new SoundObject12(nameList12.get(4), R.raw.suri6), new SoundObject12(nameList12.get(5), R.raw.suri7), new SoundObject12(nameList12.get(6), R.raw.suri8), new SoundObject12(nameList12.get(7), R.raw.suri9), new SoundObject12(nameList12.get(8), R.raw.suri10), new SoundObject12(nameList12.get(9), R.raw.suri11), new SoundObject12(nameList12.get(10), R.raw.suri12), new SoundObject12(nameList12.get(11), R.raw.suri13), new SoundObject12(nameList12.get(12), R.raw.suri14), new SoundObject12(nameList12.get(13), R.raw.suri15), new SoundObject12(nameList12.get(14), R.raw.suri16), new SoundObject12(nameList12.get(15), R.raw.suri17), new SoundObject12(nameList12.get(16), R.raw.suri18), new SoundObject12(nameList12.get(17), R.raw.suri19), new SoundObject12(nameList12.get(18), R.raw.suri20)   };

        soundList12.addAll(Arrays.asList(soundItems12));

        SoundView12 = findViewById(R.id.soundboardRecyclerView12);

        SoundLayoutManager12 = new GridLayoutManager(this, 3);

        SoundView12.setLayoutManager(SoundLayoutManager12);

        SoundView12.setAdapter(SoundAdapter12);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_suri, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem menuItem)
    {
        if(menuItem.getItemId() == R.id.suri_social){
            Intent intent = new Intent(Suri.this, Suri_Socials.class);
            startActivity(intent);
            return false;
        }
        //implement logic here to get selected item
        return super.onOptionsItemSelected(menuItem);
    }
}

