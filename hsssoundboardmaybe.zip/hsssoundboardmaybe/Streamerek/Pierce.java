package tryhss.soundboardfinally.hsssoundboardmaybe.Streamerek;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import tryhss.soundboardfinally.hsssoundboardmaybe.JavaClassok.SoundObject8;
import tryhss.soundboardfinally.hsssoundboardmaybe.JavaClassok.SoundboardRecyclerAdapter8;
import tryhss.soundboardfinally.hsssoundboardmaybe.R;
import tryhss.soundboardfinally.hsssoundboardmaybe.Socials.Pierce_Socials;

public class Pierce extends AppCompatActivity {

    ArrayList<SoundObject8> soundList8 = new ArrayList<>();

    RecyclerView SoundView8;
    SoundboardRecyclerAdapter8 SoundAdapter8 = new SoundboardRecyclerAdapter8(soundList8);
    RecyclerView.LayoutManager SoundLayoutManager8;

    androidx.appcompat.widget.Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pierce);

        //-----------------AD-----------------------------

        MobileAds.initialize(this,"ca-app-pub-8890972768819102~6800754409");

        AdView ad = findViewById(R.id.ad_view_pierce);
        AdView ad2 = findViewById(R.id.ad_view_pierce_2);

        AdRequest adRequest = new AdRequest.Builder().build();
        ad.loadAd(adRequest);

        AdRequest adRequest2 = new AdRequest.Builder().build();
        ad2.loadAd(adRequest2);

        //------------------------------------------------------------

        toolbar = findViewById(R.id.toolbar_pierce);
        setSupportActionBar(toolbar);
        toolbar.inflateMenu(R.menu.menu_pierce);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        List<String> nameList8 = Arrays.asList(getResources().getStringArray(R.array.soundNames8));

        SoundObject8[] soundItems8 = {new SoundObject8(nameList8.get(0), R.raw.pierce2), new SoundObject8(nameList8.get(1), R.raw.pierce3), new SoundObject8(nameList8.get(2), R.raw.pierce4), new SoundObject8(nameList8.get(3), R.raw.pierce5), new SoundObject8(nameList8.get(4), R.raw.pierce6), new SoundObject8(nameList8.get(5), R.raw.pierce7), new SoundObject8(nameList8.get(6), R.raw.pierce8), new SoundObject8(nameList8.get(7), R.raw.pierce9), new SoundObject8(nameList8.get(8), R.raw.pierce10), new SoundObject8(nameList8.get(9), R.raw.pierce11), new SoundObject8(nameList8.get(10), R.raw.pierce12), new SoundObject8(nameList8.get(11), R.raw.pierce13), new SoundObject8(nameList8.get(12), R.raw.pierce14), new SoundObject8(nameList8.get(13), R.raw.pierce15), new SoundObject8(nameList8.get(14), R.raw.pierce16), new SoundObject8(nameList8.get(15), R.raw.pierce17), new SoundObject8(nameList8.get(16), R.raw.pierce18), new SoundObject8(nameList8.get(17), R.raw.pierce19), new SoundObject8(nameList8.get(18), R.raw.pierce20), new SoundObject8(nameList8.get(19), R.raw.pierce21), new SoundObject8(nameList8.get(20), R.raw.pierce22), new SoundObject8(nameList8.get(21), R.raw.pierce23), new SoundObject8(nameList8.get(22), R.raw.pierce24), new SoundObject8(nameList8.get(23), R.raw.pierce25), new SoundObject8(nameList8.get(24), R.raw.pierce26), new SoundObject8(nameList8.get(25), R.raw.pierce27), new SoundObject8(nameList8.get(26), R.raw.pierce28), new SoundObject8(nameList8.get(27), R.raw.pierce29), new SoundObject8(nameList8.get(28), R.raw.pierce30), new SoundObject8(nameList8.get(29), R.raw.pierce31), new SoundObject8(nameList8.get(30), R.raw.pierce32), new SoundObject8(nameList8.get(31), R.raw.pierce33)  };

        soundList8.addAll(Arrays.asList(soundItems8));

        SoundView8 = findViewById(R.id.soundboardRecyclerView8);

        SoundLayoutManager8 = new GridLayoutManager(this, 3);

        SoundView8.setLayoutManager(SoundLayoutManager8);

        SoundView8.setAdapter(SoundAdapter8);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_pierce, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem menuItem)
    {
        if(menuItem.getItemId() == R.id.pierce_social){
            Intent intent = new Intent(Pierce.this, Pierce_Socials.class);
            startActivity(intent);
            return false;
        }
        //implement logic here to get selected item
        return super.onOptionsItemSelected(menuItem);
    }
}




