package tryhss.soundboardfinally.hsssoundboardmaybe.Streamerek;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import tryhss.soundboardfinally.hsssoundboardmaybe.JavaClassok.EventHandlerClass20;
import tryhss.soundboardfinally.hsssoundboardmaybe.JavaClassok.SoundObject20;
import tryhss.soundboardfinally.hsssoundboardmaybe.JavaClassok.SoundboardRecyclerAdapter20;
import tryhss.soundboardfinally.hsssoundboardmaybe.R;
import tryhss.soundboardfinally.hsssoundboardmaybe.Socials.PauluszSocials;

public class Paulusz extends AppCompatActivity {

    ArrayList<SoundObject20> soundList20 = new ArrayList<>();

    RecyclerView SoundView20;
    SoundboardRecyclerAdapter20 SoundAdapter20 = new SoundboardRecyclerAdapter20(soundList20);
    RecyclerView.LayoutManager SoundLayoutManager20;

    androidx.appcompat.widget.Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_paulusz);

        //-----------------AD-----------------------------

        MobileAds.initialize(this,"ca-app-pub-8890972768819102~6800754409");

        AdView ad = findViewById(R.id.ad_view_paulusz);
        AdView ad2 = findViewById(R.id.ad_view_paulusz_2);

        AdRequest adRequest = new AdRequest.Builder().build();
        ad.loadAd(adRequest);
        AdRequest adRequest2 = new AdRequest.Builder().build();
        ad2.loadAd(adRequest2);

        //------------------------------------------------------------

        toolbar = findViewById(R.id.toolbar_paulusz);
        setSupportActionBar(toolbar);
        toolbar.inflateMenu(R.menu.menu_paulusz);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        List<String> nameList20 = Arrays.asList(getResources().getStringArray(R.array.soundNames20));

        SoundObject20[] soundItems20 = {new SoundObject20(nameList20.get(0), R.raw.paulusz1), new SoundObject20(nameList20.get(1), R.raw.paulusz2), new SoundObject20(nameList20.get(2), R.raw.paulusz3), new SoundObject20(nameList20.get(3), R.raw.paulusz4), new SoundObject20(nameList20.get(4), R.raw.paulusz5), new SoundObject20(nameList20.get(5), R.raw.paulusz6), new SoundObject20(nameList20.get(6), R.raw.paulusz7), new SoundObject20(nameList20.get(7), R.raw.paulusz8), new SoundObject20(nameList20.get(8), R.raw.paulusz9), new SoundObject20(nameList20.get(9), R.raw.paulusz10), new SoundObject20(nameList20.get(10), R.raw.paulusz11), new SoundObject20(nameList20.get(11), R.raw.paulusz12), new SoundObject20(nameList20.get(12), R.raw.paulusz13), new SoundObject20(nameList20.get(13), R.raw.paulusz14), new SoundObject20(nameList20.get(14), R.raw.paulusz15), new SoundObject20(nameList20.get(15), R.raw.paulusz16), new SoundObject20(nameList20.get(16), R.raw.paulusz17), new SoundObject20(nameList20.get(17), R.raw.paulusz18), new SoundObject20(nameList20.get(18), R.raw.paulusz19), new SoundObject20(nameList20.get(19), R.raw.paulusz20), new SoundObject20(nameList20.get(20), R.raw.paulusz21) };
        soundList20.addAll(Arrays.asList(soundItems20));

        SoundView20 = findViewById(R.id.soundboardRecyclerView20);

        SoundLayoutManager20 = new GridLayoutManager(this, 3);

        SoundView20.setLayoutManager(SoundLayoutManager20);

        SoundView20.setAdapter(SoundAdapter20);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        EventHandlerClass20.releaseMediaPlayer20();
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_paulusz, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem menuItem)
    {
        if(menuItem.getItemId() == R.id.paulusz_social){
            Intent intent = new Intent(Paulusz.this, PauluszSocials.class);
            startActivity(intent);
            return false;
        }
        //implement logic here to get selected item
        return super.onOptionsItemSelected(menuItem);
    }
}


