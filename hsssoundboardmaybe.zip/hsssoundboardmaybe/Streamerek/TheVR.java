package tryhss.soundboardfinally.hsssoundboardmaybe.Streamerek;


import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import tryhss.soundboardfinally.hsssoundboardmaybe.JavaClassok.SoundObject5;
import tryhss.soundboardfinally.hsssoundboardmaybe.JavaClassok.SoundboardRecyclerAdapter5;
import tryhss.soundboardfinally.hsssoundboardmaybe.R;
import tryhss.soundboardfinally.hsssoundboardmaybe.Socials.TheVR_Socials;

public class TheVR extends AppCompatActivity {

    ArrayList<SoundObject5> soundList5 = new ArrayList<>();

    RecyclerView SoundView5;
    SoundboardRecyclerAdapter5 SoundAdapter5 = new SoundboardRecyclerAdapter5(soundList5);
    RecyclerView.LayoutManager SoundLayoutManager5;

    androidx.appcompat.widget.Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_thevr);

        //-----------------AD-----------------------------

        MobileAds.initialize(this,"ca-app-pub-8890972768819102~6800754409");

        AdView ad = findViewById(R.id.ad_view_thevr);
        AdView ad2 = findViewById(R.id.ad_view_thevr_2);

        AdRequest adRequest = new AdRequest.Builder().build();
        ad.loadAd(adRequest);

        AdRequest adRequest2 = new AdRequest.Builder().build();
        ad2.loadAd(adRequest2);

        //------------------------------------------------------------

        toolbar = findViewById(R.id.toolbar_thevr);
        setSupportActionBar(toolbar);
        toolbar.inflateMenu(R.menu.menu_thevr);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        List<String> nameList5 = Arrays.asList(getResources().getStringArray(R.array.soundNames5));

        SoundObject5[] soundItems5 = {new SoundObject5(nameList5.get(0), R.raw.vr2), new SoundObject5(nameList5.get(1), R.raw.vr3), new SoundObject5(nameList5.get(2), R.raw.vr4), new SoundObject5(nameList5.get(3), R.raw.vr5), new SoundObject5(nameList5.get(4), R.raw.vr6), new SoundObject5(nameList5.get(5), R.raw.vr7), new SoundObject5(nameList5.get(6), R.raw.vr8), new SoundObject5(nameList5.get(7), R.raw.vr9), new SoundObject5(nameList5.get(8), R.raw.vr10), new SoundObject5(nameList5.get(9), R.raw.vr11), new SoundObject5(nameList5.get(10), R.raw.vr12), new SoundObject5(nameList5.get(11), R.raw.vr13), new SoundObject5(nameList5.get(12), R.raw.vr14), new SoundObject5(nameList5.get(13), R.raw.vr15), new SoundObject5(nameList5.get(14), R.raw.vr16), new SoundObject5(nameList5.get(15), R.raw.vr17), new SoundObject5(nameList5.get(16), R.raw.vr18), new SoundObject5(nameList5.get(17), R.raw.vr19), new SoundObject5(nameList5.get(18), R.raw.vr20), new SoundObject5(nameList5.get(19), R.raw.vr21), new SoundObject5(nameList5.get(20), R.raw.vr22), new SoundObject5(nameList5.get(21), R.raw.vr23), new SoundObject5(nameList5.get(22), R.raw.vr24), new SoundObject5(nameList5.get(23), R.raw.vr25), new SoundObject5(nameList5.get(24), R.raw.vr26), new SoundObject5(nameList5.get(25), R.raw.vr27), new SoundObject5(nameList5.get(26), R.raw.vr28), new SoundObject5(nameList5.get(27), R.raw.vr29), new SoundObject5(nameList5.get(28), R.raw.vr30), new SoundObject5(nameList5.get(29), R.raw.vr31), new SoundObject5(nameList5.get(30), R.raw.vr32), new SoundObject5(nameList5.get(31), R.raw.vr33), new SoundObject5(nameList5.get(32), R.raw.vr34), new SoundObject5(nameList5.get(33), R.raw.vr35), new SoundObject5(nameList5.get(34), R.raw.vr36), new SoundObject5(nameList5.get(35), R.raw.vr1), new SoundObject5(nameList5.get(36), R.raw.thevr37), new SoundObject5(nameList5.get(37), R.raw.vr38), new SoundObject5(nameList5.get(38), R.raw.vr39), new SoundObject5(nameList5.get(39), R.raw.vr40), new SoundObject5(nameList5.get(40), R.raw.vr41), new SoundObject5(nameList5.get(41), R.raw.vr42), new SoundObject5(nameList5.get(42), R.raw.vr43), new SoundObject5(nameList5.get(43), R.raw.vr44), new SoundObject5(nameList5.get(44), R.raw.vr45), new SoundObject5(nameList5.get(45), R.raw.vr46), new SoundObject5(nameList5.get(46), R.raw.vr47), new SoundObject5(nameList5.get(47), R.raw.vr48), new SoundObject5(nameList5.get(48), R.raw.vr49), new SoundObject5(nameList5.get(49), R.raw.vr50), new SoundObject5(nameList5.get(50), R.raw.vr51), new SoundObject5(nameList5.get(51), R.raw.vr52), new SoundObject5(nameList5.get(52), R.raw.vr53), new SoundObject5(nameList5.get(53), R.raw.vr54), new SoundObject5(nameList5.get(54), R.raw.vr55) , new SoundObject5(nameList5.get(55), R.raw.vr56), new SoundObject5(nameList5.get(56), R.raw.vr57), new SoundObject5(nameList5.get(57), R.raw.vr58), new SoundObject5(nameList5.get(58), R.raw.vr59), new SoundObject5(nameList5.get(59), R.raw.vr60), new SoundObject5(nameList5.get(60), R.raw.vr61) };

        soundList5.addAll(Arrays.asList(soundItems5));

        SoundView5 = findViewById(R.id.soundboardRecyclerView5);

        SoundLayoutManager5 = new GridLayoutManager(this, 4);

        SoundView5.setLayoutManager(SoundLayoutManager5);
        
        SoundView5.setAdapter(SoundAdapter5);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_thevr, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem menuItem)
    {
        if(menuItem.getItemId() == R.id.thevr_social){
            Intent intent = new Intent(TheVR.this, TheVR_Socials.class);
            startActivity(intent);
            return false;
        }
        //implement logic here to get selected item
        return super.onOptionsItemSelected(menuItem);
    }
}

