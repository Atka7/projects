package tryhss.soundboardfinally.hsssoundboardmaybe.Streamerek;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import tryhss.soundboardfinally.hsssoundboardmaybe.JavaClassok.EventHandlerClass3;
import tryhss.soundboardfinally.hsssoundboardmaybe.JavaClassok.SoundObject3;
import tryhss.soundboardfinally.hsssoundboardmaybe.JavaClassok.SoundboardRecyclerAdapter3;
import tryhss.soundboardfinally.hsssoundboardmaybe.R;
import tryhss.soundboardfinally.hsssoundboardmaybe.Socials.Nerdhub_Socials;

public class Nerdhub extends AppCompatActivity {

    ArrayList<SoundObject3> soundList3 = new ArrayList<>();

    RecyclerView SoundView3;
    SoundboardRecyclerAdapter3 SoundAdapter3 = new SoundboardRecyclerAdapter3(soundList3);
    RecyclerView.LayoutManager SoundLayoutManager3;

    androidx.appcompat.widget.Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nerdhub);

        //-----------------AD-----------------------------

        MobileAds.initialize(this,"ca-app-pub-8890972768819102~6800754409");

        AdView ad = findViewById(R.id.ad_view_nerdhub);
        AdView ad2 = findViewById(R.id.ad_view_nerdhub_2);

        AdRequest adRequest = new AdRequest.Builder().build();
        ad.loadAd(adRequest);

        AdRequest adRequest2 = new AdRequest.Builder().build();
        ad2.loadAd(adRequest2);

        //------------------------------------------------------------

        toolbar = findViewById(R.id.toolbar_nerdhub);
        setSupportActionBar(toolbar);
        toolbar.inflateMenu(R.menu.menu_nerdhub);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        List<String> nameList3 = Arrays.asList(getResources().getStringArray(R.array.soundNames3));

        SoundObject3[] soundItems3 = {new SoundObject3(nameList3.get(0), R.raw.nh2), new SoundObject3(nameList3.get(1), R.raw.nh3), new SoundObject3(nameList3.get(2), R.raw.nh4), new SoundObject3(nameList3.get(3), R.raw.nh5), new SoundObject3(nameList3.get(4), R.raw.nh6), new SoundObject3(nameList3.get(5), R.raw.nh7), new SoundObject3(nameList3.get(6), R.raw.nh8), new SoundObject3(nameList3.get(7), R.raw.nh9), new SoundObject3(nameList3.get(8), R.raw.nh10), new SoundObject3(nameList3.get(9), R.raw.nh11), new SoundObject3(nameList3.get(10), R.raw.nh12), new SoundObject3(nameList3.get(11), R.raw.nh13), new SoundObject3(nameList3.get(12), R.raw.nh14), new SoundObject3(nameList3.get(13), R.raw.nh15), new SoundObject3(nameList3.get(14), R.raw.nh16), new SoundObject3(nameList3.get(15), R.raw.nh17), new SoundObject3(nameList3.get(16), R.raw.nh18), new SoundObject3(nameList3.get(17), R.raw.nh19), new SoundObject3(nameList3.get(18), R.raw.nh20), new SoundObject3(nameList3.get(19), R.raw.nh21), new SoundObject3(nameList3.get(20), R.raw.nh22), new SoundObject3(nameList3.get(21), R.raw.nh23), new SoundObject3(nameList3.get(22), R.raw.nh24), new SoundObject3(nameList3.get(23), R.raw.nh25), new SoundObject3(nameList3.get(24), R.raw.nh31), new SoundObject3(nameList3.get(25), R.raw.nh28), new SoundObject3(nameList3.get(26), R.raw.nh29), new SoundObject3(nameList3.get(27), R.raw.nh30), new SoundObject3(nameList3.get(28), R.raw.nh32), new SoundObject3(nameList3.get(29), R.raw.nh33), new SoundObject3(nameList3.get(30), R.raw.nh34), new SoundObject3(nameList3.get(31), R.raw.nh35), new SoundObject3(nameList3.get(32), R.raw.nh36), new SoundObject3(nameList3.get(33), R.raw.nh37), new SoundObject3(nameList3.get(34), R.raw.nh38), new SoundObject3(nameList3.get(35), R.raw.nh39), new SoundObject3(nameList3.get(36), R.raw.nh40), new SoundObject3(nameList3.get(37), R.raw.nh41), new SoundObject3(nameList3.get(38), R.raw.nh42), new SoundObject3(nameList3.get(39), R.raw.nh43), new SoundObject3(nameList3.get(40), R.raw.nh44), new SoundObject3(nameList3.get(41), R.raw.nh45), new SoundObject3(nameList3.get(42), R.raw.nh46), new SoundObject3(nameList3.get(43), R.raw.nh47), new SoundObject3(nameList3.get(44), R.raw.nh48)  };

        soundList3.addAll(Arrays.asList(soundItems3));

        SoundView3 = findViewById(R.id.soundboardRecyclerView3);

        SoundLayoutManager3 = new GridLayoutManager(this, 3);

        SoundView3.setLayoutManager(SoundLayoutManager3);

        SoundView3.setAdapter(SoundAdapter3);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        EventHandlerClass3.releaseMediaPlayer3();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_nerdhub, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem menuItem)
    {
        if(menuItem.getItemId() == R.id.nerdhub_social){
            Intent intent = new Intent(Nerdhub.this, Nerdhub_Socials.class);
            startActivity(intent);
            return false;
        }
        //implement logic here to get selected item
        return super.onOptionsItemSelected(menuItem);
    }
}


