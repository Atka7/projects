package tryhss.soundboardfinally.hsssoundboardmaybe.Streamerek;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import tryhss.soundboardfinally.hsssoundboardmaybe.JavaClassok.EventHandlerClass11;
import tryhss.soundboardfinally.hsssoundboardmaybe.JavaClassok.SoundObject11;
import tryhss.soundboardfinally.hsssoundboardmaybe.JavaClassok.SoundboardRecyclerAdapter11;
import tryhss.soundboardfinally.hsssoundboardmaybe.R;
import tryhss.soundboardfinally.hsssoundboardmaybe.Socials.AvidisOddSocials;

public class AvidisOdd extends AppCompatActivity {

    ArrayList<SoundObject11> soundList11 = new ArrayList<>();

    RecyclerView SoundView11;
    SoundboardRecyclerAdapter11 SoundAdapter11 = new SoundboardRecyclerAdapter11(soundList11);
    RecyclerView.LayoutManager SoundLayoutManager11;

    androidx.appcompat.widget.Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_avidis_odd);

        //-----------------AD-----------------------------

        MobileAds.initialize(this,"ca-app-pub-8890972768819102~6800754409");

        AdView ad = findViewById(R.id.ad_view_avidisodd);
        AdView ad2 = findViewById(R.id.ad_view_avidisodd_2);

        AdRequest adRequest = new AdRequest.Builder().build();
        ad.loadAd(adRequest);
        AdRequest adRequest2 = new AdRequest.Builder().build();
        ad2.loadAd(adRequest2);

        //------------------------------------------------------------

        toolbar = findViewById(R.id.toolbar_avidisodd);
        setSupportActionBar(toolbar);
        toolbar.inflateMenu(R.menu.menu_avidisodd);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        List<String> nameList11 = Arrays.asList(getResources().getStringArray(R.array.soundNames11));

        SoundObject11[] soundItems11 = {new SoundObject11(nameList11.get(0), R.raw.avid1), new SoundObject11(nameList11.get(1), R.raw.avid2), new SoundObject11(nameList11.get(2), R.raw.avid3), new SoundObject11(nameList11.get(3), R.raw.avid4), new SoundObject11(nameList11.get(4), R.raw.avid5), new SoundObject11(nameList11.get(5), R.raw.avid6), new SoundObject11(nameList11.get(6), R.raw.avid7), new SoundObject11(nameList11.get(7), R.raw.avid8), new SoundObject11(nameList11.get(8), R.raw.avid9), new SoundObject11(nameList11.get(9), R.raw.avid10), new SoundObject11(nameList11.get(10), R.raw.avid11), new SoundObject11(nameList11.get(11), R.raw.avid12), new SoundObject11(nameList11.get(12), R.raw.avid13), new SoundObject11(nameList11.get(13), R.raw.avid14), new SoundObject11(nameList11.get(14), R.raw.avid15), new SoundObject11(nameList11.get(15), R.raw.avid16), new SoundObject11(nameList11.get(16), R.raw.avid17), new SoundObject11(nameList11.get(17), R.raw.avid18), new SoundObject11(nameList11.get(18), R.raw.avid19), new SoundObject11(nameList11.get(19), R.raw.avid20), new SoundObject11(nameList11.get(20), R.raw.avid21), new SoundObject11(nameList11.get(21), R.raw.avid22), new SoundObject11(nameList11.get(22), R.raw.avid23) };
        soundList11.addAll(Arrays.asList(soundItems11));

        SoundView11 = findViewById(R.id.soundboardRecyclerView11);

        SoundLayoutManager11 = new GridLayoutManager(this, 3);

        SoundView11.setLayoutManager(SoundLayoutManager11);

        SoundView11.setAdapter(SoundAdapter11);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        EventHandlerClass11.releaseMediaPlayer11();
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_avidisodd, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem menuItem)
    {
        if(menuItem.getItemId() == R.id.avidisodd_social){
            Intent intent = new Intent(AvidisOdd.this, AvidisOddSocials.class);
            startActivity(intent);
            return false;
        }
        //implement logic here to get selected item
        return super.onOptionsItemSelected(menuItem);
    }
}


