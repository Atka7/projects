package tryhss.soundboardfinally.hsssoundboardmaybe.SlotActivity;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import tryhss.soundboardfinally.hsssoundboardmaybe.R;

public class Nerdhub_Slot extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nerdhub__sub);
    }
}
