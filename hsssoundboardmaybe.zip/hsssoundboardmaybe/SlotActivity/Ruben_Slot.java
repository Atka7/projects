package tryhss.soundboardfinally.hsssoundboardmaybe.SlotActivity;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.ads.MobileAds;

import tryhss.soundboardfinally.hsssoundboardmaybe.R;

public class Ruben_Slot extends AppCompatActivity {

    androidx.appcompat.widget.Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ruben_slot);

        toolbar = findViewById(R.id.toolbar_ruben_slot);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        //-----------------AD-----------------------------

        MobileAds.initialize(this, "ca-app-pub-8890972768819102~6800754409");





        //------------------------------------------------------------


    }
}
