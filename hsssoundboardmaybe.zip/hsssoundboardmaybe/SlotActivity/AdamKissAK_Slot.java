package tryhss.soundboardfinally.hsssoundboardmaybe.SlotActivity;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import tryhss.soundboardfinally.hsssoundboardmaybe.R;

public class AdamKissAK_Slot extends AppCompatActivity {

    androidx.appcompat.widget.Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_adamkissak_sub);

        toolbar = (androidx.appcompat.widget.Toolbar) findViewById(R.id.toolbar_adamkissak_sub);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

    }
}
