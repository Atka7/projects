package tryhss.soundboardfinally.hsssoundboardmaybe.JavaClassok;

public class SoundObject12 {
    private String itemName12;
    private Integer itemID12;

    public SoundObject12(String itemName12, Integer itemID12){

        this.itemName12 = itemName12;
        this.itemID12 = itemID12;
    }


    public String getItemName12(){

        return itemName12;
    }

    public  Integer getItemID12(){

        return itemID12;
    }
}
