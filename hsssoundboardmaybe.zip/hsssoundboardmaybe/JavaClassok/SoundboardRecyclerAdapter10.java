package tryhss.soundboardfinally.hsssoundboardmaybe.JavaClassok;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

import tryhss.soundboardfinally.hsssoundboardmaybe.R;

public class SoundboardRecyclerAdapter10 extends RecyclerView.Adapter<SoundboardRecyclerAdapter10.SoundboardViewHolder> {
    private ArrayList<SoundObject10> soundObjects10;

    public SoundboardRecyclerAdapter10(ArrayList<SoundObject10> soundObjects10){

        this.soundObjects10 = soundObjects10;
    }

    @Override
    public SoundboardRecyclerAdapter10.SoundboardViewHolder onCreateViewHolder(ViewGroup parent, int viewType){
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.sound_item10, null);
        return new SoundboardViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull SoundboardRecyclerAdapter10.SoundboardViewHolder holder, int position) {

        final SoundObject10 object10 = soundObjects10.get(position);
        final Integer soundID10 = object10.getItemID10();



        holder.itemTextView10.setText(object10.getItemName10());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                EventHandlerClass10.startMediaPlayer10(view, soundID10);

            }
        });

        holder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {

                EventHandlerClass10.popupManager(view, object10);

                return true;
            }
        });

    }

    @Override
    public int getItemCount() {
        return soundObjects10.size();
    }

    public class  SoundboardViewHolder extends RecyclerView.ViewHolder{
        TextView itemTextView10;
        public  SoundboardViewHolder(View itemView){
            super(itemView);

            itemTextView10 = (TextView) itemView.findViewById(R.id.textViewItem10);
        }
    }


}