package tryhss.soundboardfinally.hsssoundboardmaybe.JavaClassok;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

import tryhss.soundboardfinally.hsssoundboardmaybe.R;

public class SoundboardRecyclerAdapter18 extends RecyclerView.Adapter<SoundboardRecyclerAdapter18.SoundboardViewHolder>{

    private ArrayList<SoundObject18> soundObjects18;

    public SoundboardRecyclerAdapter18(ArrayList<SoundObject18> soundObjects18){

        this.soundObjects18 = soundObjects18;
    }

    @Override
    public SoundboardViewHolder onCreateViewHolder(ViewGroup parent, int viewType){
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.sound_item18, null);
        return new SoundboardViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull SoundboardRecyclerAdapter18.SoundboardViewHolder holder, int position) {

        final SoundObject18 object18 = soundObjects18.get(position);
        final Integer soundID18 = object18.getItemID18();



        holder.itemTextView.setText(object18.getItemName18());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                EventHandlerClass18.startMediaPlayer18(view, soundID18);

            }
        });

        holder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {

                EventHandlerClass18.popupManager(view, object18);

                return true;
            }
        });

    }

    @Override
    public int getItemCount() {
        return soundObjects18.size();
    }

    public class  SoundboardViewHolder extends RecyclerView.ViewHolder{
        TextView itemTextView;
        public  SoundboardViewHolder(View itemView){
            super(itemView);

            itemTextView = (TextView) itemView.findViewById(R.id.textViewItem18);
        }
    }


}


