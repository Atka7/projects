package tryhss.soundboardfinally.hsssoundboardmaybe.JavaClassok;

public class SoundObject17 {

    private String itemName17;
    private Integer itemID17;

    public SoundObject17(String itemName17, Integer itemID17){

        this.itemName17 = itemName17;
        this.itemID17 = itemID17;
    }


    public String getItemName17(){

        return itemName17;
    }

    public  Integer getItemID17(){

        return itemID17;
    }
}

