package tryhss.soundboardfinally.hsssoundboardmaybe.JavaClassok;

public class SoundObject6 {
    private String itemName6;
    private Integer itemID6;

    public SoundObject6(String itemName6, Integer itemID6){

        this.itemName6 = itemName6;
        this.itemID6 = itemID6;
    }


    public String getItemName6(){

        return itemName6;
    }

    public  Integer getItemID6(){

        return itemID6;
    }
}
