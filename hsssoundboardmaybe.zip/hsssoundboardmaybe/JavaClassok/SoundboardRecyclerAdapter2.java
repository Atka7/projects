package tryhss.soundboardfinally.hsssoundboardmaybe.JavaClassok;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

import tryhss.soundboardfinally.hsssoundboardmaybe.R;

public class SoundboardRecyclerAdapter2 extends RecyclerView.Adapter<SoundboardRecyclerAdapter2.SoundboardViewHolder>{

    private ArrayList<SoundObject2> soundObjects2;

    public SoundboardRecyclerAdapter2(ArrayList<SoundObject2> soundObjects2){

        this.soundObjects2 = soundObjects2;
    }

    @Override
    public SoundboardViewHolder onCreateViewHolder(ViewGroup parent, int viewType){
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.sound_item2, null);
        return new SoundboardViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull SoundboardRecyclerAdapter2.SoundboardViewHolder holder, int position) {

        final SoundObject2 object2 = soundObjects2.get(position);
        final Integer soundID2 = object2.getItemID2();



        holder.itemTextView.setText(object2.getItemName2());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                EventHandlerClass2.startMediaPlayer2(view, soundID2);

            }
        });

        holder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {

                EventHandlerClass2.popupManager(view, object2);

                return true;
            }
        });

    }

    @Override
    public int getItemCount() {
        return soundObjects2.size();
    }

    public class  SoundboardViewHolder extends RecyclerView.ViewHolder{
        TextView itemTextView;
        public  SoundboardViewHolder(View itemView){
            super(itemView);

            itemTextView = (TextView) itemView.findViewById(R.id.textViewItem2);
        }
    }


}


