package tryhss.soundboardfinally.hsssoundboardmaybe.JavaClassok;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

import tryhss.soundboardfinally.hsssoundboardmaybe.R;

public class SoundboardRecyclerAdapter23 extends RecyclerView.Adapter<SoundboardRecyclerAdapter23.SoundboardViewHolder>{

    private ArrayList<SoundObject23> soundObjects23;

    public SoundboardRecyclerAdapter23(ArrayList<SoundObject23> soundObjects23){

        this.soundObjects23 = soundObjects23;
    }

    @Override
    public SoundboardViewHolder onCreateViewHolder(ViewGroup parent, int viewType){
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.sound_item23, null);
        return new SoundboardViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull SoundboardRecyclerAdapter23.SoundboardViewHolder holder, int position) {

        final SoundObject23 object23 = soundObjects23.get(position);
        final Integer soundID23 = object23.getItemID23();



        holder.itemTextView.setText(object23.getItemName23());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                EventHandlerClass23.startMediaPlayer23(view, soundID23);

            }
        });

        holder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {

                EventHandlerClass23.popupManager(view, object23);

                return true;
            }
        });

    }

    @Override
    public int getItemCount() {
        return soundObjects23.size();
    }

    public class  SoundboardViewHolder extends RecyclerView.ViewHolder{
        TextView itemTextView;
        public  SoundboardViewHolder(View itemView){
            super(itemView);

            itemTextView = (TextView) itemView.findViewById(R.id.textViewItem23);
        }
    }


}


