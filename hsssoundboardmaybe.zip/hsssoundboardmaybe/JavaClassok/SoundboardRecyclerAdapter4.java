package tryhss.soundboardfinally.hsssoundboardmaybe.JavaClassok;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

import tryhss.soundboardfinally.hsssoundboardmaybe.R;

public class SoundboardRecyclerAdapter4 extends RecyclerView.Adapter<SoundboardRecyclerAdapter4.SoundboardViewHolder> {
    private ArrayList<SoundObject4> soundObjects4;

    public SoundboardRecyclerAdapter4(ArrayList<SoundObject4> soundObjects4){

        this.soundObjects4 = soundObjects4;
    }

    @Override
    public SoundboardRecyclerAdapter4.SoundboardViewHolder onCreateViewHolder(ViewGroup parent, int viewType){
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.sound_item4, null);
        return new SoundboardViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull SoundboardRecyclerAdapter4.SoundboardViewHolder holder, int position) {

        final SoundObject4 object4 = soundObjects4.get(position);
        final Integer soundID4 = object4.getItemID4();



        holder.itemTextView4.setText(object4.getItemName4());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                EventHandlerClass4.startMediaPlayer4(view, soundID4);

            }
        });

        holder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {

                EventHandlerClass4.popupManager(view, object4);

                return true;
            }
        });

    }

    @Override
    public int getItemCount() {
        return soundObjects4.size();
    }

    public class  SoundboardViewHolder extends RecyclerView.ViewHolder{
        TextView itemTextView4;
        public  SoundboardViewHolder(View itemView){
            super(itemView);

            itemTextView4 = (TextView) itemView.findViewById(R.id.textViewItem4);
        }
    }


}




