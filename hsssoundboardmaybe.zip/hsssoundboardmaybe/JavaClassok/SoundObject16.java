package tryhss.soundboardfinally.hsssoundboardmaybe.JavaClassok;

public class SoundObject16 {

    private String itemName16;
    private Integer itemID16;

    public SoundObject16(String itemName16, Integer itemID16){

        this.itemName16 = itemName16;
        this.itemID16 = itemID16;
    }


    public String getItemName16(){

        return itemName16;
    }

    public  Integer getItemID16(){

        return itemID16;
    }
}

