package tryhss.soundboardfinally.hsssoundboardmaybe.JavaClassok;

public class SoundObject8 {
    private String itemName8;
    private Integer itemID8;

    public SoundObject8(String itemName8, Integer itemID8){

        this.itemName8 = itemName8;
        this.itemID8 = itemID8;
    }


    public String getItemName8(){

        return itemName8;
    }

    public  Integer getItemID8(){

        return itemID8;
    }
}
