package tryhss.soundboardfinally.hsssoundboardmaybe.JavaClassok;

public class SoundObject24 {

    private String itemName24;
    private Integer itemID24;

    public SoundObject24(String itemName24, Integer itemID24){

        this.itemName24 = itemName24;
        this.itemID24 = itemID24;
    }


    public String getItemName24(){

        return itemName24;
    }

    public  Integer getItemID24(){

        return itemID24;
    }
}

