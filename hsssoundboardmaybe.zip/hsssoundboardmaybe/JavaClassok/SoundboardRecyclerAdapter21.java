package tryhss.soundboardfinally.hsssoundboardmaybe.JavaClassok;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

import tryhss.soundboardfinally.hsssoundboardmaybe.R;

public class SoundboardRecyclerAdapter21 extends RecyclerView.Adapter<SoundboardRecyclerAdapter21.SoundboardViewHolder>{

    private ArrayList<SoundObject21> soundObjects21;

    public SoundboardRecyclerAdapter21(ArrayList<SoundObject21> soundObjects21){

        this.soundObjects21 = soundObjects21;
    }

    @Override
    public SoundboardViewHolder onCreateViewHolder(ViewGroup parent, int viewType){
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.sound_item21, null);
        return new SoundboardViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull SoundboardRecyclerAdapter21.SoundboardViewHolder holder, int position) {

        final SoundObject21 object21 = soundObjects21.get(position);
        final Integer soundID21 = object21.getItemID21();



        holder.itemTextView.setText(object21.getItemName21());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                EventHandlerClass21.startMediaPlayer21(view, soundID21);

            }
        });

        holder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {

                EventHandlerClass21.popupManager(view, object21);

                return true;
            }
        });

    }

    @Override
    public int getItemCount() {
        return soundObjects21.size();
    }

    public class  SoundboardViewHolder extends RecyclerView.ViewHolder{
        TextView itemTextView;
        public  SoundboardViewHolder(View itemView){
            super(itemView);

            itemTextView = (TextView) itemView.findViewById(R.id.textViewItem21);
        }
    }


}


