package tryhss.soundboardfinally.hsssoundboardmaybe.JavaClassok;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

import tryhss.soundboardfinally.hsssoundboardmaybe.R;

public class SoundboardRecyclerAdapter5 extends RecyclerView.Adapter<SoundboardRecyclerAdapter5.SoundboardViewHolder> {
    private ArrayList<SoundObject5> soundObjects5;

    public SoundboardRecyclerAdapter5(ArrayList<SoundObject5> soundObjects5){

        this.soundObjects5 = soundObjects5;
    }

    @Override
    public SoundboardRecyclerAdapter5.SoundboardViewHolder onCreateViewHolder(ViewGroup parent, int viewType){
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.sound_item5, null);
        return new SoundboardViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull SoundboardRecyclerAdapter5.SoundboardViewHolder holder, int position) {

        final SoundObject5 object5 = soundObjects5.get(position);
        final Integer soundID5 = object5.getItemID5();



        holder.itemTextView5.setText(object5.getItemName5());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                EventHandlerClass5.startMediaPlayer5(view, soundID5);

            }
        });

        holder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {

                EventHandlerClass5.popupManager(view, object5);

                return true;
            }
        });

    }

    @Override
    public int getItemCount() {
        return soundObjects5.size();
    }

    public class  SoundboardViewHolder extends RecyclerView.ViewHolder{
        TextView itemTextView5;
        public  SoundboardViewHolder(View itemView){
            super(itemView);

            itemTextView5 = (TextView) itemView.findViewById(R.id.textViewItem5);
        }
    }


}
