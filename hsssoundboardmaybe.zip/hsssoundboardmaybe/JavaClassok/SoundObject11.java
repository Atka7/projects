package tryhss.soundboardfinally.hsssoundboardmaybe.JavaClassok;

public class SoundObject11 {
    private String itemName11;
    private Integer itemID11;

    public SoundObject11(String itemName11, Integer itemID11){

        this.itemName11 = itemName11;
        this.itemID11 = itemID11;
    }


    public String getItemName11(){

        return itemName11;
    }

    public  Integer getItemID11(){

        return itemID11;
    }
}
