package tryhss.soundboardfinally.hsssoundboardmaybe.JavaClassok;

public class SoundObject4 {
    private String itemName4;
    private Integer itemID4;

    public SoundObject4(String itemName4, Integer itemID4){

        this.itemName4 = itemName4;
        this.itemID4 = itemID4;
    }


    public String getItemName4(){

        return itemName4;
    }

    public  Integer getItemID4(){

        return itemID4;
    }
}
