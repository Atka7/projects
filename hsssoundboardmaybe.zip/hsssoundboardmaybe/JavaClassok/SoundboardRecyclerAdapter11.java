package tryhss.soundboardfinally.hsssoundboardmaybe.JavaClassok;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

import tryhss.soundboardfinally.hsssoundboardmaybe.R;

public class SoundboardRecyclerAdapter11 extends RecyclerView.Adapter<SoundboardRecyclerAdapter11.SoundboardViewHolder> {
    private ArrayList<SoundObject11> soundObjects11;

    public SoundboardRecyclerAdapter11(ArrayList<SoundObject11> soundObjects11){

        this.soundObjects11 = soundObjects11;
    }

    @Override
    public SoundboardRecyclerAdapter11.SoundboardViewHolder onCreateViewHolder(ViewGroup parent, int viewType){
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.sound_item11, null);
        return new SoundboardViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull SoundboardRecyclerAdapter11.SoundboardViewHolder holder, int position) {

        final SoundObject11 object11 = soundObjects11.get(position);
        final Integer soundID11 = object11.getItemID11();



        holder.itemTextView11.setText(object11.getItemName11());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                EventHandlerClass11.startMediaPlayer11(view, soundID11);

            }
        });

        holder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {

                EventHandlerClass11.popupManager(view, object11);

                return true;
            }
        });

    }

    @Override
    public int getItemCount() {
        return soundObjects11.size();
    }

    public class  SoundboardViewHolder extends RecyclerView.ViewHolder{
        TextView itemTextView11;
        public  SoundboardViewHolder(View itemView){
            super(itemView);

            itemTextView11 = (TextView) itemView.findViewById(R.id.textViewItem11);
        }
    }


}