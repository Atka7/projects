package tryhss.soundboardfinally.hsssoundboardmaybe.JavaClassok;

public class SoundObject7 {
    private String itemName7;
    private Integer itemID7;

    public SoundObject7(String itemName7, Integer itemID7){

        this.itemName7 = itemName7;
        this.itemID7 = itemID7;
    }


    public String getItemName7(){

        return itemName7;
    }

    public  Integer getItemID7(){

        return itemID7;
    }
}