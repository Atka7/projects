package tryhss.soundboardfinally.hsssoundboardmaybe.JavaClassok;

public class SoundObject23 {

    private String itemName23;
    private Integer itemID23;

    public SoundObject23(String itemName23, Integer itemID23){

        this.itemName23 = itemName23;
        this.itemID23 = itemID23;
    }


    public String getItemName23(){

        return itemName23;
    }

    public  Integer getItemID23(){

        return itemID23;
    }
}

