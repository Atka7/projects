package tryhss.soundboardfinally.hsssoundboardmaybe.JavaClassok;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

import tryhss.soundboardfinally.hsssoundboardmaybe.R;

public class SoundboardRecyclerAdapter7 extends RecyclerView.Adapter<SoundboardRecyclerAdapter7.SoundboardViewHolder> {
    private ArrayList<SoundObject7> soundObjects7;

    public SoundboardRecyclerAdapter7(ArrayList<SoundObject7> soundObjects7){

        this.soundObjects7 = soundObjects7;
    }

    @Override
    public SoundboardRecyclerAdapter7.SoundboardViewHolder onCreateViewHolder(ViewGroup parent, int viewType){
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.sound_item7, null);
        return new SoundboardViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull SoundboardRecyclerAdapter7.SoundboardViewHolder holder, int position) {

        final SoundObject7 object7 = soundObjects7.get(position);
        final Integer soundID7 = object7.getItemID7();



        holder.itemTextView7.setText(object7.getItemName7());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                EventHandlerClass7.startMediaPlayer7(view, soundID7);

            }
        });

        holder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {

                EventHandlerClass7.popupManager(view, object7);

                return true;
            }
        });

    }

    @Override
    public int getItemCount() {
        return soundObjects7.size();
    }

    public class  SoundboardViewHolder extends RecyclerView.ViewHolder{
        TextView itemTextView7;
        public  SoundboardViewHolder(View itemView){
            super(itemView);

            itemTextView7 = (TextView) itemView.findViewById(R.id.textViewItem7);
        }
    }


}
