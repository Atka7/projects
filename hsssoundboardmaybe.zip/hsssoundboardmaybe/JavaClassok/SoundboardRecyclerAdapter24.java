package tryhss.soundboardfinally.hsssoundboardmaybe.JavaClassok;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

import tryhss.soundboardfinally.hsssoundboardmaybe.R;

public class SoundboardRecyclerAdapter24 extends RecyclerView.Adapter<SoundboardRecyclerAdapter24.SoundboardViewHolder>{

    private ArrayList<SoundObject24> soundObjects24;

    public SoundboardRecyclerAdapter24(ArrayList<SoundObject24> soundObjects24){

        this.soundObjects24 = soundObjects24;
    }

    @Override
    public SoundboardViewHolder onCreateViewHolder(ViewGroup parent, int viewType){
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.sound_item24, null);
        return new SoundboardViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull SoundboardRecyclerAdapter24.SoundboardViewHolder holder, int position) {

        final SoundObject24 object24 = soundObjects24.get(position);
        final Integer soundID24 = object24.getItemID24();



        holder.itemTextView.setText(object24.getItemName24());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                EventHandlerClass24.startMediaPlayer24(view, soundID24);

            }
        });

        holder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {

                EventHandlerClass24.popupManager(view, object24);

                return true;
            }
        });

    }

    @Override
    public int getItemCount() {
        return soundObjects24.size();
    }

    public class  SoundboardViewHolder extends RecyclerView.ViewHolder{
        TextView itemTextView;
        public  SoundboardViewHolder(View itemView){
            super(itemView);

            itemTextView = (TextView) itemView.findViewById(R.id.textViewItem24);
        }
    }


}


