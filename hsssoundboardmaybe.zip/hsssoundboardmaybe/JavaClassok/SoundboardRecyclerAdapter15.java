package tryhss.soundboardfinally.hsssoundboardmaybe.JavaClassok;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

import tryhss.soundboardfinally.hsssoundboardmaybe.R;

public class SoundboardRecyclerAdapter15 extends RecyclerView.Adapter<SoundboardRecyclerAdapter15.SoundboardViewHolder>{

    private ArrayList<SoundObject15> soundObjects15;

    public SoundboardRecyclerAdapter15(ArrayList<SoundObject15> soundObjects15){

        this.soundObjects15 = soundObjects15;
    }

    @Override
    public SoundboardViewHolder onCreateViewHolder(ViewGroup parent, int viewType){
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.sound_item15, null);
        return new SoundboardViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull SoundboardRecyclerAdapter15.SoundboardViewHolder holder, int position) {

        final SoundObject15 object15 = soundObjects15.get(position);
        final Integer soundID15 = object15.getItemID15();



        holder.itemTextView.setText(object15.getItemName15());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                EventHandlerClass15.startMediaPlayer15(view, soundID15);

            }
        });

        holder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {

                EventHandlerClass15.popupManager(view, object15);

                return true;
            }
        });

    }

    @Override
    public int getItemCount() {
        return soundObjects15.size();
    }

    public class  SoundboardViewHolder extends RecyclerView.ViewHolder{
        TextView itemTextView;
        public  SoundboardViewHolder(View itemView){
            super(itemView);

            itemTextView = (TextView) itemView.findViewById(R.id.textViewItem15);
        }
    }


}


