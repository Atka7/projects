package tryhss.soundboardfinally.hsssoundboardmaybe.JavaClassok;

public class SoundObject2 {

    private String itemName2;
    private Integer itemID2;

    public SoundObject2(String itemName2, Integer itemID2){

        this.itemName2 = itemName2;
        this.itemID2 = itemID2;
    }


    public String getItemName2(){

        return itemName2;
    }

    public  Integer getItemID2(){

        return itemID2;
    }
}

