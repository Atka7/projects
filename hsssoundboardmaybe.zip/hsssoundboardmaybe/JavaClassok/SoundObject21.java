package tryhss.soundboardfinally.hsssoundboardmaybe.JavaClassok;

public class SoundObject21 {

    private String itemName21;
    private Integer itemID21;

    public SoundObject21(String itemName21, Integer itemID21){

        this.itemName21 = itemName21;
        this.itemID21 = itemID21;
    }


    public String getItemName21(){

        return itemName21;
    }

    public  Integer getItemID21(){

        return itemID21;
    }
}

