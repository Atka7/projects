package tryhss.soundboardfinally.hsssoundboardmaybe.JavaClassok;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

import tryhss.soundboardfinally.hsssoundboardmaybe.R;

public class SoundboardRecyclerAdapter19 extends RecyclerView.Adapter<SoundboardRecyclerAdapter19.SoundboardViewHolder>{

    private ArrayList<SoundObject19> soundObjects19;

    public SoundboardRecyclerAdapter19(ArrayList<SoundObject19> soundObjects19){

        this.soundObjects19 = soundObjects19;
    }

    @Override
    public SoundboardViewHolder onCreateViewHolder(ViewGroup parent, int viewType){
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.sound_item19, null);
        return new SoundboardViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull SoundboardRecyclerAdapter19.SoundboardViewHolder holder, int position) {

        final SoundObject19 object19 = soundObjects19.get(position);
        final Integer soundID19 = object19.getItemID19();



        holder.itemTextView.setText(object19.getItemName19());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                EventHandlerClass19.startMediaPlayer19(view, soundID19);

            }
        });

        holder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {

                EventHandlerClass19.popupManager(view, object19);

                return true;
            }
        });

    }

    @Override
    public int getItemCount() {
        return soundObjects19.size();
    }

    public class  SoundboardViewHolder extends RecyclerView.ViewHolder{
        TextView itemTextView;
        public  SoundboardViewHolder(View itemView){
            super(itemView);

            itemTextView = (TextView) itemView.findViewById(R.id.textViewItem19);
        }
    }


}


