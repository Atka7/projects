package tryhss.soundboardfinally.hsssoundboardmaybe.JavaClassok;

public class SoundObject3 {
    private String itemName3;
    private Integer itemID3;

    public SoundObject3(String itemName3, Integer itemID3){

        this.itemName3 = itemName3;
        this.itemID3 = itemID3;
    }


    public String getItemName3(){

        return itemName3;
    }

    public  Integer getItemID3(){

        return itemID3;
    }
}



