package tryhss.soundboardfinally.hsssoundboardmaybe.JavaClassok;

import android.media.MediaPlayer;
import android.os.Environment;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.PopupMenu;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import tryhss.soundboardfinally.hsssoundboardmaybe.R;

public class EventHandlerClass6 {

    private static final String LOG_TAG6 = "EVENTHANDLER";

    private static MediaPlayer mp6;

    public static void startMediaPlayer6(View view, Integer soundID6){

        try {

            if (soundID6 != null){

                if (mp6 != null)
                    mp6.reset();

                mp6= MediaPlayer.create(view.getContext(), soundID6);
                mp6.start();
            }

        }catch (Exception e){

            Log.e(LOG_TAG6,"Failed to initialize MediaPlayer: " + e.getMessage());
        }
    }
    public static void releaseMediaPlayer6(){

        if (mp6 !=null){

            mp6.release();
            mp6 = null;
        }
    }

    public static void  popupManager(final View view, final SoundObject6 soundObject6)
    {
        PopupMenu popup = new PopupMenu(view.getContext(), view);
        popup.getMenuInflater().inflate(R.menu.longclick, popup.getMenu());

        popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem menuItem) {

                if (menuItem.getItemId() == R.id.action_save )
                {
                    final String fileName = soundObject6.getItemName6() + ".mp3";

                    File storage = Environment.getExternalStorageDirectory();
                    File directory = new File(storage.getAbsolutePath() + "/Hungarian_Streamers_Soundboard/Zsozeatya/");
                    directory.mkdirs();

                    final File file = new File(directory, fileName);

                    InputStream in = view.getContext().getResources().openRawResource(soundObject6.getItemID6());

                    try {

                        OutputStream out = new FileOutputStream(file);
                        byte[] buffer = new byte[1024];

                        int len;
                        while ((len = in.read(buffer, 0, buffer.length)) != -1){
                            out.write(buffer, 0, len);
                        }

                        in.close();
                        out.close();

                    }catch (IOException e){
                        Log.e(LOG_TAG6, "Nem sikerült a mentés:" + e.getMessage());
                    }

                }

                return true;
            }
        });

        popup.show();
    }
}
