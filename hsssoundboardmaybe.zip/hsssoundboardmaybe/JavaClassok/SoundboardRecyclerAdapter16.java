package tryhss.soundboardfinally.hsssoundboardmaybe.JavaClassok;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

import tryhss.soundboardfinally.hsssoundboardmaybe.R;

public class SoundboardRecyclerAdapter16 extends RecyclerView.Adapter<SoundboardRecyclerAdapter16.SoundboardViewHolder>{

    private ArrayList<SoundObject16> soundObjects16;

    public SoundboardRecyclerAdapter16(ArrayList<SoundObject16> soundObjects16){

        this.soundObjects16 = soundObjects16;
    }

    @Override
    public SoundboardViewHolder onCreateViewHolder(ViewGroup parent, int viewType){
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.sound_item16, null);
        return new SoundboardViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull SoundboardRecyclerAdapter16.SoundboardViewHolder holder, int position) {

        final SoundObject16 object16 = soundObjects16.get(position);
        final Integer soundID16 = object16.getItemID16();



        holder.itemTextView.setText(object16.getItemName16());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                EventHandlerClass16.startMediaPlayer16(view, soundID16);

            }
        });

        holder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {

                EventHandlerClass16.popupManager(view, object16);

                return true;
            }
        });

    }

    @Override
    public int getItemCount() {
        return soundObjects16.size();
    }

    public class  SoundboardViewHolder extends RecyclerView.ViewHolder{
        TextView itemTextView;
        public  SoundboardViewHolder(View itemView){
            super(itemView);

            itemTextView = (TextView) itemView.findViewById(R.id.textViewItem16);
        }
    }


}


