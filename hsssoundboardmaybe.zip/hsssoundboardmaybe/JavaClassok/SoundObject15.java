package tryhss.soundboardfinally.hsssoundboardmaybe.JavaClassok;

public class SoundObject15 {

    private String itemName15;
    private Integer itemID15;

    public SoundObject15(String itemName15, Integer itemID15){

        this.itemName15 = itemName15;
        this.itemID15 = itemID15;
    }


    public String getItemName15(){

        return itemName15;
    }

    public  Integer getItemID15(){

        return itemID15;
    }
}

