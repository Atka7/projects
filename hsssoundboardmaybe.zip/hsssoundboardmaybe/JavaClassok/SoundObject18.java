package tryhss.soundboardfinally.hsssoundboardmaybe.JavaClassok;

public class SoundObject18 {

    private String itemName18;
    private Integer itemID18;

    public SoundObject18(String itemName18, Integer itemID18){

        this.itemName18 = itemName18;
        this.itemID18 = itemID18;
    }


    public String getItemName18(){

        return itemName18;
    }

    public  Integer getItemID18(){

        return itemID18;
    }
}

