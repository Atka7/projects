package tryhss.soundboardfinally.hsssoundboardmaybe.JavaClassok;

public class SoundObject10 {
    private String itemName10;
    private Integer itemID10;

    public SoundObject10(String itemName10, Integer itemID10){

        this.itemName10 = itemName10;
        this.itemID10 = itemID10;
    }


    public String getItemName10(){

        return itemName10;
    }

    public  Integer getItemID10(){

        return itemID10;
    }
}
