package tryhss.soundboardfinally.hsssoundboardmaybe.JavaClassok;

public class SoundObject20 {

    private String itemName20;
    private Integer itemID20;

    public SoundObject20(String itemName20, Integer itemID20){

        this.itemName20 = itemName20;
        this.itemID20 = itemID20;
    }


    public String getItemName20(){

        return itemName20;
    }

    public  Integer getItemID20(){

        return itemID20;
    }
}

