package tryhss.soundboardfinally.hsssoundboardmaybe.JavaClassok;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

import tryhss.soundboardfinally.hsssoundboardmaybe.R;

public class SoundboardRecyclerAdapter3 extends RecyclerView.Adapter<SoundboardRecyclerAdapter3.SoundboardViewHolder> {
    private ArrayList<SoundObject3> soundObjects3;

    public SoundboardRecyclerAdapter3(ArrayList<SoundObject3> soundObjects3){

        this.soundObjects3 = soundObjects3;
    }

    @Override
    public SoundboardRecyclerAdapter3.SoundboardViewHolder onCreateViewHolder(ViewGroup parent, int viewType){
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.sound_item3, null);
        return new SoundboardViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull SoundboardRecyclerAdapter3.SoundboardViewHolder holder, int position) {

        final SoundObject3 object3 = soundObjects3.get(position);
        final Integer soundID3 = object3.getItemID3();



        holder.itemTextView3.setText(object3.getItemName3());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                EventHandlerClass3.startMediaPlayer3(view, soundID3);

            }
        });

        holder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {

                EventHandlerClass3.popupManager(view, object3);

                return true;
            }
        });

    }

    @Override
    public int getItemCount() {
        return soundObjects3.size();
    }

    public class  SoundboardViewHolder extends RecyclerView.ViewHolder{
        TextView itemTextView3;
        public  SoundboardViewHolder(View itemView){
            super(itemView);

            itemTextView3 = (TextView) itemView.findViewById(R.id.textViewItem3);
        }
    }


}



