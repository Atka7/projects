package tryhss.soundboardfinally.hsssoundboardmaybe.JavaClassok;

public class SoundObject9 {
    private String itemName9;
    private Integer itemID9;

    public SoundObject9(String itemName9, Integer itemID9){

        this.itemName9 = itemName9;
        this.itemID9 = itemID9;
    }


    public String getItemName9(){

        return itemName9;
    }

    public  Integer getItemID9(){

        return itemID9;
    }
}
