package tryhss.soundboardfinally.hsssoundboardmaybe.JavaClassok;

public class SoundObject13 {
    private String itemName13;
    private Integer itemID13;

    public SoundObject13(String itemName13, Integer itemID13){

        this.itemName13 = itemName13;
        this.itemID13 = itemID13;
    }


    public String getItemName13(){

        return itemName13;
    }

    public  Integer getItemID13(){

        return itemID13;
    }
}
