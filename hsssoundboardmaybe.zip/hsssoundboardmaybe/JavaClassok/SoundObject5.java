package tryhss.soundboardfinally.hsssoundboardmaybe.JavaClassok;

public class SoundObject5 {
    private String itemName5;
    private Integer itemID5;

    public SoundObject5(String itemName5, Integer itemID5){

        this.itemName5 = itemName5;
        this.itemID5 = itemID5;
    }


    public String getItemName5(){

        return itemName5;
    }

    public  Integer getItemID5(){

        return itemID5;
    }
}
