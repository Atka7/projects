package tryhss.soundboardfinally.hsssoundboardmaybe.JavaClassok;

public class SoundObject19 {

    private String itemName19;
    private Integer itemID19;

    public SoundObject19(String itemName19, Integer itemID19){

        this.itemName19 = itemName19;
        this.itemID19 = itemID19;
    }


    public String getItemName19(){

        return itemName19;
    }

    public  Integer getItemID19(){

        return itemID19;
    }
}

