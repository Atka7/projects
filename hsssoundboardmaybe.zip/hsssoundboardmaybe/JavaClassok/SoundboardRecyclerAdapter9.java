package tryhss.soundboardfinally.hsssoundboardmaybe.JavaClassok;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

import tryhss.soundboardfinally.hsssoundboardmaybe.R;

public class SoundboardRecyclerAdapter9 extends RecyclerView.Adapter<SoundboardRecyclerAdapter9.SoundboardViewHolder> {
    private ArrayList<SoundObject9> soundObjects9;

    public SoundboardRecyclerAdapter9(ArrayList<SoundObject9> soundObjects9){

        this.soundObjects9 = soundObjects9;
    }

    @Override
    public SoundboardRecyclerAdapter9.SoundboardViewHolder onCreateViewHolder(ViewGroup parent, int viewType){
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.sound_item9, null);
        return new SoundboardViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull SoundboardRecyclerAdapter9.SoundboardViewHolder holder, int position) {

        final SoundObject9 object9 = soundObjects9.get(position);
        final Integer soundID9 = object9.getItemID9();



        holder.itemTextView9.setText(object9.getItemName9());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                EventHandlerClass9.startMediaPlayer9(view, soundID9);

            }
        });

        holder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {

                EventHandlerClass9.popupManager(view, object9);

                return true;
            }
        });

    }

    @Override
    public int getItemCount() {
        return soundObjects9.size();
    }

    public class  SoundboardViewHolder extends RecyclerView.ViewHolder{
        TextView itemTextView9;
        public  SoundboardViewHolder(View itemView){
            super(itemView);

            itemTextView9 = (TextView) itemView.findViewById(R.id.textViewItem9);
        }
    }


}