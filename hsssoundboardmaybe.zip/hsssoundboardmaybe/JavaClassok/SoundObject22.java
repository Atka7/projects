package tryhss.soundboardfinally.hsssoundboardmaybe.JavaClassok;

public class SoundObject22 {

    private String itemName22;
    private Integer itemID22;

    public SoundObject22(String itemName22, Integer itemID22){

        this.itemName22 = itemName22;
        this.itemID22 = itemID22;
    }


    public String getItemName22(){

        return itemName22;
    }

    public  Integer getItemID22(){

        return itemID22;
    }
}

