package tryhss.soundboardfinally.hsssoundboardmaybe.JavaClassok;

public class SoundObject1 {

    private String itemName1;
    private Integer itemID1;

    public SoundObject1(String itemName1, Integer itemID1){

        this.itemName1 = itemName1;
        this.itemID1 = itemID1;
    }


    public String getItemName1(){

        return itemName1;
    }

    public  Integer getItemID1(){

        return itemID1;
    }
}

