package tryhss.soundboardfinally.hsssoundboardmaybe.JavaClassok;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

import tryhss.soundboardfinally.hsssoundboardmaybe.R;

public class SoundboardRecyclerAdapter1 extends RecyclerView.Adapter<SoundboardRecyclerAdapter1.SoundboardViewHolder>{

    private ArrayList<SoundObject1> soundObjects1;

    public SoundboardRecyclerAdapter1(ArrayList<SoundObject1> soundObjects1){

        this.soundObjects1 = soundObjects1;
    }

    @Override
    public SoundboardViewHolder onCreateViewHolder(ViewGroup parent, int viewType){
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.sound_item1, null);
        return new SoundboardViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull SoundboardRecyclerAdapter1.SoundboardViewHolder holder, int position) {

        final SoundObject1 object1 = soundObjects1.get(position);
        final Integer soundID1 = object1.getItemID1();



        holder.itemTextView.setText(object1.getItemName1());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                EventHandlerClass1.startMediaPlayer1(view, soundID1);

            }
        });

        holder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {

                EventHandlerClass1.popupManager(view, object1);

                return true;
            }
        });

    }

    @Override
    public int getItemCount() {
        return soundObjects1.size();
    }

    public class  SoundboardViewHolder extends RecyclerView.ViewHolder{
        TextView itemTextView;
        public  SoundboardViewHolder(View itemView){
            super(itemView);

            itemTextView = (TextView) itemView.findViewById(R.id.textViewItem1);
        }
    }


}


