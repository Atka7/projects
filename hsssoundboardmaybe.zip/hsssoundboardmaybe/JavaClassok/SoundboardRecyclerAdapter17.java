package tryhss.soundboardfinally.hsssoundboardmaybe.JavaClassok;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

import tryhss.soundboardfinally.hsssoundboardmaybe.R;

public class SoundboardRecyclerAdapter17 extends RecyclerView.Adapter<SoundboardRecyclerAdapter17.SoundboardViewHolder>{

    private ArrayList<SoundObject17> soundObjects17;

    public SoundboardRecyclerAdapter17(ArrayList<SoundObject17> soundObjects17){

        this.soundObjects17 = soundObjects17;
    }

    @Override
    public SoundboardViewHolder onCreateViewHolder(ViewGroup parent, int viewType){
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.sound_item17, null);
        return new SoundboardViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull SoundboardRecyclerAdapter17.SoundboardViewHolder holder, int position) {

        final SoundObject17 object17 = soundObjects17.get(position);
        final Integer soundID17 = object17.getItemID17();



        holder.itemTextView.setText(object17.getItemName17());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                EventHandlerClass17.startMediaPlayer17(view, soundID17);

            }
        });

        holder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {

                EventHandlerClass17.popupManager(view, object17);

                return true;
            }
        });

    }

    @Override
    public int getItemCount() {
        return soundObjects17.size();
    }

    public class  SoundboardViewHolder extends RecyclerView.ViewHolder{
        TextView itemTextView;
        public  SoundboardViewHolder(View itemView){
            super(itemView);

            itemTextView = (TextView) itemView.findViewById(R.id.textViewItem17);
        }
    }


}


