package tryhss.soundboardfinally.hsssoundboardmaybe.JavaClassok;

public class SoundObject14 {
    private String itemName14;
    private Integer itemID14;

    public SoundObject14(String itemName14, Integer itemID14){

        this.itemName14 = itemName14;
        this.itemID14 = itemID14;
    }


    public String getItemName14(){

        return itemName14;
    }

    public  Integer getItemID14(){

        return itemID14;
    }
}
