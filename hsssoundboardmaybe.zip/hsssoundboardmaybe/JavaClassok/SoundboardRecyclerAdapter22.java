package tryhss.soundboardfinally.hsssoundboardmaybe.JavaClassok;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

import tryhss.soundboardfinally.hsssoundboardmaybe.R;

public class SoundboardRecyclerAdapter22 extends RecyclerView.Adapter<SoundboardRecyclerAdapter22.SoundboardViewHolder>{

    private ArrayList<SoundObject22> soundObjects22;

    public SoundboardRecyclerAdapter22(ArrayList<SoundObject22> soundObjects22){

        this.soundObjects22 = soundObjects22;
    }

    @Override
    public SoundboardViewHolder onCreateViewHolder(ViewGroup parent, int viewType){
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.sound_item22, null);
        return new SoundboardViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull SoundboardRecyclerAdapter22.SoundboardViewHolder holder, int position) {

        final SoundObject22 object22 = soundObjects22.get(position);
        final Integer soundID22 = object22.getItemID22();



        holder.itemTextView.setText(object22.getItemName22());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                EventHandlerClass22.startMediaPlayer22(view, soundID22);

            }
        });

        holder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {

                EventHandlerClass22.popupManager(view, object22);

                return true;
            }
        });

    }

    @Override
    public int getItemCount() {
        return soundObjects22.size();
    }

    public class  SoundboardViewHolder extends RecyclerView.ViewHolder{
        TextView itemTextView;
        public  SoundboardViewHolder(View itemView){
            super(itemView);

            itemTextView = (TextView) itemView.findViewById(R.id.textViewItem22);
        }
    }


}


