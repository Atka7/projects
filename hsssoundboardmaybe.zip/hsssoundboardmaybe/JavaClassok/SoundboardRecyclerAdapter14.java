package tryhss.soundboardfinally.hsssoundboardmaybe.JavaClassok;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

import tryhss.soundboardfinally.hsssoundboardmaybe.R;

public class SoundboardRecyclerAdapter14 extends RecyclerView.Adapter<SoundboardRecyclerAdapter14.SoundboardViewHolder> {

    private ArrayList<SoundObject14> soundObjects14;

    public SoundboardRecyclerAdapter14(ArrayList<SoundObject14> soundObjects14) {

        this.soundObjects14 = soundObjects14;
    }

    @Override
    public SoundboardRecyclerAdapter14.SoundboardViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.sound_item14, null);
        return new SoundboardViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull SoundboardRecyclerAdapter14.SoundboardViewHolder holder, int position) {

        final SoundObject14 object14 = soundObjects14.get(position);
        final Integer soundID14 = object14.getItemID14();


        holder.itemTextView14.setText(object14.getItemName14());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                EventHandlerClass14.startMediaPlayer14(view, soundID14);

            }
        });

        holder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {

                EventHandlerClass14.popupManager(view, object14);

                return true;
            }
        });

    }

    @Override
    public int getItemCount() {
        return soundObjects14.size();
    }

    public class SoundboardViewHolder extends RecyclerView.ViewHolder {
        TextView itemTextView14;

        public SoundboardViewHolder(View itemView) {
            super(itemView);

            itemTextView14 = (TextView) itemView.findViewById(R.id.textViewItem14);
        }
    }


}