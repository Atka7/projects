package tryhss.soundboardfinally.hsssoundboardmaybe.JavaClassok;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

import tryhss.soundboardfinally.hsssoundboardmaybe.R;

public class SoundboardRecyclerAdapter8 extends RecyclerView.Adapter<SoundboardRecyclerAdapter8.SoundboardViewHolder> {
    private ArrayList<SoundObject8> soundObjects8;

    public SoundboardRecyclerAdapter8(ArrayList<SoundObject8> soundObjects8){

        this.soundObjects8 = soundObjects8;
    }

    @Override
    public SoundboardRecyclerAdapter8.SoundboardViewHolder onCreateViewHolder(ViewGroup parent, int viewType){
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.sound_item8, null);
        return new SoundboardViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull SoundboardRecyclerAdapter8.SoundboardViewHolder holder, int position) {

        final SoundObject8 object8 = soundObjects8.get(position);
        final Integer soundID8 = object8.getItemID8();



        holder.itemTextView8.setText(object8.getItemName8());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                EventHandlerClass8.startMediaPlayer8(view, soundID8);

            }
        });

        holder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {

                EventHandlerClass8.popupManager(view, object8);

                return true;
            }
        });

    }

    @Override
    public int getItemCount() {
        return soundObjects8.size();
    }

    public class  SoundboardViewHolder extends RecyclerView.ViewHolder{
        TextView itemTextView8;
        public  SoundboardViewHolder(View itemView){
            super(itemView);

            itemTextView8 = (TextView) itemView.findViewById(R.id.textViewItem8);
        }
    }


}