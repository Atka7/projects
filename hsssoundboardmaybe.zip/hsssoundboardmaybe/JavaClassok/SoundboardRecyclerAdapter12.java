package tryhss.soundboardfinally.hsssoundboardmaybe.JavaClassok;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

import tryhss.soundboardfinally.hsssoundboardmaybe.R;

public class SoundboardRecyclerAdapter12 extends RecyclerView.Adapter<SoundboardRecyclerAdapter12.SoundboardViewHolder> {
    private ArrayList<SoundObject12> soundObjects12;

    public SoundboardRecyclerAdapter12(ArrayList<SoundObject12> soundObjects12){

        this.soundObjects12 = soundObjects12;
    }

    @Override
    public SoundboardRecyclerAdapter12.SoundboardViewHolder onCreateViewHolder(ViewGroup parent, int viewType){
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.sound_item12, null);
        return new SoundboardViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull SoundboardRecyclerAdapter12.SoundboardViewHolder holder, int position) {

        final SoundObject12 object12 = soundObjects12.get(position);
        final Integer soundID12 = object12.getItemID12();



        holder.itemTextView12.setText(object12.getItemName12());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                EventHandlerClass12.startMediaPlayer12(view, soundID12);

            }
        });

        holder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {

                EventHandlerClass12.popupManager(view, object12);

                return true;
            }
        });

    }

    @Override
    public int getItemCount() {
        return soundObjects12.size();
    }

    public class  SoundboardViewHolder extends RecyclerView.ViewHolder{
        TextView itemTextView12;
        public  SoundboardViewHolder(View itemView){
            super(itemView);

            itemTextView12 = (TextView) itemView.findViewById(R.id.textViewItem12);
        }
    }


}