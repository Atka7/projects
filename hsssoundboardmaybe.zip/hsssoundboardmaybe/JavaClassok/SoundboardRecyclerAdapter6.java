package tryhss.soundboardfinally.hsssoundboardmaybe.JavaClassok;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

import tryhss.soundboardfinally.hsssoundboardmaybe.R;

public class SoundboardRecyclerAdapter6 extends RecyclerView.Adapter<SoundboardRecyclerAdapter6.SoundboardViewHolder> {
    private ArrayList<SoundObject6> soundObjects6;

    public SoundboardRecyclerAdapter6(ArrayList<SoundObject6> soundObjects6){

        this.soundObjects6 = soundObjects6;
    }

    @Override
    public SoundboardRecyclerAdapter6.SoundboardViewHolder onCreateViewHolder(ViewGroup parent, int viewType){
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.sound_item6, null);
        return new SoundboardViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull SoundboardRecyclerAdapter6.SoundboardViewHolder holder, int position) {

        final SoundObject6 object6 = soundObjects6.get(position);
        final Integer soundID6 = object6.getItemID6();



        holder.itemTextView6.setText(object6.getItemName6());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                EventHandlerClass6.startMediaPlayer6(view, soundID6);

            }
        });

        holder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {

                EventHandlerClass6.popupManager(view, object6);

                return true;
            }
        });

    }

    @Override
    public int getItemCount() {
        return soundObjects6.size();
    }

    public class  SoundboardViewHolder extends RecyclerView.ViewHolder{
        TextView itemTextView6;
        public  SoundboardViewHolder(View itemView){
            super(itemView);

            itemTextView6 = (TextView) itemView.findViewById(R.id.textViewItem6);
        }
    }


}
