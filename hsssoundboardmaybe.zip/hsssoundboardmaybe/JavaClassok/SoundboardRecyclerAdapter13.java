package tryhss.soundboardfinally.hsssoundboardmaybe.JavaClassok;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

import tryhss.soundboardfinally.hsssoundboardmaybe.R;

public class SoundboardRecyclerAdapter13 extends RecyclerView.Adapter<SoundboardRecyclerAdapter13.SoundboardViewHolder> {
    private ArrayList<SoundObject13> soundObjects13;

    public SoundboardRecyclerAdapter13(ArrayList<SoundObject13> soundObjects13){

        this.soundObjects13 = soundObjects13;
    }

    @Override
    public SoundboardRecyclerAdapter13.SoundboardViewHolder onCreateViewHolder(ViewGroup parent, int viewType){
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.sound_item13, null);
        return new SoundboardViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull SoundboardRecyclerAdapter13.SoundboardViewHolder holder, int position) {

        final SoundObject13 object13 = soundObjects13.get(position);
        final Integer soundID13 = object13.getItemID13();



        holder.itemTextView13.setText(object13.getItemName13());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                EventHandlerClass13.startMediaPlayer13(view, soundID13);

            }
        });

        holder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {

                EventHandlerClass13.popupManager(view, object13);

                return true;
            }
        });

    }

    @Override
    public int getItemCount() {
        return soundObjects13.size();
    }

    public class  SoundboardViewHolder extends RecyclerView.ViewHolder{
        TextView itemTextView13;
        public  SoundboardViewHolder(View itemView){
            super(itemView);

            itemTextView13 = (TextView) itemView.findViewById(R.id.textViewItem13);
        }
    }


}