package tryhss.soundboardfinally.hsssoundboardmaybe.Shop;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import tryhss.soundboardfinally.hsssoundboardmaybe.R;

public class Ruben_Shop_Icon extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ruben_shop_icon);
    }
}
