package tryhss.soundboardfinally.hsssoundboardmaybe.Socials;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;

import tryhss.soundboardfinally.hsssoundboardmaybe.R;

public class Atka_Socials extends AppCompatActivity {

    androidx.appcompat.widget.Toolbar toolbar;

    private AdView ad, ad2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_socials);

        //-----------------AD-----------------------------

        MobileAds.initialize(this,"ca-app-pub-8890972768819102~6800754409");

        ad = (AdView) findViewById(R.id.ad_view_mysocial);
        ad2 = (AdView) findViewById(R.id.ad_view_mysocial_2);

        AdRequest adRequest = new AdRequest.Builder().build();
        ad.loadAd(adRequest);

        AdRequest adRequest2 = new AdRequest.Builder().build();
        ad2.loadAd(adRequest2);

        //------------------------------------------------------------

        toolbar = (androidx.appcompat.widget.Toolbar) findViewById(R.id.toolbar_atka_social);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        findViewById(R.id.atka_twitch).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clicked_btntwitch("https://www.twitch.tv/atkaaaa");
            }
        });
        findViewById(R.id.atka_insta).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clicked_btninsta("https://www.instagram.com/atkawastaken/");
            }
        });
        findViewById(R.id.atka_dc).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clicked_btndc("https://discord.gg/W2MA6WN");
            }
        });
        findViewById(R.id.atka_tiktok).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clicked_btndc("https://www.tiktok.com/@atkaa7?lang=hu-HU");
            }
        });
    }
    public void clicked_btninsta(String url){
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(url));
        startActivity(intent);
    }
    public void clicked_btntwitch(String url){
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(url));
        startActivity(intent);
    }
    public void clicked_btndc(String url){
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(url));
        startActivity(intent);
    }
}



