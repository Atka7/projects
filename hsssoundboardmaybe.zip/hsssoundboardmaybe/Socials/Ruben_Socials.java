package tryhss.soundboardfinally.hsssoundboardmaybe.Socials;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;

import tryhss.soundboardfinally.hsssoundboardmaybe.R;

public class Ruben_Socials extends AppCompatActivity {

    androidx.appcompat.widget.Toolbar toolbar;

    private AdView ad, ad2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ruben_socials);

        //-----------------AD-----------------------------

        MobileAds.initialize(this,"ca-app-pub-8890972768819102~6800754409");

        ad = (AdView) findViewById(R.id.ad_view_ruben_socials);
        ad2 = (AdView) findViewById(R.id.ad_view_ruben_socials_2);

        AdRequest adRequest = new AdRequest.Builder().build();
        ad.loadAd(adRequest);

        AdRequest adRequest2 = new AdRequest.Builder().build();
        ad2.loadAd(adRequest2);

        //------------------------------------------------------------

        toolbar = (androidx.appcompat.widget.Toolbar) findViewById(R.id.toolbar_ruben_social);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        findViewById(R.id.ruben_dc).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clicked_btndc("https://discord.com/invite/ruben");
            }
        });
        findViewById(R.id.ruben_insta).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clicked_btninsta("https://www.instagram.com/twitchruben/");
            }
        });

        findViewById(R.id.ruben_twitch).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clicked_btntwitch("https://www.twitch.tv/ruben");
            }
        });
        findViewById(R.id.ruben_yt).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clicked_btnyt("https://www.youtube.com/channel/UC-oAGRHJI2sr20XHdE3RFww?view_as=subscriber");
            }
        });
        findViewById(R.id.ruben_face).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clicked_btnface("https://www.facebook.com/TwitchRuben");
            }
        });
        findViewById(R.id.ruben_lanbox).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clicked_btnface("https://lanbox.hu/ruben/");
            }
        });

    }
    public void clicked_btndc(String url){
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(url));
        startActivity(intent);
    }
    public void clicked_btninsta(String url){
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(url));
        startActivity(intent);
    }
    public void clicked_btntwitch(String url){
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(url));
        startActivity(intent);
    }
    public void clicked_btnyt(String url){
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(url));
        startActivity(intent);
    }
    public void clicked_btnface(String url){
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(url));
        startActivity(intent);
    }

}
