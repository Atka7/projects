package tryhss.soundboardfinally.hsssoundboardmaybe.Socials;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;

import tryhss.soundboardfinally.hsssoundboardmaybe.R;

public class PauluszSocials extends AppCompatActivity {

    androidx.appcompat.widget.Toolbar toolbar;

    private AdView ad, ad2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_paulusz_socials);

        //-----------------AD-----------------------------

        MobileAds.initialize(this,"ca-app-pub-8890972768819102~6800754409");

        ad = (AdView) findViewById(R.id.ad_view_paulusz_social);
        ad2 = (AdView) findViewById(R.id.ad_view_paulusz_social_2);

        AdRequest adRequest = new AdRequest.Builder().build();
        ad.loadAd(adRequest);

        AdRequest adRequest2 = new AdRequest.Builder().build();
        ad2.loadAd(adRequest2);

        //------------------------------------------------------------

        toolbar = (androidx.appcompat.widget.Toolbar) findViewById(R.id.toolbar_paulusz_social);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        findViewById(R.id.paulusz_dc).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clicked_btndc("https://discord.gg/UZ8P973");
            }
        });
        findViewById(R.id.paulusz_insta).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clicked_btninsta("https://www.instagram.com/zolimacso97/");
            }
        });
        findViewById(R.id.paulusz_twitch).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clicked_btntwitch("https://www.twitch.tv/paulusz_");
            }
        });
        findViewById(R.id.paulusz_yt).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clicked_btnyt("https://www.youtube.com/channel/UCkw_A9biWfgGTF9ctZ6QDqw/featured");
            }
        });

    }
    public void clicked_btndc(String url){
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(url));
        startActivity(intent);
    }
    public void clicked_btninsta(String url){
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(url));
        startActivity(intent);
    }
    public void clicked_btntwitch(String url){
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(url));
        startActivity(intent);
    }
    public void clicked_btnyt(String url){
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(url));
        startActivity(intent);
    }

}
