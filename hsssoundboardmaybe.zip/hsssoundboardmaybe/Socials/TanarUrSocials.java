package tryhss.soundboardfinally.hsssoundboardmaybe.Socials;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;

import tryhss.soundboardfinally.hsssoundboardmaybe.R;

public class TanarUrSocials extends AppCompatActivity {

    androidx.appcompat.widget.Toolbar toolbar;

    private AdView ad, ad2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tanarur_socials);

        //-----------------AD-----------------------------

        MobileAds.initialize(this,"ca-app-pub-8890972768819102~3454163387");

        ad = (AdView) findViewById(R.id.ad_view_tanarur_social);
        ad2 = (AdView) findViewById(R.id.ad_view_tanarur_social_2);

        AdRequest adRequest = new AdRequest.Builder().build();
        ad.loadAd(adRequest);

        AdRequest adRequest2 = new AdRequest.Builder().build();
        ad2.loadAd(adRequest2);

        //------------------------------------------------------------

        toolbar = (androidx.appcompat.widget.Toolbar) findViewById(R.id.toolbar_tanarur_social);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        findViewById(R.id.tanarur_twitch).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clicked_btntwitch("https://www.twitch.tv/tanarur");
            }
        });
        findViewById(R.id.tanarur_insta).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clicked_btninsta("https://www.instagram.com/tanarurgram/");
            }
        });
        findViewById(R.id.tanarur_yt).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clicked_btyt("https://www.youtube.com/c/tanarurstream?sub_confirmation=1");
            }
        });
        findViewById(R.id.tanarur_face).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clicked_btnface("https://www.facebook.com/tanarurstream");
            }
        });
        findViewById(R.id.tanarur_twitter).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clicked_btntwitter("https://twitter.com/tanarurstream");
            }
        });
        findViewById(R.id.tanarur_shop).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clicked_btnshop("http://shop.pentamedia.hu/tanar-ur");
            }
        });
        findViewById(R.id.tanarur_page).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clicked_btnpage("https://www.tanarurstream.hu");
            }
        });
        findViewById(R.id.tanarur_dc).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clicked_btndc("https://discord.com/invite/tanarur");
            }
        });


    }
    public void clicked_btndc(String url){
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(url));
        startActivity(intent);
    }
    public void clicked_btninsta(String url){
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(url));
        startActivity(intent);
    }
    public void clicked_btntwitch(String url){
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(url));
        startActivity(intent);
    }
    public void clicked_btyt(String url){
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(url));
        startActivity(intent);
    }
    public void clicked_btnface(String url){
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(url));
        startActivity(intent);
    }
    public void clicked_btntwitter(String url){
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(url));
        startActivity(intent);
    }
    public void clicked_btnshop(String url){
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(url));
        startActivity(intent);
    }
    public void clicked_btnpage(String url){
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(url));
        startActivity(intent);
    }

}

