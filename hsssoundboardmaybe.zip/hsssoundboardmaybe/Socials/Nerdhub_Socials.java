package tryhss.soundboardfinally.hsssoundboardmaybe.Socials;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;

import tryhss.soundboardfinally.hsssoundboardmaybe.R;

public class Nerdhub_Socials extends AppCompatActivity {

    androidx.appcompat.widget.Toolbar toolbar;

    private AdView ad, ad2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nerdhub_socials);

        //-----------------AD-----------------------------

        MobileAds.initialize(this,"ca-app-pub-8890972768819102~6800754409");

        ad = (AdView) findViewById(R.id.ad_view_nerdhub_social);
        ad2 = (AdView) findViewById(R.id.ad_view_nerdhub_social_2);

        AdRequest adRequest = new AdRequest.Builder().build();
        ad.loadAd(adRequest);

        AdRequest adRequest2 = new AdRequest.Builder().build();
        ad2.loadAd(adRequest2);

        //------------------------------------------------------------

        toolbar = (androidx.appcompat.widget.Toolbar) findViewById(R.id.toolbar_nerdhub_social);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        findViewById(R.id.nh_dc).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clicked_btndc("https://discord.com/invite/szqTcfk");
            }
        });
        findViewById(R.id.nh_insta).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clicked_btninsta("https://www.instagram.com/thenerdhub/?hl=hu");
            }
        });

        findViewById(R.id.nh_twitch).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clicked_btntwitch("https://www.twitch.tv/nerdhub");
            }
        });
        findViewById(R.id.nh_yt).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clicked_btnyt("https://www.youtube.com/channel/UCt-iaRZ0COAwl7QgC_hCCLQ");
            }
        });
        findViewById(R.id.nh_reddit).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clicked_btnface("https://www.facebook.com/AdamKissAK/");
            }
        });
        findViewById(R.id.nh_face).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clicked_btnface("https://www.facebook.com/thenerdhub/?fref=ts");
            }
        });

    }
    public void clicked_btndc(String url){
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(url));
        startActivity(intent);
    }
    public void clicked_btninsta(String url){
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(url));
        startActivity(intent);
    }
    public void clicked_btntwitch(String url){
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(url));
        startActivity(intent);
    }
    public void clicked_btnyt(String url){
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(url));
        startActivity(intent);
    }
    public void clicked_btnface(String url){
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(url));
        startActivity(intent);
    }

}
