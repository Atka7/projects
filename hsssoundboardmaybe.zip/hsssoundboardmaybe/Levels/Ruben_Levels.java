package tryhss.soundboardfinally.hsssoundboardmaybe.Levels;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import tryhss.soundboardfinally.hsssoundboardmaybe.R;

public class Ruben_Levels extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ruben_levels);
    }
}
