import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'widgets/options.dart';

class BoltokPage extends StatefulWidget {
  @override
  _BoltokPageState createState() => _BoltokPageState();
}

class _BoltokPageState extends State<BoltokPage> {
  bool isLoading = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        drawer: NavDrawer(),
        appBar: AppBar(
          backgroundColor: Color.fromARGB(255, 157, 210, 42),
          iconTheme: IconThemeData(color: Colors.white),
          centerTitle: true,
          title: Text('Viszonteladók',
              textAlign: TextAlign.center,
              style: TextStyle(
                  color: Colors.white,
                  fontFamily: 'Roboto',
                  fontWeight: FontWeight.bold,
                  fontSize: 25.0)),
        ),
        body: Stack(children: <Widget>[
          SafeArea(
            child: WebView(
              initialUrl:
                  'https://www.google.com/maps/d/u/0/viewer?mid=1c8zkGMdByTkpVbtAOmdbtx-1i5ibgjJr&ll=47.30148270631567%2C19.473752000000022&z=7',
              javascriptMode: JavascriptMode.unrestricted,
              onWebViewCreated: (WebViewController webviewcontroller) {},
              onPageFinished: (finish) {
                setState(() {
                  isLoading = false;
                });
              },
            ),
          ),
          isLoading
              ? Center(
                  child: CircularProgressIndicator(),
                )
              : Stack(),
        ]));
  }
}
