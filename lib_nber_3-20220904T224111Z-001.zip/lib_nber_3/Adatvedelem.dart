import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';

class Adatvedelem extends StatefulWidget {
  @override
  _AdatvedelemState createState() => _AdatvedelemState();
}
class _AdatvedelemState extends State<Adatvedelem> {
  bool isLoading = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color.fromARGB(255, 157, 210, 42),
        elevation: 0.0,
        centerTitle: true,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () {
            Navigator.of(context).pop();
          },
        ),
        title: Text('Adatvédelem',
            style: TextStyle(
                fontFamily: 'Roboto',
                fontWeight: FontWeight.bold,
                fontSize: 20.0,
                color: Colors.white)),
        actions: <Widget>[],
      ),
      body: Stack(
          children: <Widget>[
            SafeArea(
              child: WebView(
                initialUrl:
                'https://nberenergydrink.hu/adatvedelem/',
                javascriptMode: JavascriptMode.unrestricted,
                onWebViewCreated: (WebViewController webviewcontroller) {},
                onPageFinished: (finish) {
                  setState(() {
                    isLoading = false;
                  });
                },
              ),

            ),
            isLoading ? Center( child: CircularProgressIndicator(),)
                : Stack(),
          ]
      ));
  }
}
