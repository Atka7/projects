import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:nberenergydrink/H%C3%ADrek.dart';
import 'package:nberenergydrink/SocialMediaPosts.dart';
import 'package:nberenergydrink/services/Twitchpage.dart';
import 'package:nberenergydrink/widgets/splash.dart';
import 'WebShopPage.dart';
import 'package:nberenergydrink/Italok.dart';
import 'BoltokPage.dart';
import 'package:firebase_messaging/firebase_messaging.dart';

final GlobalKey<NavigatorState> firstTabNavKey = GlobalKey<NavigatorState>();
final GlobalKey<NavigatorState> secondTabNavKey = GlobalKey<NavigatorState>();
final GlobalKey<NavigatorState> thirdTabNavKey = GlobalKey<NavigatorState>();
final GlobalKey<NavigatorState> fourthTabNavKey = GlobalKey<NavigatorState>();
final GlobalKey<NavigatorState> fifthTabNavKey = GlobalKey<NavigatorState>();
final GlobalKey<NavigatorState> sixthTabNavKey = GlobalKey<NavigatorState>();

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();

  FirebaseMessaging messaging = FirebaseMessaging.instance;

  NotificationSettings settings = await messaging.requestPermission (
      alert: true,
      announcement: true,
      badge: true,
      carPlay: false,
      criticalAlert: true,
      provisional: false,
      sound: true,
  );

  print('User granted permission: ${settings.authorizationStatus}');

  FirebaseMessaging.onMessage.listen((RemoteMessage message) {
    print('Got a message whilst in the foreground!');
    print('Message data: ${message.data}');

    if(message.notification != null){
      print('Message also contained a notification: ${message.notification}');
    }
  });

  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'NBER Energydrink',
      theme: ThemeData(
        visualDensity: VisualDensity.adaptivePlatformDensity,
        fontFamily: 'Roboto',
        primaryColor: Color.fromARGB(255, 157, 210, 42),
        primaryColorLight: Color(0xFFFBE0E6),
      ),
      home: SplashScreen(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 6, vsync: this);
  }


  @override
  void dispose() {
    super.dispose();
    _tabController.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return CupertinoTabScaffold(
      tabBar: CupertinoTabBar(
        activeColor: Colors.white,
        inactiveColor: Color.fromARGB(255, 117 ,169,  39),
        backgroundColor: Color.fromARGB(255, 157, 210, 42),
        items: [
          BottomNavigationBarItem(
            backgroundColor: Colors.white,
            activeIcon: Icon(FontAwesomeIcons.store,),
            icon: Icon(FontAwesomeIcons.store,),
          ),
          BottomNavigationBarItem(
            backgroundColor: Colors.white,
            activeIcon: Icon(FontAwesomeIcons.newspaper,),
            icon: Icon(FontAwesomeIcons.newspaper,),
          ),
          BottomNavigationBarItem(
            backgroundColor: Colors.white,
            activeIcon: Icon(FontAwesomeIcons.bell,),
            icon: Icon(FontAwesomeIcons.bell,),
          ),
          BottomNavigationBarItem(
            backgroundColor: Colors.white,
            activeIcon: Icon(FontAwesomeIcons.map,),
            icon: Icon(FontAwesomeIcons.map,),
          ),
          BottomNavigationBarItem(
            backgroundColor: Colors.white,
            activeIcon: Icon(FontAwesomeIcons.tv,),
            icon: Icon(FontAwesomeIcons.tv,),
          ),
          BottomNavigationBarItem(
            backgroundColor: Colors.white,
            activeIcon: Icon(FontAwesomeIcons.glassWater,),
            icon: Icon(FontAwesomeIcons.glassWater,),
          ),
        ],
      ),
      tabBuilder: (context, index) {
        if (index == 0) {
          return CupertinoTabView(
            navigatorKey: firstTabNavKey,
            builder: (BuildContext context) => WebShopPage(),
          );
        }
        else if (index == 1) {
          return CupertinoTabView(
            navigatorKey: secondTabNavKey,
            builder: (BuildContext context) => HirekPage(),
          );
        }
        else if (index == 2) {
          return CupertinoTabView(
            navigatorKey: thirdTabNavKey,
            builder: (BuildContext context) => SocialMediaPosts(),
          );
        }
        else if (index == 3) {
          return CupertinoTabView(
            navigatorKey: fourthTabNavKey,
            builder: (BuildContext context) => BoltokPage(),
          );
        }
        else if (index == 4) {
          return CupertinoTabView(
            navigatorKey: fifthTabNavKey,
            builder: (BuildContext context) => TwitchPage(),
          );
        }
        else {
          return CupertinoTabView(
            navigatorKey: sixthTabNavKey,
            builder: (BuildContext context) => Italok(),
          );
        }
      },
    );
  }
}
