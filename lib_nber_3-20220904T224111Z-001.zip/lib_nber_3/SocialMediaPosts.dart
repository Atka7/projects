import 'package:any_link_preview/any_link_preview.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:nberenergydrink/services/storage_services.dart';
import 'package:nberenergydrink/widgets/options.dart';

class SocialMediaPosts extends StatefulWidget {
  @override
  _SocialMediaPostsState createState() => _SocialMediaPostsState();
}

class _SocialMediaPostsState extends State<SocialMediaPosts> {

  final Stream<QuerySnapshot> posztok = FirebaseFirestore.instance.collection('socialmediaposts').orderBy('id', descending: true).snapshots();
  final Storage storage = Storage();

  final String _errorImage =
      "https://i.ytimg.com/vi/z8wrRRR7_qU/maxresdefault.jpg";

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        drawer: NavDrawer(),
        appBar: AppBar(
          backgroundColor: Color.fromARGB(255, 157, 210, 42),
          iconTheme: IconThemeData(color: Colors.white),
          centerTitle: true,
          title: Text('Posztok',
              textAlign: TextAlign.center,
              style: TextStyle(
                  color: Colors.white,
                  fontFamily: 'Roboto',
                  fontWeight: FontWeight.bold,
                  fontSize: 25.0)),
        ),
        body: Column(
          children: [
            StreamBuilder<QuerySnapshot>(
              stream: posztok,
              builder: (BuildContext context, AsyncSnapshot<QuerySnapshot> snapshot) {
                if(snapshot.hasError) {
                  return Text('Something went wrong');
                }
                if(snapshot.connectionState == ConnectionState.waiting) {
                  return CircularProgressIndicator();
                }

                final data = snapshot.requireData;

                return Flexible(
                  child: Container(
                      padding: EdgeInsets.only(right: 10.0, left: 10.0, top: 10.0),
                      width: double.infinity,
                      height: MediaQuery.of(context).size.height,
                      child:
                      SingleChildScrollView(
                        child: Column(
                          children:
                          List.generate(data.size, (index) {
                            return Column(
                              children: [
                                AnyLinkPreview(
                                  link: "${data.docs[index]['link']}",
                                  displayDirection: UIDirection.uiDirectionHorizontal,
                                  backgroundColor: Colors.grey[300],
                                  errorWidget: Container(
                                    color: Colors.black,
                                    child: Text('Oops!'),
                                  ),
                                  titleStyle: TextStyle(
                                    color: Colors.black,
                                    fontWeight: FontWeight.bold,
                                    fontSize: 15,
                                  ),
                                  bodyStyle: TextStyle(color: Colors.grey, fontSize: 12),
                                  errorImage: _errorImage,
                                ),
                                SizedBox(height: 25),
                              ],
                            );
                          }),
                        ),
                      )
                  ),
                );
              },
            ),
          ],
        )
      ),
    );
  }
}