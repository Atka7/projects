import 'dart:core';
import 'dart:ui';

class AppColors {
  static const Color GREEN = Color.fromARGB(255, 157, 210, 42);
  static const Color DARK_GREEN = Color.fromARGB(255, 117 ,169,  39);
  static const Color WHITE = Color.fromARGB(255, 255, 255, 255);
  static const Color YELLOW = Color.fromARGB(255, 255, 255, 255);


}