import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:nberenergydrink/Poseidon.dart';
import '../services/shimmer_images_details.dart';
import '../services/storage_services.dart';

class TermekLeiras extends StatelessWidget {
  final name, picture, price, link, leiras, leiras2;

  TermekLeiras(
      {this.name, this.picture, this.price, this.link, this.leiras, this.leiras2});

  final Storage storage = Storage();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color.fromARGB(255, 157, 210, 42),
        elevation: 0.0,
        centerTitle: true,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () {
            Navigator.of(context).pop();
          },
        ),
        title: Text('Vásárlás',
            style: TextStyle(
                fontFamily: 'Roboto',
                fontWeight: FontWeight.bold,
                fontSize: 20.0,
                color: Colors.white)),
        actions: <Widget>[],
      ),
      body: ListView(children: [
        SizedBox(height: 15.0),
        Padding(
          padding: EdgeInsets.only(left: 20.0),
          child: Center(
            child: Text('NBER Energydrink',
                style: TextStyle(
                    fontFamily: 'Roboto',
                    fontWeight: FontWeight.bold,
                    fontSize: 35.0,
                    color: Color.fromARGB(255, 157, 210, 42))),
          )
        ),
        SizedBox(height: 15.0),
         FutureBuilder(
              future: storage.downloadURL(picture),
              builder: (BuildContext context, AsyncSnapshot<String> snapshot) {
                if (snapshot.connectionState == ConnectionState.done && snapshot.hasData) {
                  return Container(
                    padding: EdgeInsets.only(top: 5.0, left: 5.0, right: 5.0),
                    child:
                    Image.network(
                      snapshot.data!, fit: BoxFit.contain,
                      ),

                  );
                }
                if(snapshot.connectionState== ConnectionState.waiting || !snapshot.hasData) {
                  return ShimmerDetails();
                }
                return ShimmerDetails();
              }),
        SizedBox(height: 20.0),
        Center(
          child:  Text(name,
              textAlign: TextAlign.center,
              style: TextStyle(
                  color: Color(0xFF575E67),
                  fontFamily: 'Roboto',
                  fontWeight: FontWeight.bold,
                  fontSize: 30.0)),
        ),
        SizedBox(height: 20.0),
        Center(
          child: Container(
            width: MediaQuery.of(context).size.width - 50.0,
            child: Text(leiras2,
                textAlign: TextAlign.center,
                style: TextStyle(
                    fontFamily: 'Roboto',
                    fontWeight: FontWeight.bold,
                    fontSize: 16.0,
                    color: Color(0xFFB4B8B9))),
          ),
        ),
        SizedBox(height: 10.0),
        Padding(
          padding: EdgeInsets.only(left: 20.0, right: 20.0),
          child: Text(leiras,
              textAlign: TextAlign.center,
              style: TextStyle(
                  color: Color(0xFF575E67),
                  fontFamily: 'Roboto',
                  fontWeight: FontWeight.bold,
                  fontSize: 18.0)),
        ),
        SizedBox(height: 20.0),
        Center(
          child: Text(price + " Ft",
              style: TextStyle(
                  color: Color.fromARGB(255, 157, 210, 42),
                  fontFamily: 'Roboto',
                  fontWeight: FontWeight.bold,
                  fontSize: 24.0)),
        ),
        SizedBox(height: 20.0),
        Center(
            child: Container(
                width: MediaQuery.of(context).size.width - 50.0,
                height: 50.0,
                child: new ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    primary: Color.fromARGB(255, 157, 210, 42), // background
                    onPrimary: Colors.white,
                  ), // foreground
                  onPressed: () { launch(link);
                  },
                  child: new Text(
                    'Megveszem',
                    style: TextStyle(
                        fontFamily: 'Roboto',
                        fontWeight: FontWeight.bold,
                        fontSize: 14.0,
                        color: Colors.white),
                  ),
                ))),
        SizedBox(height: 20.0),
        Center(
            child: Container(
                width: MediaQuery.of(context).size.width - 50.0,
                height: 50.0,
                child: new ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    primary: Color.fromARGB(255, 157, 210, 42), // background
                    onPrimary: Colors.white,
                  ), // foreground
                  onPressed: () async {
                    final urlPreview = link;

                    await Share.share('$urlPreview');
                  },
                  child: new Text(
                    'Megosztás',
                    style: TextStyle(
                        fontFamily: 'Roboto',
                        fontWeight: FontWeight.bold,
                        fontSize: 14.0,
                        color: Colors.white),
                  ),
                ))),
        SizedBox(height: 50.0,)
      ]),
    );
  }
}
