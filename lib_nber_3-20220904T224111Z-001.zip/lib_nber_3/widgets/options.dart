import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:nberenergydrink/Adatvedelem.dart';
import 'package:nberenergydrink/Impresszum.dart';
import 'package:nberenergydrink/Poseidon.dart';

class NavDrawer extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: Container(
        color: Color.fromARGB(255, 50, 50, 48),
        child: ListView(
          padding: EdgeInsets.zero,
          children: <Widget>[
            DrawerHeader(
              child: Text(
                '',
              ),
              decoration: BoxDecoration(
                  color: Color.fromARGB(255, 50, 50, 48),
                  image: DecorationImage(
                      fit: BoxFit.fitWidth,
                      image: AssetImage('assets/nberlogo.png'))),
            ),
            ListTile(
              leading: Icon(
                FontAwesomeIcons.globe,
                color: Color.fromARGB(255, 157, 210, 42),
              ),
              title: Text(
                'Weboldal',
                style: TextStyle(
                    color: Color.fromARGB(255, 157, 210, 42),
                    fontFamily: 'Roboto',
                    fontWeight: FontWeight.bold,
                    fontSize: 18.0),
              ),
              onTap: () => {launch("https://nberenergydrink.hu/")},
            ),
            ListTile(
              leading: Icon(
                FontAwesomeIcons.store,
                color: Color.fromARGB(255, 157, 210, 42),
              ),
              title: Text(
                'Rendelés',
                style: TextStyle(
                    color: Color.fromARGB(255, 157, 210, 42),
                    fontFamily: 'Roboto',
                    fontWeight: FontWeight.bold,
                    fontSize: 18.0),
              ),
              onTap: () => {launch("https://nberenergydrink.hu/#rendeles")},
            ),
            ListTile(
              leading: Icon(
                FontAwesomeIcons.truck,
                color: Color.fromARGB(255, 157, 210, 42),
              ),
              title: Text(
                'Viszonteladóknak',
                style: TextStyle(
                    color: Color.fromARGB(255, 157, 210, 42),
                    fontFamily: 'Roboto',
                    fontWeight: FontWeight.bold,
                    fontSize: 18.0),
              ),
              onTap: () =>
                  {launch("https://nberenergydrink.hu/#viszonteladoknak")},
            ),
            ListTile(
              leading: Icon(
                FontAwesomeIcons.lock,
                color: Color.fromARGB(255, 157, 210, 42),
              ),
              title: Text(
                'Adatvédelem',
                style: TextStyle(
                    color: Color.fromARGB(255, 157, 210, 42),
                    fontFamily: 'Roboto',
                    fontWeight: FontWeight.bold,
                    fontSize: 18.0),
              ),
              onTap: () => {Navigator.of(context).push(MaterialPageRoute(
              builder: (context) => Adatvedelem()))},
            ),
            ListTile(
              leading: Icon(
                FontAwesomeIcons.info,
                color: Color.fromARGB(255, 157, 210, 42),
              ),
              title: Text(
                'Impresszum',
                style: TextStyle(
                    color: Color.fromARGB(255, 157, 210, 42),
                    fontFamily: 'Roboto',
                    fontWeight: FontWeight.bold,
                    fontSize: 18.0),
              ),
              onTap: () => {Navigator.of(context).push(MaterialPageRoute(
                  builder: (context) => Impresszum()))},
            ),
            ListTile(
              leading:  Icon(
                FontAwesomeIcons.checkCircle,
                color: Color.fromARGB(255, 157, 210, 42),
              ),
              title: Text(
                'Info',
                style: TextStyle(
                    color: Color.fromARGB(255, 157, 210, 42),
                    fontFamily: 'Roboto',
                    fontWeight: FontWeight.bold,
                    fontSize: 18.0),
              ),
              onTap: () => {Navigator.of(context).push(MaterialPageRoute(
                  builder: (context) => Poseidon()))},
            ),
            ListTile(
              leading: Icon(
                Icons.exit_to_app,
                color: Color.fromARGB(255, 157, 210, 42),
              ),
              title: Text(
                'Bezárás',
                style: TextStyle(
                    color: Color.fromARGB(255, 157, 210, 42),
                    fontFamily: 'Roboto',
                    fontWeight: FontWeight.bold,
                    fontSize: 18.0),
              ),
              onTap: () => {Navigator.of(context).pop()},
            ),
          ],
        ),
      ),
    );
  }
}
