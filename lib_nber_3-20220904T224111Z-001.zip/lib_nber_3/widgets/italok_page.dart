import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:nberenergydrink/widgets/termekleiras.dart';
import '../services/shimmer_products.dart';
import '../services/storage_services.dart';

class ItalokPage extends StatelessWidget {
  final Stream<QuerySnapshot> products = FirebaseFirestore.instance.collection('products').where('type', whereIn: ['Italok']).snapshots();
  final Storage storage = Storage();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFFCFAF8),
      body: StreamBuilder<QuerySnapshot>(
        stream: products,
        builder: (BuildContext context, AsyncSnapshot<QuerySnapshot> snapshot) {
          if(snapshot.hasError) {
            return Text('Something went wrong');
          }
          if(snapshot.connectionState == ConnectionState.waiting) {
            return CircularProgressIndicator();
          }

          final data = snapshot.requireData;

          return Container(
              width: MediaQuery.of(context).size.width - 0.0,
              height: MediaQuery.of(context).size.height - 50.0,
              child: GridView.count(
                  crossAxisCount: 2,
                  primary: false,
                  padding:
                  EdgeInsets.only(right: 0.0, left: 0.0, bottom: 250.0),
                  crossAxisSpacing: 10.0,
                  mainAxisSpacing: 15.0,
                  childAspectRatio: 0.7,
                  children:
                  List.generate(data.size, (index) {
                    return Padding(
                        padding: EdgeInsets.only(top: 5.0, bottom: 5.0, left: 5.0, right: 5.0),
                        child: InkWell(
                            onTap: () {
                              Navigator.of(context).push(MaterialPageRoute(
                                  builder: (context) => TermekLeiras(
                                    name: "${data.docs[index]['name']}",
                                    picture: "${data.docs[index]['picture']}",
                                    price: "${data.docs[index]['price']}",
                                    leiras: "${data.docs[index]['desc']}",
                                    leiras2: "${data.docs[index]['desc2']}",
                                    link: "${data.docs[index]['link']}",
                                  )));
                            },
                            child: Container(
                                decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(15.0),
                                    boxShadow: [
                                      BoxShadow(
                                          color: Colors.grey.withOpacity(0.2),
                                          spreadRadius: 5.0,
                                          blurRadius: 5.0)
                                    ],
                                    color: Colors.white),
                                child: Column(
                                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      FutureBuilder(
                                          future: storage.downloadURL('${data.docs[index]['picture']}'),
                                          builder: (BuildContext context, AsyncSnapshot<String> snapshot) {
                                            if (snapshot.connectionState == ConnectionState.done && snapshot.hasData) {
                                              return Container(
                                                height: 150,
                                                padding: EdgeInsets.only(top: 10.0, left: 10.0, right: 10.0),
                                                child:
                                                InkWell(
                                                  child: Image.network(
                                                    snapshot.data!, fit: BoxFit.cover,
                                                  ),
                                                ),
                                              );
                                            }
                                            if(snapshot.connectionState== ConnectionState.waiting || !snapshot.hasData) {
                                              return ShimmerProducts();
                                            }
                                            return ShimmerProducts();
                                          }),
                                      SizedBox(height: 7.0),
                                      Center(
                                        child: Text('${data.docs[index]['type']}',
                                            textAlign: TextAlign.center,
                                            style: TextStyle(
                                                color: Color.fromARGB(255, 157, 210, 42),
                                                fontWeight: FontWeight.bold,
                                                fontSize: 14.0)),
                                      ),
                                      Center(
                                          child: Container(
                                            padding: EdgeInsets.only(
                                              top: 3.0,
                                            ),
                                            child: Text('${data.docs[index]['name']}',
                                                textAlign: TextAlign.center,
                                                style: TextStyle(
                                                    color: Color(0xFF575E67),
                                                    fontWeight: FontWeight.bold,
                                                    fontSize: 11.0)),
                                          )),
                                      Padding(
                                          padding: EdgeInsets.all(5.0),
                                          child:
                                          Container(color: Color(0xFFEBEBEB), height: 1.0)),
                                      Center(
                                        child: Text('${data.docs[index]['price']} Ft',
                                            textAlign: TextAlign.center,
                                            style: TextStyle(
                                                color: Color.fromARGB(255, 157, 210, 42),
                                                fontWeight: FontWeight.bold,
                                                fontSize: 14.0)),
                                      ),
                                      Padding(
                                        padding: EdgeInsets.all(5.0),
                                      ),
                                    ]))));
                  })
              ));
        },
      ),
    );
  }
}