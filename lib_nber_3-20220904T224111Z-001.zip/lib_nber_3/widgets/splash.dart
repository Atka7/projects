import 'package:flutter/material.dart';
import 'package:nberenergydrink/main.dart';

class SplashScreen extends StatefulWidget {
  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {

  @override
  void initState() {
    super.initState();
    _navigatetohome();
  }

  _navigatetohome() async {

    await Future.delayed(Duration(milliseconds: 3000), () {});
    Navigator.pushReplacement(
        context, MaterialPageRoute(builder: (context) => MyHomePage()));

  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Color.fromARGB(255, 157, 210, 42),
        body: Container(
            color: Color.fromARGB(255, 50, 50, 48),
            child: Column(
              children: [
                Expanded(
                  child: Container(),
                  flex: 1,
                ),
                Expanded(
                  child: Padding(
                    padding: EdgeInsets.all(50.0),
                    child: Image.asset('assets/logosplash.png'),
                  ),
                  flex: 10,
                ),
                Expanded(
                  flex: 2,
                  child: Column(
                    children: [
                      Text('from',
                        style: TextStyle(
                          color: Color.fromARGB(255, 101, 118, 134),
                          fontSize: 18,
                          fontWeight: FontWeight.bold
                        ),
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Image.asset('assets/poseidon.png', scale: 80,),
                          Text('Poseidon Originals',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                            ),
                          )
                        ],
                      )
                    ],
                  ),
                )
              ],
            ),
        ));
  }
}
