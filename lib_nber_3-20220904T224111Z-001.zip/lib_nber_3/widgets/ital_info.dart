import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:nberenergydrink/Poseidon.dart';

import '../services/shimmer_images_details.dart';
import '../services/storage_services_italok.dart';

class ItalInformacio extends StatelessWidget {
  final name, picture, szlogen, detail, tulajdonsag1, tulajdonsag2, tulajdonsag3;

  ItalInformacio({this.name, this.picture, this.szlogen, this.detail, this.tulajdonsag1, this.tulajdonsag2, this.tulajdonsag3});

  final StorageItalok storage = StorageItalok();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color.fromARGB(255, 157, 210, 42),
        elevation: 0.0,
        centerTitle: true,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () {
            Navigator.of(context).pop();
          },
        ),
        title: Text('Ital Információ',
            style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 20.0,
                color: Colors.white)),
        actions: <Widget>[],
      ),
      body: ListView(children: [
        SizedBox(height: 15.0),
        FutureBuilder(
            future: storage.downloadURL(picture),
            builder: (BuildContext context, AsyncSnapshot<String> snapshot) {
              if (snapshot.connectionState == ConnectionState.done && snapshot.hasData) {
                return Container(
                  child:
                  Image.network(
                    snapshot.data!, fit: BoxFit.cover,
                  ),

                );
              }
              if(snapshot.connectionState== ConnectionState.waiting || !snapshot.hasData) {
                return ShimmerDetails();
              }
              return ShimmerDetails();
            }),
        SizedBox(height: 20.0),
        Center(
          child: Text(name,
              style: TextStyle(
                  color: Color(0xFF575E67),
                  fontFamily: 'Roboto',
                  fontWeight: FontWeight.bold,
                  fontSize: 24.0)),
        ),
        SizedBox(height: 20.0),
        Center(
          child: Container(
            width: MediaQuery.of(context).size.width - 50.0,
            child: Text(szlogen,
                textAlign: TextAlign.center,
                style: TextStyle(
                    fontFamily: 'Roboto',
                    fontWeight: FontWeight.bold,
                    fontSize: 16.0,
                    color: Color(0xFFB4B8B9))),
          ),
        ),
        SizedBox(height: 10.0),
        Column(
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(
                  FontAwesomeIcons.circleCheck,
                  size: 40,
                  color: Color.fromARGB(255, 157, 210, 42),
                ),
                Text(tulajdonsag1,
                  style: TextStyle(
                    fontSize: 20,
                    fontFamily: 'Roboto',
                    fontWeight: FontWeight.bold,
                  ),
                )
              ],
            ),
            Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(
                  FontAwesomeIcons.circleCheck,
                  size: 40,
                  color: Color.fromARGB(255, 157, 210, 42),
                ),
                Text(tulajdonsag2,
                  style: TextStyle(
                    fontSize: 20,
                    fontFamily: 'Roboto',
                    fontWeight: FontWeight.bold,
                  ),
                )
              ],
            ),
            Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(
                  FontAwesomeIcons.circleCheck,
                  size: 40,
                  color: Color.fromARGB(255, 157, 210, 42),
                ),
                Text(tulajdonsag3,
                  style: TextStyle(
                    fontSize: 20,
                    fontFamily: 'Roboto',
                    fontWeight: FontWeight.bold,
                  ),
                )
              ],
            ),
          ],
        ),
        SizedBox(height: 15.0,),
        Center(
          child: Container(
            width: MediaQuery.of(context).size.width - 50.0,
            child: Text(detail,
                textAlign: TextAlign.center,
                style: TextStyle(
                    fontFamily: 'Roboto',
                    fontWeight: FontWeight.bold,
                    fontSize: 16.0,
                    color: Color(0xFFB4B8B9))),
          ),
        ),
      ]),
    );
  }
}
