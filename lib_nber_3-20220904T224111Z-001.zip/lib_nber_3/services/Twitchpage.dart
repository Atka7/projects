import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';
import '../widgets/options.dart';

class TwitchPage extends StatefulWidget {
  @override
  _TwitchPageState createState() => _TwitchPageState();
}

class _TwitchPageState extends State<TwitchPage> {
  bool isLoading = true;
  late WebViewController _webViewController;

  String link = 'https://www.facebook.com/Zsozeatyaofficial/';
  String title = ' Facebook';
  Icon fab = Icon(
    Icons.switch_right,
    size: 30.0,
  );

  int fabIconNumber = 0;


  @override
  Widget build(BuildContext context) {
    return Scaffold(
        drawer: NavDrawer(),
        appBar: AppBar(
          backgroundColor: Color.fromARGB(255, 157, 210, 42),
          iconTheme: IconThemeData(color: Colors.white),
          centerTitle: true,
          title: Text('Streamek' + title,
              textAlign: TextAlign.center,
              style: TextStyle(
                  color: Colors.white,
                  fontFamily: 'Roboto',
                  fontWeight: FontWeight.bold,
                  fontSize: 25.0)),
        ),
        body: Stack(children: <Widget>[
          WebView(
              initialUrl:
              link,
              javascriptMode: JavascriptMode.unrestricted,
              onWebViewCreated: (controller) {
                _webViewController = controller;
              },
              onPageFinished: (finish) {
                setState(() {
                  isLoading = false;
                });
              },
            ),
          isLoading
              ? Center(
                  child: CircularProgressIndicator(),
                )
              : Stack(),
        ]),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
        if (link=='https://www.facebook.com/Zsozeatyaofficial/') {
            _webViewController.loadUrl('https://player.twitch.tv/?channel=zsozeatyaofficial&parent=google.com');
        link = 'https://player.twitch.tv/?channel=zsozeatyaofficial&parent=google.com';
        title = ' Twitch';
        }
        else if(link == 'https://player.twitch.tv/?channel=zsozeatyaofficial&parent=google.com') {
          _webViewController.loadUrl('https://www.facebook.com/Zsozeatyaofficial/');
          link = 'https://www.facebook.com/Zsozeatyaofficial/';
          title = ' Facebook';
        }

        if (fabIconNumber == 0) {
          fab = Icon(
            Icons.switch_left,
            size: 30.0,
          );
          fabIconNumber = 1;
        } else {
          fab = Icon(Icons.switch_right,
            size: 30.0,
          );
          fabIconNumber = 0;
        }
        },

        backgroundColor: Color.fromARGB(255, 157, 210, 42),
        child: fab,
      ),
    );
  }
}
