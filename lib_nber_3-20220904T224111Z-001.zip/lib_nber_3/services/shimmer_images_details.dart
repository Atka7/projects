import 'package:flutter/material.dart';
import 'package:shimmer/shimmer.dart';

class ShimmerDetails extends StatelessWidget {
  const ShimmerDetails({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Container(
        height: 400.0,
        width: MediaQuery.of(context).size.width,
        padding: EdgeInsets.all(10.0),
        child:
        ClipRRect(
            borderRadius: BorderRadius.circular(15.0),
            child: SizedBox.fromSize(
              child: InkWell(
                  child: Shimmer.fromColors(
                    baseColor: Colors.grey.shade300,
                    highlightColor: Colors.grey.shade400,
                    child: Container(
                      color: Colors.grey.shade300,
                    ),
                  )
              ),
            )
        )
    );
  }
}