import 'package:flutter/material.dart';
import 'package:shimmer/shimmer.dart';

class ShimmerWidget extends StatelessWidget {
  const ShimmerWidget({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Container(
        height: 250.0,
        width: MediaQuery.of(context).size.width,
        padding: EdgeInsets.all(20.0),
        child:
        ClipRRect(
            borderRadius: BorderRadius.circular(25.0),
            child: SizedBox.fromSize(
              child: InkWell(
                child: Shimmer.fromColors(
                  baseColor: Colors.grey.shade300,
                  highlightColor: Colors.grey.shade400,
                  child: Container(
                    color: Colors.grey.shade300,
                  ),
                )
              ),
            )
        )
    );
  }
}