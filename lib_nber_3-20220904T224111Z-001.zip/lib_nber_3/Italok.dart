import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:nberenergydrink/services/storage_services_italok.dart';
import 'package:nberenergydrink/widgets/ital_info.dart';
import 'widgets/options.dart';

class Italok extends StatelessWidget {

  final Stream<QuerySnapshot> italok = FirebaseFirestore.instance.collection(
      'drinks').snapshots();
  final StorageItalok storage = StorageItalok();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        drawer: NavDrawer(),
        appBar: AppBar(
          iconTheme: IconThemeData(color: Colors.white),
          centerTitle: true,
          backgroundColor: Color.fromARGB(255, 157, 210, 42),
          title: Text('Italok',
              textAlign: TextAlign.center,
              style: TextStyle(
                  color: Colors.white,
                  fontFamily: 'Roboto',
                  fontWeight: FontWeight.bold,
                  fontSize: 25.0)),
        ),
        backgroundColor: Color(0xFFFCFAF8),
        body: Container(
          decoration: BoxDecoration(
            image: DecorationImage(
              image: AssetImage("assets/bg.png"),
              fit: BoxFit.cover,
            ),
          ),
          child: StreamBuilder<QuerySnapshot>(
            stream: italok,
            builder: (BuildContext context,
                AsyncSnapshot<QuerySnapshot> snapshot) {
              if (snapshot.hasError) {
                return Text('Something went wrong');
              }
              if (snapshot.connectionState == ConnectionState.waiting) {
                return Container(
                  child: CircularProgressIndicator(),
                );
              }

              final data = snapshot.requireData;

              return Container(
                  width: MediaQuery.of(context).size.width - 0.0,
                  height: MediaQuery.of(context).size.height - 50.0,
                  child: GridView.count(
                      crossAxisCount: 2,
                      primary: false,
                      padding:
                      EdgeInsets.only(right: 0.0, left: 0.0, bottom: 250.0),
                      crossAxisSpacing: 10.0,
                      mainAxisSpacing: 15.0,
                      childAspectRatio: 0.8,
                      children:
                      List.generate(data.size, (index) {
                        return Padding(
                            padding: EdgeInsets.only(
                                top: 5.0, bottom: 5.0, left: 5.0, right: 5.0),
                            child: InkWell(
                                onTap: () {
                                  Navigator.of(context).push(MaterialPageRoute(
                                      builder: (context) =>
                                          ItalInformacio(
                                            name: "${data.docs[index]['name']}",
                                            picture: "${data
                                                .docs[index]['picture']}",
                                            szlogen: "${data
                                                .docs[index]['szlogen']}",
                                            detail: "${data
                                                .docs[index]['detail']}",
                                            tulajdonsag1: "${data
                                                .docs[index]['tulajdonsag1']}",
                                            tulajdonsag2: "${data
                                                .docs[index]['tulajdonsag2']}",
                                            tulajdonsag3: "${data
                                                .docs[index]['tulajdonsag3']}",
                                          )));
                                },
                                child: Container(
                                    child: Column(
                                        crossAxisAlignment: CrossAxisAlignment
                                            .center,
                                        mainAxisAlignment: MainAxisAlignment
                                            .center,
                                        mainAxisSize: MainAxisSize.max,
                                        children: [
                                          FutureBuilder(
                                              future: storage.downloadURL(
                                                  '${data
                                                      .docs[index]['picture']}'),
                                              builder: (BuildContext context,
                                                  AsyncSnapshot<
                                                      String> snapshot) {
                                                if (snapshot.connectionState ==
                                                    ConnectionState.done &&
                                                    snapshot.hasData) {
                                                  return Container(
                                                    height: 227.0,
                                                    child:
                                                    InkWell(
                                                      child: Image.network(
                                                        snapshot.data!,
                                                        fit: BoxFit.cover,
                                                      ),
                                                    ),
                                                  );
                                                }
                                                if (snapshot.connectionState ==
                                                    ConnectionState.waiting ||
                                                    !snapshot.hasData) {
                                                  return Center(
                                                    child: CircularProgressIndicator(),
                                                  );
                                                }
                                                return Center(
                                                  child: CircularProgressIndicator(),
                                                );
                                              }),
                                        ]))));
                      })
                  ));
            },
          ),
        ));
  }
}
