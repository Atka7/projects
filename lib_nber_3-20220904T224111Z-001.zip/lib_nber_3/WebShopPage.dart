import 'package:flutter/material.dart';
import 'package:nberenergydrink/helpers/appcolors.dart';
import 'package:nberenergydrink/services/shimmer_widget.dart';
import 'package:nberenergydrink/widgets/italok_page.dart';
import 'package:nberenergydrink/widgets/kiegeszitok_page.dart';
import 'package:nberenergydrink/widgets/osszes_page.dart';
import 'package:nberenergydrink/widgets/ruhazat_page.dart';
import 'package:tab_indicator_styler/tab_indicator_styler.dart';
import 'package:url_launcher/url_launcher.dart';
import 'widgets/options.dart';
import 'services/storage_services.dart';

final Uri imageUrl = Uri.parse('https://leet.hu/nber');

class WebShopPage extends StatefulWidget {
  @override
  _WebShopPageState createState() => _WebShopPageState();
}

class _WebShopPageState extends State<WebShopPage>
    with SingleTickerProviderStateMixin {

  late TabController _tabController;

  company() async {
    if (await canLaunch('https://www.instagram.com/poseidon.studios/')) {
      await launch("https://www.instagram.com/poseidon.studios/");
    } else {
      throw 'Nem sikerült kapcsolódni a szerverekhez.';
    }
  }

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 1, vsync: this);
  }

  @override
  Widget build(BuildContext context) {
  final Storage storage = Storage();
    return Scaffold(
      extendBodyBehindAppBar: true,
      drawer: NavDrawer(),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        iconTheme: IconThemeData(color: AppColors.GREEN),
        shadowColor: AppColors.WHITE,
      ),
        body:
            ListView(
              children: <Widget> [
                Column(
                  children: [
                    FutureBuilder(
                        future: storage.downloadURL('promo_picture.jpg'),
                        builder: (BuildContext context, AsyncSnapshot<String> snapshot) {
                          if (snapshot.connectionState == ConnectionState.done && snapshot.hasData) {
                            return Container(
                                height: 250.0,
                                width: MediaQuery.of(context).size.width,
                                padding: EdgeInsets.all(20.0),
                                child:
                                ClipRRect(
                                    borderRadius: BorderRadius.circular(25.0),
                                    child: SizedBox.fromSize(
                                      child: InkWell(
                                        child: Image.network(
                                          snapshot.data!, fit: BoxFit.cover,
                                        ),
                                        onTap: () => launchUrl(imageUrl),
                                      ),
                                    )
                                )
                            );
                          }
                          if(snapshot.connectionState== ConnectionState.waiting || !snapshot.hasData) {
                            return ShimmerWidget();
                          }
                          return Container();
                        }),
                    DefaultTabController(
                        length: 4,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: <Widget> [
                            Container(
                              child: TabBar(
                                tabs: [
                                  Tab(child: Center(
                                    child: Container(
                                      padding: EdgeInsets.only(left: 30.0, right: 30.0),
                                      child: Text('Összes',
                                      style: TextStyle(
                                        fontFamily: 'Roboto',
                                        fontWeight: FontWeight.bold,
                                        fontSize: 21.0,
                                      ),),
                                    ),
                                  ),),
                                  Tab(child: Center(
                                    child: Container(
                                      padding: EdgeInsets.only(left: 30.0, right: 30.0),
                                      child: Text('Italok',
                                        style: TextStyle(
                                          fontFamily: 'Roboto',
                                          fontWeight: FontWeight.bold,
                                          fontSize: 21.0,
                                        ),),
                                    ),
                                  ),),
                                  Tab(child: Center(
                                    child: Container(
                                      padding: EdgeInsets.only(left: 30.0, right: 30.0),
                                      child: Text('Ruházat',
                                        style: TextStyle(
                                          fontFamily: 'Roboto',
                                          fontWeight: FontWeight.bold,
                                          fontSize: 21.0,
                                        ),),
                                    ),
                                  ),),
                                  Tab(child: Center(
                                    child: Container(
                                      padding: EdgeInsets.only(left: 30.0, right: 30.0),
                                      child: Text('Kiegészítők',
                                        style: TextStyle(
                                          fontFamily: 'Roboto',
                                          fontWeight: FontWeight.bold,
                                          fontSize: 21.0,
                                        ),),
                                    ),
                                  ),),
                                ],
                                indicatorSize: TabBarIndicatorSize.label,
                                isScrollable: true,
                                labelColor: AppColors.WHITE,
                                indicatorColor: AppColors.GREEN,
                                unselectedLabelColor: AppColors.DARK_GREEN,
                                indicator: RectangularIndicator(
                                  color: AppColors.GREEN,
                                  bottomLeftRadius: 100,
                                  bottomRightRadius: 100,
                                  topLeftRadius: 100,
                                  topRightRadius: 100,

                                ),
                              ),
                            ),
                            Container(
                              height: 600,
                              decoration: BoxDecoration(
                                  border: Border(top: BorderSide(color: Colors.grey, width: 0.5))
                              ),
                              child: TabBarView(
                                children: <Widget> [
                                  OsszesPage(),
                                  ItalokPage(),
                                  RuhazatPage(),
                                  KiegeszitokPage(),
                                ],
                              ),
                            )
                          ],
                        )
                    )
                  ],
                ),
              ],
            )


    );
  }
}


