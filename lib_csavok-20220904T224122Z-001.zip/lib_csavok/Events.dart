import 'package:csavok/widgets/ciggi_events.dart';
import 'package:csavok/widgets/csavok_events.dart';
import 'package:csavok/widgets/felus_events.dart';
import 'package:csavok/widgets/jauri_events.dart';
import 'package:csavok/widgets/joer_events.dart';
import 'package:csavok/widgets/koosz_events.dart';
import 'package:csavok/widgets/lennard_events.dart';
import 'package:csavok/widgets/options.dart';
import 'package:csavok/widgets/sipi_events.dart';
import 'package:flutter/material.dart';
import 'package:tab_indicator_styler/tab_indicator_styler.dart';

import 'helpers/appcolors.dart';

class Events extends StatefulWidget {
  const Events({Key? key}) : super(key: key);

  @override
  State<Events> createState() => _EventsState();
}

class Choice {
  final String title;
  final String image;

  Choice(this.title, this.image);
}

class _EventsState extends State<Events> {
  @override
  Widget build(BuildContext context) {

    List<Choice> tabs = [
      Choice('THE SHOW', 'assets/csavok.jpg'),
      Choice('Joer', 'assets/joer.jpg'),
      Choice('Lennard', 'assets/lennard.jpg'),
      Choice('Jauri', 'assets/jauri.jpg'),
      Choice('Koosz', 'assets/kooszmilan.jpg'),
      Choice('Ciggi', 'assets/ciggi.jpg'),
      Choice('Sipi', 'assets/sipi.jpg'),
      Choice('Felus', 'assets/felus.jpg'),
    ];
    return MaterialApp(
        home: DefaultTabController(
          length: tabs.length,
          child: Scaffold(
            drawer: NavDrawer(),
            appBar: AppBar(
                centerTitle: true,
                title: Text('Partyk',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 25.0)),
              backgroundColor: AppColors.CSAVOK_PRIMARY,
              iconTheme: IconThemeData(color: AppColors.WHITE),
              shadowColor: AppColors.WHITE,
              bottom: PreferredSize(
                preferredSize: Size(100.0, 100.0),
                child:
                Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                        colors: [
                          AppColors.CSAVOK_PRIMARY,
                          AppColors.CSAVOK_SECONDARY
                        ],
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        stops: [0.5,1.0]
                    ),
                  ),
                  child:
                TabBar(
                  labelPadding: EdgeInsets.symmetric(horizontal: 10.0),
                  tabs:
                  tabs.map((Choice tab) => Container(
                    height: 100.0,
                    child: Tab(
                        text: tab.title,
                        icon: ClipOval(
                          child: Image.asset(tab.image, scale: 7,),
                        )
                    ),
                  )
                  ).toList(),

                  indicatorSize: TabBarIndicatorSize.tab,
                  isScrollable: true,
                  labelColor: AppColors.CSAVOK_SECONDARY_TEXT,
                  indicatorColor: AppColors.CSAVOK_SECONDARY,
                  unselectedLabelColor: AppColors.WHITE,
                  indicator: BoxDecoration(
                      borderRadius: BorderRadius.circular(50),
                      color: Colors.transparent),
                ),
              ),
              )
            ),
            body: TabBarView(
              children: <Widget> [
                CsavokPage(),
                JoerPage(),
                LennardPage(),
                JauriPage(),
                KooszPage(),
                CiggiPage(),
                SipiPage(),
                FelusPage()

              ],
            ),


          ),
        ),
    );
  }
}
