import 'package:csavok/Cards.dart';
import 'package:csavok/Series.dart';
import 'package:csavok/Events.dart';
import 'package:csavok/helpers/appcolors.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:csavok/widgets/splash.dart';
import 'package:csavok/services/tabs_icons.dart';

final GlobalKey<NavigatorState> firstTabNavKey = GlobalKey<NavigatorState>();
final GlobalKey<NavigatorState> secondTabNavKey = GlobalKey<NavigatorState>();
final GlobalKey<NavigatorState> thirdTabNavKey = GlobalKey<NavigatorState>();
final GlobalKey<NavigatorState> fourthTabNavKey = GlobalKey<NavigatorState>();

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Csávók',
      theme: ThemeData(
        fontFamily: '',
        primaryColor: AppColors.CSAVOK_PRIMARY,
        primaryColorLight: const Color(0xFFFBE0E6),
      ),
      home: const SplashScreen(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({Key? key}) : super(key: key);

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 6, vsync: this);
  }

  @override
  void dispose() {
    super.dispose();
    _tabController.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return CupertinoTabScaffold(
      tabBar: CupertinoTabBar(
        activeColor: Colors.white,
        inactiveColor: AppColors.CSAVOK_PRIMARY_DARK,
        backgroundColor: AppColors.CSAVOK_PRIMARY,
        items: const [
          BottomNavigationBarItem(
            backgroundColor: Colors.white,
            activeIcon: Icon(CupertinoIcons.play_rectangle_fill,),
            icon: Icon(CupertinoIcons.play_rectangle,),
          ),
          BottomNavigationBarItem(
            backgroundColor: Colors.white,
            activeIcon: Icon(FontAwesomeIcons.solidCalendar,),
            icon: Icon(FontAwesomeIcons.solidCalendarDays,),
          ),
          BottomNavigationBarItem(
            backgroundColor: Colors.white,
            activeIcon: Icon(CupertinoIcons.suit_heart_fill,),
            icon: Icon(CupertinoIcons.suit_heart,),
          ),
          BottomNavigationBarItem(
            backgroundColor: Colors.white,
            activeIcon: Icon(TabsIcons.heart_regular,),
            icon: Icon(CupertinoIcons.heart_solid,),
          ),
        ],
      ),
      tabBuilder: (context, index) {
        if (index == 0) {
          return CupertinoTabView(
            navigatorKey: firstTabNavKey,
            builder: (BuildContext context) => const Series(),
          );
        }
        else if (index == 1) {
          return CupertinoTabView(
            navigatorKey: secondTabNavKey,
            builder: (BuildContext context) => const Events(),
          );
        }
        else if (index == 2) {
          return CupertinoTabView(
            navigatorKey: thirdTabNavKey,
            builder: (BuildContext context) => const Series(),
          );
        }
        else {
          return CupertinoTabView(
            navigatorKey: fourthTabNavKey,
            builder: (BuildContext context) => Cards(),
          );
        }
      },
    );
  }
}
