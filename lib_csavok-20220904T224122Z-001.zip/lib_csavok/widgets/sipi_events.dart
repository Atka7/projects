import 'package:flutter/material.dart';

class SipiPage extends StatefulWidget {
  const SipiPage({Key? key}) : super(key: key);

  @override
  State<SipiPage> createState() => _SipiPageState();
}

class _SipiPageState extends State<SipiPage> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
