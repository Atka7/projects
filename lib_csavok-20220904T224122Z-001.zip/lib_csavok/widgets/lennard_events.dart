import 'package:flutter/material.dart';

class LennardPage extends StatefulWidget {
  const LennardPage({Key? key}) : super(key: key);

  @override
  State<LennardPage> createState() => _LennardPageState();
}

class _LennardPageState extends State<LennardPage> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
