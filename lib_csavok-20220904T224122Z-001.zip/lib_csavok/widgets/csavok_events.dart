import 'package:flutter/material.dart';

class CsavokPage extends StatefulWidget {
  const CsavokPage({Key? key}) : super(key: key);

  @override
  State<CsavokPage> createState() => _CsavokPageState();
}

class _CsavokPageState extends State<CsavokPage> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
