import 'package:flutter/material.dart';

class JoerPage extends StatefulWidget {
  const JoerPage({Key? key}) : super(key: key);

  @override
  State<JoerPage> createState() => _JoerPageState();
}

class _JoerPageState extends State<JoerPage> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
