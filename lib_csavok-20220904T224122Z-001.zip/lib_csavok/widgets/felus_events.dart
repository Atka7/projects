import 'package:flutter/material.dart';

class FelusPage extends StatefulWidget {
  const FelusPage({Key? key}) : super(key: key);

  @override
  State<FelusPage> createState() => _FelusPageState();
}

class _FelusPageState extends State<FelusPage> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
