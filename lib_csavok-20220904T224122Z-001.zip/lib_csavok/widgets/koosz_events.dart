import 'package:flutter/material.dart';

class KooszPage extends StatefulWidget {
  const KooszPage({Key? key}) : super(key: key);

  @override
  State<KooszPage> createState() => _KooszPageState();
}

class _KooszPageState extends State<KooszPage> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
