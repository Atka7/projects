import 'package:csavok/helpers/appcolors.dart';
import 'package:flutter/material.dart';
import 'package:csavok/main.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({Key? key}) : super(key: key);

  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {

  @override
  void initState() {
    super.initState();
    _navigatetohome();
  }

  _navigatetohome() async {

    await Future.delayed(Duration(milliseconds: 3000), () {});
    Navigator.pushReplacement(
        context, MaterialPageRoute(builder: (context) => MyHomePage()));

  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: AppColors.CSAVOK_PRIMARY,
        body: Container(
          color: AppColors.CSAVOK_PRIMARY,
          child: Column(
            children: [
              Expanded(
                child: Container(),
                flex: 1,
              ),
              Expanded(
                child: Padding(
                  padding: EdgeInsets.all(30.0),
                  child: Image.asset('assets/csavoklogo.png'),
                ),
                flex: 10,
              ),
              Expanded(
                flex: 2,
                child: Column(
                  children: [
                    Text('from',
                      style: TextStyle(
                          color: AppColors.CSAVOK_PRIMARY_DARK,
                          fontSize: 18,
                          fontWeight: FontWeight.bold
                      ),
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Image.asset('assets/poseidon.png', scale: 80,),
                        Text('Poseidon Originals',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                          ),
                        )
                      ],
                    )
                  ],
                ),
              )
            ],
          ),
        ));
  }
}
