import 'package:flutter/material.dart';

class CiggiPage extends StatefulWidget {
  const CiggiPage({Key? key}) : super(key: key);

  @override
  State<CiggiPage> createState() => _CiggiPageState();
}

class _CiggiPageState extends State<CiggiPage> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
