import 'package:csavok/helpers/appcolors.dart';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

class NavDrawer extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
              colors: [
                AppColors.CSAVOK_SECONDARY,
                AppColors.CSAVOK_PRIMARY
              ],
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              stops: [0.5, 1]
          ),
        ),
        child: ListView(
          padding: EdgeInsets.zero,
          children: <Widget>[
            DrawerHeader(
              child: Text(
                '',
              ),
              decoration: BoxDecoration(
                  gradient: LinearGradient(
                      colors: [
                        AppColors.CSAVOK_PRIMARY,
                        AppColors.CSAVOK_SECONDARY
                      ],
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      stops: [0.5, 1]
                  ),                  image: DecorationImage(
                      fit: BoxFit.fitWidth,
                      image: AssetImage('assets/csavoklogo.png'))),
            ),
            ListTile(
              leading: Icon(
                FontAwesomeIcons.globe,
                color: AppColors.CSAVOK_SECONDARY_TEXT,
              ),
              title: Text(
                'Platformok',
                style: TextStyle(
                    color: AppColors.CSAVOK_SECONDARY_TEXT,
                    fontWeight: FontWeight.bold,
                    fontSize: 18.0),
              ),
              onTap: () => {launch("https://nberenergydrink.hu/")},
            ),
            ListTile(
              leading: Icon(
                FontAwesomeIcons.table,
                color: AppColors.CSAVOK_SECONDARY_TEXT,
              ),
              title: Text(
                'Pontozás',
                style: TextStyle(
                    color: AppColors.CSAVOK_SECONDARY_TEXT,
                    fontWeight: FontWeight.bold,
                    fontSize: 18.0),
              ),
              onTap: () => {launch("https://nberenergydrink.hu/#rendeles")},
            ),
            ListTile(
              leading: Icon(
                Icons.exit_to_app,
                color: AppColors.CSAVOK_SECONDARY_TEXT,
              ),
              title: Text(
                'Bezárás',
                style: TextStyle(
                    color: AppColors.CSAVOK_SECONDARY_TEXT,
                    fontWeight: FontWeight.bold,
                    fontSize: 18.0),
              ),
              onTap: () => {Navigator.of(context).pop()},
            ),
          ],
        ),
      ),
    );
  }
}
