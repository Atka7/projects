import 'package:flutter/material.dart';

class JauriPage extends StatefulWidget {
  const JauriPage({Key? key}) : super(key: key);

  @override
  State<JauriPage> createState() => _JauriPageState();
}

class _JauriPageState extends State<JauriPage> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
