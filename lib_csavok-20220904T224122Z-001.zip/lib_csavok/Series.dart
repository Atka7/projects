import 'package:csavok/widgets/card_widget.dart';
import 'package:flutter/material.dart';

import 'helpers/appcolors.dart';

class Series extends StatefulWidget {
  const Series({Key? key}) : super(key: key);

  @override
  State<Series> createState() => _SeriesState();
}

class _SeriesState extends State<Series> {
  @override
  Widget build(BuildContext context) {
    return Container(
    );
  }
}
