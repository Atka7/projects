import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:csavok/widgets/card_widget.dart';
import 'package:csavok/widgets/options.dart';
import 'package:dotted_line/dotted_line.dart';
import 'package:flutter/material.dart';

import 'helpers/appcolors.dart';

class Cards extends StatelessWidget {
  final Stream<QuerySnapshot> kartyak = FirebaseFirestore.instance.collection('cards').snapshots();

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
          drawer: NavDrawer(),
          appBar: AppBar(
            centerTitle: true,
            title: Text('Kártyák',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 25.0)),
              backgroundColor: AppColors.CSAVOK_PRIMARY,
              iconTheme: IconThemeData(color: AppColors.WHITE),
              shadowColor: AppColors.WHITE,
          ),
          body: Scaffold(
            backgroundColor: Color(0xFFFCFAF8),
            body: StreamBuilder<QuerySnapshot>(
              stream: kartyak,
              builder: (BuildContext context, AsyncSnapshot<QuerySnapshot> snapshot) {
                if(snapshot.hasError) {
                  return Text('Something went wrong');
                }
                if(snapshot.connectionState == ConnectionState.waiting) {
                  return CircularProgressIndicator();
                }

                final data = snapshot.requireData;

                return Container(
                    width: MediaQuery.of(context).size.width - 0.0,
                    height: MediaQuery.of(context).size.height - 50.0,
                    child: GridView.count(
                        crossAxisCount: 2,
                        primary: false,
                        padding:
                        EdgeInsets.only(right: 5.0, left: 5.0, bottom: 250.0, top: 5.0),
                        crossAxisSpacing: 10.0,
                        mainAxisSpacing: 15.0,
                        childAspectRatio: 0.8,
                        children:
                        List.generate(data.size, (index) {
                          return Padding(
                              padding: EdgeInsets.only(top: 5.0, bottom: 5.0, left: 5.0, right: 5.0),
                              child: InkWell(
                                  onTap: () {
                                    Navigator.of(context).push(MaterialPageRoute(
                                        builder: (context) => Kartya(
                                          name: "${data.docs[index]['name']}",
                                        )));
                                  },
                                  child: Container(
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(0.0),
                                        boxShadow: [
                                          BoxShadow(
                                              color: Colors.grey.withOpacity(0.2),
                                              spreadRadius: 3.0,
                                              blurRadius: 5.0)
                                        ],
                                        gradient: LinearGradient(
                                          begin: Alignment.topLeft,
                                          end: Alignment(1.5, 0.5),
                                          stops: [0.0,0.5,0.5 ,1],
                                          colors: [
                                            AppColors.KARTYA_KEK1,
                                            AppColors.KARTYA_KEK1,
                                            AppColors.KARTYA_KEK2,
                                            AppColors.KARTYA_KEK2,
                                          ],
                                          tileMode: TileMode.repeated,
                                        ),
                                      ),
                                      child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.center,
                                          mainAxisAlignment: MainAxisAlignment.end,
                                          mainAxisSize: MainAxisSize.max,
                                          children: [
                                            Expanded(
                                              child: Center(
                                                child: Container(
                                                  height: 150.0,
                                                  child: Image.asset('assets/csavoklogo.png'),
                                                ),
                                              ),
                                              flex: 5,
                                            ),
                                            Expanded(
                                              child: Center(
                                                  child: Container(
                                                    padding: EdgeInsets.only(left: 5, right: 5),
                                                    child: Column(
                                                      crossAxisAlignment: CrossAxisAlignment.center,
                                                      mainAxisAlignment: MainAxisAlignment.start,
                                                      children: [
                                                        Text('${data.docs[index]['name']}',
                                                            textAlign: TextAlign.center,
                                                            style: TextStyle(
                                                                color: AppColors.WHITE,
                                                                fontWeight: FontWeight.bold,
                                                                fontSize: 20.0)),
                                                        Center(
                                                          child: DottedLine(
                                                            dashColor: AppColors.WHITE,
                                                            dashLength: 25,
                                                            dashGapLength: 10,
                                                            lineThickness: 7,
                                                          ),
                                                        )
                                                      ],
                                                    )
                                                  )),
                                              flex: 5,
                                            ),
                                            Expanded(
                                              flex: 1,
                                              child: Center(
                                                  child: Container(
                                                    padding: EdgeInsets.only(
                                                      top: 3.0,
                                                    ),
                                                    child: Text('KÁRTYA',
                                                        textAlign: TextAlign.center,
                                                        style: TextStyle(
                                                            color: AppColors.WHITE,
                                                            fontWeight: FontWeight.bold,
                                                            fontSize: 15.0)),
                                                  )),
                                            ),
                                          ]))));
                        })

                    ));
              },
            ),

          ),

          ),


        );
  }
}
