import 'dart:core';
import 'dart:ui';

class AppColors {
  static const Color JOER = Color.fromARGB(255, 157, 210, 42);
  static const Color JAURI = Color.fromARGB(255, 117 ,169,  39);
  static const Color LENNARD = Color.fromARGB(255, 255, 255, 255);
  static const Color KOOSZ = Color.fromARGB(255, 255, 255, 255);
  static const Color FELUS = Color.fromARGB(255, 255, 255, 255);
  static const Color CIGI = Color.fromARGB(255, 255, 255, 255);
  static const Color SIPI = Color.fromARGB(255, 255, 255, 255);
  static const Color WHITE = Color.fromARGB(255, 255, 255, 255);
  static const Color BLACK = Color.fromARGB(255, 0, 0, 0);

  static const Color CSAVOK_PRIMARY_TEXT = Color.fromARGB(255, 255, 255, 255);
  static const Color CSAVOK_SECONDARY_TEXT = Color.fromARGB(255, 12, 204, 31);
  static const Color CSAVOK_PRIMARY = Color.fromARGB(255, 254, 70, 0);
  static const Color CSAVOK_PRIMARY_DARK = Color.fromARGB(255, 182, 18, 0);

  static const Color CSAVOK_SECONDARY = Color.fromARGB(255, 255, 224, 1);

  static const Color KARTYA_KEK1 = Color.fromARGB(255, 44, 59, 90);
  static const Color KARTYA_KEK2 = Color.fromARGB(255, 27, 42, 67);


}