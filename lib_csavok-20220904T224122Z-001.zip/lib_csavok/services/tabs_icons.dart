/// flutter:
///   fonts:
///    - family:  MyFlutterApp
///      fonts:
///       - asset: fonts/MyFlutterApp.ttf

import 'package:flutter/widgets.dart';

class TabsIcons {
  TabsIcons._();

  static const _kFontFam = 'TabsIcons';
  static const String? _kFontPkg = null;

  static const IconData heart_regular = IconData(0xe800, fontFamily: _kFontFam, fontPackage: _kFontPkg);
  static const IconData heart_blank = IconData(0xe801, fontFamily: _kFontFam, fontPackage: _kFontPkg);
  static const IconData calendar_blank = IconData(0xe802, fontFamily: _kFontFam, fontPackage: _kFontPkg);
  static const IconData cards_blank = IconData(0xe803, fontFamily: _kFontFam, fontPackage: _kFontPkg);
  static const IconData calendar_regular = IconData(0xe804, fontFamily: _kFontFam, fontPackage: _kFontPkg);
}
